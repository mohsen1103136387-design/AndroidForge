# AutoScope ProGuard rules (minifyEnabled is false by default)
-keepclassmembers class ir.autoscope.app.MainActivity$AutoScopeJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
