package ir.autoscope.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var lastBackPressedMs: Long = 0L

    companion object {
        private const val LOCAL_APP_URL =
            "https://appassets.androidplatform.net/assets/www/index.html"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#020617")
        window.navigationBarColor = Color.parseColor("#020617")

        webView = WebView(this)
        setContentView(webView)

        // Enable hardware acceleration for smooth Three.js WebGL 3D rendering
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        webView.setBackgroundColor(Color.parseColor("#020617"))

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(false)

        val defaultApiBase = getString(R.string.default_api_base)
        webView.addJavascriptInterface(AutoScopeJsBridge(defaultApiBase), "AndroidBridge")

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                if (url.startsWith("https://appassets.androidplatform.net/")) {
                    return false
                }
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    true
                } catch (_: Exception) {
                    false
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                val escapedBase = defaultApiBase
                    .replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                view.evaluateJavascript(
                    "window.__AUTOSCOPE_API_BASE__ = \"$escapedBase\";",
                    null
                )
            }
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(LOCAL_APP_URL)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                    return
                }
                val now = System.currentTimeMillis()
                if (now - lastBackPressedMs < 2000L) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                } else {
                    lastBackPressedMs = now
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.press_back_again),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
        super.onDestroy()
    }

    inner class AutoScopeJsBridge(private val apiBase: String) {

        @JavascriptInterface
        fun getApiBaseUrl(): String = apiBase

        @JavascriptInterface
        fun printReport(title: String?) {
            val jobTitle = if (!title.isNullOrBlank()) title else "AutoScope-Report"
            runOnUiThread {
                try {
                    val printManager =
                        getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return@runOnUiThread
                    val adapter = webView.createPrintDocumentAdapter(jobTitle)
                    printManager.print(jobTitle, adapter, PrintAttributes.Builder().build())
                } catch (_: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "خطا در باز کردن پنجره چاپ اندروید",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun shareText(text: String?, title: String?) {
            if (text.isNullOrBlank()) return
            runOnUiThread {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    if (!title.isNullOrBlank()) {
                        putExtra(Intent.EXTRA_SUBJECT, title)
                    }
                }
                startActivity(
                    Intent.createChooser(shareIntent, getString(R.string.share_report_title))
                )
            }
        }

        @JavascriptInterface
        fun exportCsv(csvContent: String?, filename: String?) {
            if (csvContent.isNullOrBlank()) return
            val safeName = (if (!filename.isNullOrBlank()) filename else "autoscope-history.csv")
                .replace(Regex("[^a-zA-Z0-9._-]"), "_")
            runOnUiThread {
                try {
                    val exportDir = File(cacheDir, "exports")
                    if (!exportDir.exists()) exportDir.mkdirs()
                    val outFile = File(exportDir, safeName)
                    outFile.writeText(csvContent, Charsets.UTF_8)

                    val uri = FileProvider.getUriForFile(
                        this@MainActivity,
                        "${packageName}.fileprovider",
                        outFile
                    )
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/csv"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(
                        Intent.createChooser(intent, getString(R.string.export_csv_title))
                    )
                } catch (_: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "خطا در ذخیره فایل اکسل",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun openExternalUrl(url: String?) {
            if (url.isNullOrBlank()) return
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (_: Exception) {
                    // ignore invalid URL
                }
            }
        }
    }
}
