import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
// Must always be port 3000 as per AI Studio environment constraints (nginx reverse proxy forwards to 3000)
const PORT = 3000;

app.use(express.json());

// Initialize GoogleGenAI server-side with required User-Agent header
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Cooldown timestamp if Gemini returns 429 RESOURCE_EXHAUSTED so we don't spam exhausted quota
let geminiCooldownUntil = 0;
const GEMINI_COOLDOWN_MS = 5 * 60 * 1000;

// In-memory cache for live IranJib price table (30 minutes TTL)
interface IranJibRow {
  name: string;
  normalizedName: string;
  tokens: string[];
  marketPrice: number;
  factoryPrice: number | null;
}

interface IranJibCache {
  fetchedAt: number;
  dateLabel: string;
  rows: IranJibRow[];
}

let iranJibCache: IranJibCache | null = null;
const IRANJIB_CACHE_TTL_MS = 30 * 60 * 1000;

interface PriceResponseCacheEntry {
  cachedAt: number;
  payload: Record<string, any>;
}

const priceResponseCache = new Map<string, PriceResponseCacheEntry>();
const PRICE_RESPONSE_CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours

function toEnglishDigitsServer(input: string): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  let out = input;
  for (let i = 0; i < 10; i++) {
    out = out.replace(new RegExp(persianDigits[i], 'g'), String(i));
    out = out.replace(new RegExp(arabicDigits[i], 'g'), String(i));
  }
  return out;
}

function normalizeCarText(input: string): string {
  return toEnglishDigitsServer(input)
    .toLowerCase()
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\u200c()\[\]\/\-_.،,]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseTomanCell(cellText: string): number | null {
  const english = toEnglishDigitsServer(cellText);
  const match = english.match(/(\d{1,3}(?:[,٬]\d{3}){2,3}|\d{8,12})/);
  if (!match) return null;
  const val = Number(match[1].replace(/[,٬]/g, ''));
  if (!Number.isFinite(val) || val < 50_000_000 || val > 80_000_000_000) return null;
  return val;
}

async function fetchIranJibLivePrices(): Promise<IranJibCache | null> {
  if (iranJibCache && Date.now() - iranJibCache.fetchedAt < IRANJIB_CACHE_TTL_MS) {
    return iranJibCache;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const response = await fetch(
      'https://www.iranjib.ir/showgroup/45/%D9%82%DB%8C%D9%85%D8%AA-%D8%AE%D9%88%D8%AF%D8%B1%D9%88/',
      {
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.8',
        },
      }
    );

    if (!response.ok) return iranJibCache;
    const html = await response.text();
    const trMatches = [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)];

    let dateLabel = 'آبان ۱۴۰۵ (مرجع: ایران‌جیب)';
    const rows: IranJibRow[] = [];

    for (const m of trMatches) {
      const cells = [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map((c) =>
        c[1]
          .replace(/<[^>]+>/g, ' ')
          .replace(/&nbsp;/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
      );

      // Header row often holds the Persian date in the 3rd cell
      if (cells.length >= 3 && /۱۴۰\d|140\d/.test(cells[2]) && !parseTomanCell(cells[1])) {
        const cleanedDate = cells[2].replace(/[A-Za-z0-9,\s]+$/g, '').trim();
        if (cleanedDate) dateLabel = `${cleanedDate} (ایران‌جیب)`;
      }

      if (cells.length >= 2) {
        const marketPrice = parseTomanCell(cells[1]);
        if (marketPrice && cells[0].length >= 2) {
          const factoryPrice = cells[2] ? parseTomanCell(cells[2]) : null;
          const normalizedName = normalizeCarText(cells[0]);
          const tokens = normalizedName.split(' ').filter((t) => t.length >= 1);
          rows.push({
            name: cells[0],
            normalizedName,
            tokens,
            marketPrice,
            factoryPrice,
          });
        }
      }
    }

    if (rows.length > 0) {
      iranJibCache = {
        fetchedAt: Date.now(),
        dateLabel,
        rows,
      };
      return iranJibCache;
    }

    return iranJibCache;
  } catch {
    return iranJibCache;
  } finally {
    clearTimeout(timeout);
  }
}

const PRIMARY_MODEL_FAMILIES = [
  'پارس', 'دنا', 'تارا', 'سورن', 'رانا', 'سمند', 'تیبا', 'ساینا', 'کوییک',
  'شاهین', 'اطلس', 'سهند', 'پراید', 'وانت', 'آریسان', 'زامیاد', 'تندر', 'ساندرو',
  'جک', 'آریزو', 'تیگو', 'فیدلیتی', 'دیگنیتی', 'لاماری', 'ریسپکت', 'بسترن',
  'فونیکس', 'هایما', 'سانتافه', 'سوناتا', 'الانترا', 'اسپورتیج', 'سراتو',
  'اپتیما', 'کرولا', 'راو4', 'تلیسمان', 'جوک', 'چانگان', 'سیتروئن', 'ریرا',
];

function matchIranJibLiveRow(modelName: string, cache: IranJibCache | null): IranJibRow | null {
  if (!cache || cache.rows.length === 0) return null;

  const stopWords = new Set([
    'پژو', 'سمند', 'رنو', 'چری', 'ام', 'وی', 'سایپا', 'ایران', 'خودرو',
    'موتور', 'سقف', 'شیشه', 'ای', 'فول', 'توربو', 'و', 'یا', 'تیپ', 'مدل',
  ]);
  const queryNorm = normalizeCarText(modelName).replace(/ری را/g, 'ریرا');
  const queryTokens = queryNorm.split(' ').filter((t) => t.length >= 1);
  if (queryTokens.length === 0) return null;

  // Extract mandatory 2+ char alphanumeric/numeric model codes (e.g., 206, 207, 405, x22, x33, s5, s7, j4, l90, h30)
  const requiredCodes = queryTokens.filter((t) => /\d/.test(t) && t.length >= 2);
  // Extract mandatory Persian model family names
  const requiredFamilies = PRIMARY_MODEL_FAMILIES.filter((fam) => queryNorm.includes(fam));

  let bestRow: IranJibRow | null = null;
  let bestScore = 0;

  for (const row of cache.rows) {
    const rowNorm = row.normalizedName.replace(/ری را/g, 'ریرا');

    // Enforce exact match on primary model code (e.g. 206 != 207) and family (e.g. دنا != تارا)
    if (requiredCodes.length > 0 && !requiredCodes.some((code) => row.tokens.includes(code) || rowNorm.includes(code))) {
      continue;
    }
    if (requiredFamilies.length > 0 && !requiredFamilies.some((fam) => rowNorm.includes(fam))) {
      continue;
    }
    if (requiredCodes.length === 0 && requiredFamilies.length === 0) {
      continue;
    }

    let score = 0;
    for (const qt of queryTokens) {
      const isKey = /\d/.test(qt) || !stopWords.has(qt);
      if (row.tokens.includes(qt)) {
        score += isKey ? 4 : 1;
      } else if (qt.length >= 3 && rowNorm.includes(qt)) {
        score += 2;
      }
    }

    // Penalize mismatches on critical trim keywords
    const qAuto = /اتومات|cvt|at/.test(queryNorm);
    const rAuto = /اتومات|cvt|at/.test(rowNorm);
    if (qAuto !== rAuto) score -= 3;

    const qPan = /پانوراما/.test(queryNorm);
    const rPan = /پانوراما/.test(rowNorm);
    if (qPan !== rPan) score -= 2;

    if (score > bestScore && score >= 4) {
      bestScore = score;
      bestRow = row;
    }
  }

  return bestRow;
}

interface CarIrRow {
  name: string;
  normalizedName: string;
  tokens: string[];
  year: number | null;
  marketPrice: number;
}

interface CarIrCache {
  fetchedAt: number;
  rows: CarIrRow[];
}

let carIrCache: CarIrCache | null = null;
const CAR_IR_CACHE_TTL_MS = 30 * 60 * 1000;

interface DiscontinuedRule {
  pattern: RegExp;
  lastYear: number;
  label: string;
}

const DISCONTINUED_CAR_RULES: DiscontinuedRule[] = [
  { pattern: /پیکان|آردی|روا|روآ/, lastYear: 1391, label: 'پیکان / روآ' },
  { pattern: /زانتیا/, lastYear: 1389, label: 'سیتروئن زانتیا' },
  { pattern: /ماکسیما|مگان/, lastYear: 1392, label: 'نیسان ماکسیما / رنو مگان' },
  { pattern: /مزدا3|مزدا۳|مزدا\s*3/, lastYear: 1398, label: 'مزدا ۳' },
  { pattern: /پژو\s*405|405/, lastYear: 1400, label: 'پژو ۴۰۵' },
  { pattern: /پژو\s*206|206/, lastYear: 1402, label: 'پژو ۲۰۶' },
  { pattern: /پژو\s*پارس|پارسسال|پارسtu5|پارسelx|پارسlx/, lastYear: 1403, label: 'پژو پارس' },
  { pattern: /سمند(?!.*سورن)/, lastYear: 1401, label: 'سمند LX / EF7' },
  { pattern: /پراید\s*(111|131|132|141|صبا|نسیم)/, lastYear: 1399, label: 'پراید سواری' },
  { pattern: /تیبا/, lastYear: 1402, label: 'تیبا / تیبا ۲' },
  { pattern: /تندر|l90|ال\s*90|ال90|پارس\s*تندر/, lastYear: 1398, label: 'رنو تندر ۹۰ (L90)' },
  { pattern: /ساندرو|استپ\s*وی/, lastYear: 1398, label: 'رنو ساندرو' },
  { pattern: /برلیانس|h330|h320|h230|h220/, lastYear: 1399, label: 'برلیانس' },
  { pattern: /دانگ\s*فنگ|h30/, lastYear: 1399, label: 'دانگ‌فنگ H30 کراس' },
  { pattern: /بسترن|b30|b50/, lastYear: 1399, label: 'بسترن' },
  { pattern: /تیگو\s*5|تیگو5/, lastYear: 1401, label: 'چری تیگو ۵' },
  { pattern: /لیفان|x50|x60|620|820/, lastYear: 1398, label: 'لیفان' },
  { pattern: /ام\s*وی\s*ام\s*(110|315|530|550)|x33\s*s|x33s/, lastYear: 1400, label: 'ام‌وی‌ام (نسل قدیمی)' },
  { pattern: /جک\s*j5|j5/, lastYear: 1397, label: 'جک J5' },
  { pattern: /پژو\s*(2008|301|508)/, lastYear: 1398, label: 'پژو ۲۰۰۸ / ۳۰۱ / ۵۰۸' },
  { pattern: /سیتروئن\s*c3|c3/, lastYear: 1398, label: 'سیتروئن C3' },
  { pattern: /سوزوکی|گرند\s*ویتارا/, lastYear: 1398, label: 'سوزوکی گرند ویتارا' },
  { pattern: /سراتو\s*(مونتاژ|سایپا|وارداتی)?/, lastYear: 1398, label: 'کیا سراتو' },
  { pattern: /تلیسمان|کولئوس|سیمبل/, lastYear: 1397, label: 'رنو تلیسمان / کولئوس' },
  { pattern: /جوک/, lastYear: 1397, label: 'نیسان جوک' },
  { pattern: /سانتافه|سوناتا|الانترا|اسپورتیج|اپتیما|توسان|آزرا/, lastYear: 1397, label: 'وارداتی نسل قبل' },
];

function detectDiscontinuedCar(
  modelName: string,
  queryYear: number,
  hasLiveIranJibMatch: boolean
): { isDiscontinued: boolean; lastProductionYear?: number } {
  const norm = normalizeCarText(modelName);
  const compact = norm.replace(/\s+/g, '');

  // Explicit exemption: Pride 151 Pickup is still produced
  if (/151|وانتپراید/.test(compact)) {
    return { isDiscontinued: false };
  }
  // Explicit exemption: Soren Plus is still produced (only classic Samand is discontinued)
  if (/سورن/.test(compact)) {
    return { isDiscontinued: false };
  }

  for (const rule of DISCONTINUED_CAR_RULES) {
    if (rule.pattern.test(norm) || rule.pattern.test(compact)) {
      return { isDiscontinued: true, lastProductionYear: rule.lastYear };
    }
  }

  // If the model isn't on the active zero-km IranJib table and requested year is 1402 or older,
  // treat it as discontinued / out-of-production used market car.
  if (!hasLiveIranJibMatch && queryYear <= 1402) {
    return { isDiscontinued: true };
  }

  return { isDiscontinued: false };
}

async function fetchCarIrPrices(): Promise<CarIrCache | null> {
  if (carIrCache && Date.now() - carIrCache.fetchedAt < CAR_IR_CACHE_TTL_MS) {
    return carIrCache;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const response = await fetch('https://car.ir/prices', {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.8',
      },
    });
    if (!response.ok) return carIrCache;

    const html = await response.text();
    const trMatches = [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)];
    const rows: CarIrRow[] = [];

    for (const m of trMatches) {
      const cells = [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map((c) =>
        c[1]
          .replace(/<[^>]+>/g, ' ')
          .replace(/&nbsp;/g, ' ')
          .replace(/\s+/g, ' ')
          .trim()
      );
      if (cells.length < 3) continue;

      const rawName = cells[0];
      // Market price on car.ir is usually in cell[2] (or cell[1] if cell[2] is "---")
      const marketPrice = parseTomanCell(cells[2]) || parseTomanCell(cells[1]);
      if (!marketPrice || rawName.length < 2) continue;

      const yearMatch = toEnglishDigitsServer(rawName).match(/مدل\s*(\d{4})/);
      let rowYear: number | null = null;
      if (yearMatch) {
        const yNum = Number(yearMatch[1]);
        rowYear = yNum >= 1990 && yNum <= 2030 ? yNum - 621 : yNum;
      }

      const normalizedName = normalizeCarText(rawName.replace(/مدل\s*[0-9۰-۹]{4}/g, ''));
      const tokens = normalizedName.split(' ').filter((t) => t.length >= 1);
      rows.push({
        name: rawName,
        normalizedName,
        tokens,
        year: rowYear,
        marketPrice,
      });
    }

    if (rows.length > 0) {
      carIrCache = { fetchedAt: Date.now(), rows };
    }
    return carIrCache;
  } catch {
    return carIrCache;
  } finally {
    clearTimeout(timeout);
  }
}

function matchCarIrRow(
  modelName: string,
  targetYear: number,
  cache: CarIrCache | null
): { avg: number; min: number; max: number; matchedName: string } | null {
  if (!cache || cache.rows.length === 0) return null;

  const stopWords = new Set([
    'پژو', 'سمند', 'رنو', 'چری', 'ام', 'وی', 'سایپا', 'ایران', 'خودرو',
    'موتور', 'سقف', 'شیشه', 'ای', 'فول', 'توربو', 'و', 'یا', 'تیپ', 'مدل',
  ]);
  const queryNorm = normalizeCarText(modelName).replace(/ری را/g, 'ریرا');
  const queryTokens = queryNorm.split(' ').filter((t) => t.length >= 1);
  if (queryTokens.length === 0) return null;

  const requiredCodes = queryTokens.filter((t) => /\d/.test(t) && t.length >= 2);
  const requiredFamilies = PRIMARY_MODEL_FAMILIES.filter((fam) => queryNorm.includes(fam));

  let bestRow: CarIrRow | null = null;
  let bestScore = -999;

  for (const row of cache.rows) {
    const rowNorm = row.normalizedName.replace(/ری را/g, 'ریرا');

    if (
      requiredCodes.length > 0 &&
      !requiredCodes.some((code) => row.tokens.includes(code) || rowNorm.includes(code))
    ) {
      continue;
    }
    if (
      requiredFamilies.length > 0 &&
      !requiredFamilies.some((fam) => rowNorm.includes(fam))
    ) {
      continue;
    }
    if (requiredCodes.length === 0 && requiredFamilies.length === 0) {
      continue;
    }

    let score = 0;
    for (const qt of queryTokens) {
      const isKey = /\d/.test(qt) || !stopWords.has(qt);
      if (row.tokens.includes(qt)) {
        score += isKey ? 4 : 1;
      } else if (qt.length >= 3 && rowNorm.includes(qt)) {
        score += 2;
      }
    }

    const qAuto = /اتومات|cvt|at/.test(queryNorm);
    const rAuto = /اتومات|cvt|at/.test(rowNorm);
    if (qAuto !== rAuto) score -= 3;

    // Penalize conflicting trim numbers (e.g., تیپ 5 vs تیپ 2)
    const qTip = queryNorm.match(/تیپ\s*(\d+)/);
    const rTip = rowNorm.match(/تیپ\s*(\d+)/);
    if (qTip && rTip && qTip[1] !== rTip[1]) {
      score -= 8;
    }

    // Prefer exact or nearest model year on car.ir
    if (row.year !== null) {
      const yearGap = Math.abs(row.year - targetYear);
      score -= Math.min(yearGap * 0.6, 6);
    }

    if (score > bestScore && score >= 2) {
      bestScore = score;
      bestRow = row;
    }
  }

  if (!bestRow) return null;

  let adjustedAvg = bestRow.marketPrice;
  if (bestRow.year !== null && bestRow.year !== targetYear) {
    const diff = bestRow.year - targetYear;
    // Adjust ~5.2% per year difference from the listed model year
    const factor = diff > 0 ? Math.max(0.45, 1 - diff * 0.052) : Math.min(1.45, 1 + Math.abs(diff) * 0.052);
    adjustedAvg = Math.round((bestRow.marketPrice * factor) / 1_000_000) * 1_000_000;
  }

  return {
    avg: adjustedAvg,
    min: Math.round((adjustedAvg * 0.94) / 1_000_000) * 1_000_000,
    max: Math.round((adjustedAvg * 1.06) / 1_000_000) * 1_000_000,
    matchedName: bestRow.name,
  };
}

async function fetchDivarAveragePrice(
  modelName: string,
  targetYear: number
): Promise<{ avg: number; min: number; max: number; sampleCount: number } | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    // Strip parenthetical trim notes to get cleaner Divar search results
    const cleanQuery = modelName.replace(/\([^)]*\)/g, '').replace(/\s+/g, ' ').trim();
    const searchUrl = `https://divar.ir/s/iran/car?q=${encodeURIComponent(`${cleanQuery} ${targetYear}`)}`;
    const response = await fetch(searchUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.8',
      },
    });
    if (!response.ok) return null;

    const html = await response.text();
    const rawPrices: number[] = [];

    // 1. Parse Divar SSR __PRELOADED_STATE__ widgets when hydrated
    const preloadedMatch = html.match(/window\.__PRELOADED_STATE__\s*=\s*(\{[\s\S]*?\});/);
    if (preloadedMatch) {
      try {
        const state = JSON.parse(preloadedMatch[1]);
        const widgets = state?.nb?.listWidgets || [];
        for (const w of widgets) {
          const title = String(w?.data?.title || '');
          const desc = String(w?.data?.middle_description_text || w?.data?.top_description_text || '');
          if (!title && !desc) continue;
          // Skip installment / swap / salvage / down-payment ads
          if (/اقساط|قسطی|پیش\s*پرداخت|معاوضه|حواله|تصادفی|اوراقی|چپی|اسقاطی|کلکسیونی|کارتکس/.test(`${title} ${desc}`)) {
            continue;
          }
          const priceVal = parseTomanCell(desc);
          if (priceVal && priceVal >= 180_000_000 && priceVal <= 60_000_000_000) {
            rawPrices.push(priceVal);
          }
        }
      } catch {
        // Fallback to visible HTML scan below
      }
    }

    // 2. Fallback scan of rendered SSR HTML (scripts stripped to prevent double-counting JSON state)
    if (rawPrices.length < 3) {
      const visibleHtml = html.replace(/<script[\s\S]*?<\/script>/gi, ' ');
      const matches = [...visibleHtml.matchAll(/([0-9۰-۹]{1,3}(?:[,٬][0-9۰-۹]{3}){2,3})\s*تومان/g)];
      for (const m of matches) {
        const idx = m.index ?? 0;
        const cardContext = visibleHtml
          .slice(Math.max(0, idx - 450), Math.min(visibleHtml.length, idx + 150))
          .replace(/<[^>]+>/g, ' ');
        if (/اقساط|قسطی|پیش\s*پرداخت|معاوضه|حواله|تصادفی|اوراقی|چپی|اسقاطی|کلکسیونی|کارتکس/.test(cardContext)) {
          continue;
        }
        const val = parseTomanCell(m[1]);
        if (val && val >= 180_000_000 && val <= 60_000_000_000) {
          rawPrices.push(val);
        }
      }
    }

    if (rawPrices.length < 3) return null;

    // Sort and compute median to strip installment down-payments & extreme outliers
    const sorted = [...rawPrices].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    const filtered = sorted.filter((p) => p >= median * 0.65 && p <= median * 1.45);
    if (filtered.length < 3) return null;

    const sum = filtered.reduce((acc, p) => acc + p, 0);
    const avg = Math.round(sum / filtered.length / 1_000_000) * 1_000_000;
    const min = Math.round(filtered[0] / 1_000_000) * 1_000_000;
    const max = Math.round(filtered[filtered.length - 1] / 1_000_000) * 1_000_000;

    return { avg, min, max, sampleCount: filtered.length };
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function applyYearFactor(base1405: number, queryYear: number): { min: number; max: number; avg: number } {
  const yearDiff = 1405 - queryYear;
  let factor = 1.0;
  if (yearDiff > 0) {
    factor = Math.max(0.32, 1.0 - yearDiff * 0.055);
  } else if (yearDiff < 0) {
    factor = 1.0 + Math.abs(yearDiff) * 0.07;
  }

  const avg = Math.round((base1405 * factor) / 1_000_000) * 1_000_000;
  const min = Math.round((avg * 0.95) / 1_000_000) * 1_000_000;
  const max = Math.round((avg * 1.05) / 1_000_000) * 1_000_000;
  return { min, max, avg };
}

// Comprehensive IranJib (iranjib.ir) & Discontinued Used-Market Price Matrix (1405 Baseline)
function getOfflineCarPriceEstimate(modelName: string, year: number): { min: number; max: number; avg: number } {
  const norm = normalizeCarText(modelName).replace(/\s+/g, '');
  let base1405 = 2_800_000_000; // default average in Tomans

  // Iran Khodro (ایران خودرو)
  if (/207پانورامااتومات|207اتوماتپانوراما/.test(norm)) base1405 = 4_500_000_000;
  else if (/207اتومات/.test(norm)) base1405 = 4_150_000_000;
  else if (/207دندهپانوراما|207پانوراما/.test(norm)) base1405 = 3_420_000_000;
  else if (/207برقی|207سقففلزی/.test(norm)) base1405 = 3_070_000_000;
  else if (/207tu3|207تیپ3/.test(norm)) base1405 = 2_660_000_000;
  else if (/207هیدرولیک|207دنده|207/.test(norm)) base1405 = 2_870_000_000;
  else if (/206تیپ5/.test(norm)) base1405 = 2_150_000_000;
  else if (/206تیپ2|206/.test(norm)) base1405 = 1_850_000_000;
  else if (/دناپلاساتومات|دناتوربواتومات|دناآپشنال/.test(norm)) base1405 = 4_430_000_000;
  else if (/دناپلاس6سرعته|دناپلاسmt6|دناپلاستوربو/.test(norm)) base1405 = 3_310_000_000;
  else if (/دناپلاس|دنا/.test(norm)) base1405 = 3_200_000_000;
  else if (/تارااتومات|تاراv4|تاراv2/.test(norm)) base1405 = 4_320_000_000;
  else if (/تارادستی|تاراv1|تارا/.test(norm)) base1405 = 3_200_000_000;
  else if (/راناپلاسپانوراما/.test(norm)) base1405 = 2_650_000_000;
  else if (/راناپلاس|رانا/.test(norm)) base1405 = 2_470_000_000;
  else if (/سورنپلاس|سورنtu5/.test(norm)) base1405 = 3_090_000_000;
  else if (/سورن/.test(norm)) base1405 = 2_550_000_000;
  else if (/پارسtu5/.test(norm)) base1405 = 2_780_000_000;
  else if (/پارسسال|پارس/.test(norm)) base1405 = 2_450_000_000;
  else if (/405/.test(norm)) base1405 = 1_750_000_000;
  else if (/سمندlx|سمند/.test(norm)) base1405 = 1_950_000_000;
  else if (/ریرا/.test(norm)) base1405 = 5_550_000_000;
  else if (/هایما8s/.test(norm)) base1405 = 8_250_000_000;
  else if (/هایماs7/.test(norm)) base1405 = 7_290_000_000;
  else if (/هایماs5|هایما/.test(norm)) base1405 = 6_020_000_000;

  // Saipa (سایپا و پارس خودرو)
  else if (/شاهینپلاساتومات|شاهیناتوماتپلاس/.test(norm)) base1405 = 4_090_000_000;
  else if (/شاهیناتومات|شاهینcvt/.test(norm)) base1405 = 3_405_000_000;
  else if (/شاهینg|شاهین/.test(norm)) base1405 = 3_115_000_000;
  else if (/اطلساتومات/.test(norm)) base1405 = 3_020_000_000;
  else if (/اطلسg/.test(norm)) base1405 = 2_180_000_000;
  else if (/اطلسgl|اطلسs|اطلس/.test(norm)) base1405 = 1_857_000_000;
  else if (/سهندe|سهنداتومات/.test(norm)) base1405 = 2_970_000_000;
  else if (/سهند/.test(norm)) base1405 = 1_935_000_000;
  else if (/ساینااتومات|سایناپلاس/.test(norm)) base1405 = 2_150_000_000;
  else if (/ساینا/.test(norm)) base1405 = 1_782_000_000;
  else if (/کوییکاتومات/.test(norm)) base1405 = 2_350_000_000;
  else if (/کوییکgxr/.test(norm)) base1405 = 1_855_000_000;
  else if (/کوییکgx|کوییکs|کوییکrs|کوییکr|کوییک/.test(norm)) base1405 = 1_782_000_000;
  else if (/پراید151|وانتپراید/.test(norm)) base1405 = 1_683_000_000;
  else if (/پراید111|پراید131|پراید132|پراید/.test(norm)) base1405 = 1_250_000_000;
  else if (/تیبا2|تیبا/.test(norm)) base1405 = 1_550_000_000;
  else if (/نیسانتکسوز|نیساندوگانه|پادرا|زامیاد/.test(norm)) base1405 = 2_650_000_000;

  // Assembled & Chinese (مونتاژی و چینی)
  else if (/تندر|l90|ال90/.test(norm)) base1405 = 2_800_000_000;
  else if (/ساندرو/.test(norm)) base1405 = 3_300_000_000;
  else if (/جکj4/.test(norm)) base1405 = 2_900_000_000;
  else if (/جکs5|جک/.test(norm)) base1405 = 4_900_000_000;
  else if (/کیامسیj7|kmcj7/.test(norm)) base1405 = 7_370_000_000;
  else if (/کیامسیt8|kmct8/.test(norm)) base1405 = 6_200_000_000;
  else if (/لاماری/.test(norm)) base1405 = 8_190_000_000;
  else if (/فیدلیتی/.test(norm)) base1405 = 8_060_000_000;
  else if (/دیگنیتی/.test(norm)) base1405 = 8_100_000_000;
  else if (/آریزو6/.test(norm)) base1405 = 7_100_000_000;
  else if (/آریزو5|آریزو/.test(norm)) base1405 = 5_330_000_000;
  else if (/تیگو7|تیگو/.test(norm)) base1405 = 6_900_000_000;
  else if (/تیگو8/.test(norm)) base1405 = 12_500_000_000;
  else if (/اکستریم/.test(norm)) base1405 = 15_900_000_000;
  else if (/فونیکسfx|فونیکس/.test(norm)) base1405 = 7_800_000_000;
  else if (/امویامx22|mvmx22|x22/.test(norm)) base1405 = 2_950_000_000;
  else if (/امویامx33|mvmx33|x33/.test(norm)) base1405 = 4_430_000_000;
  else if (/برلیانس/.test(norm)) base1405 = 2_750_000_000;
  else if (/دانگفنگ|h30/.test(norm)) base1405 = 2_600_000_000;
  else if (/ریسپکت/.test(norm)) base1405 = 4_850_000_000;
  else if (/بسترن/.test(norm)) base1405 = 3_200_000_000;

  // Imported (وارداتی)
  else if (/سانتافه/.test(norm)) base1405 = 11_000_000_000;
  else if (/راو4|rav4/.test(norm)) base1405 = 14_000_000_000;
  else if (/کرولا/.test(norm)) base1405 = 9_500_000_000;
  else if (/تلیسمان/.test(norm)) base1405 = 9_800_000_000;
  else if (/جوک/.test(norm)) base1405 = 6_400_000_000;
  else if (/سوناتا|الانترا|اسپورتیج|سراتو|اپتیما/.test(norm)) base1405 = 8_800_000_000;

  return applyYearFactor(base1405, year);
}

// Generate Expert Fallback Inspection Analysis if Gemini unavailable / cooldown
function generateFallbackAnalysis(body: any): string {
  const {
    fairPrice,
    askingPrice,
    damagedChassis,
    technicalIssues,
  } = body;

  const hasChassisDamage = damagedChassis && damagedChassis.length > 0;
  const hasEngineIssue = technicalIssues?.engineReplaced;
  const hasRollover = technicalIssues?.rolledOver;

  let riskSection = '۱. تحلیل ریسک‌های خرید و ایمنی:\n';
  if (hasRollover) {
    riskSection += '⚠️ ریسک بسیار بحرانی: خودرو سابقه واژگونی و چپ‌کردگی دارد. تغییر هندسه ستون‌ها و کلاف سقف، مقاومت ایمنی خودرو را در تصادفات بعدی به شدت کاهش داده و ممکن است در سرعت‌های بالا با لرزش یا ناهماهنگی در زاویه چرخ‌ها مواجه شوید.\n';
  }
  if (hasChassisDamage) {
    riskSection += '⚠️ آسیب به ساختار شاسی و ستون‌ها ثبت شده است. آسیب در ریل‌های شاسی ممکن است باعث لاستیک‌سایی زودهنگام، کشش فرمان به یک سمت و ضعف ضربه‌گیری گردد.\n';
  }
  if (hasEngineIssue) {
    riskSection += '⚠️ سابقه تعویض کامل موتور ثبت شده است؛ حتماً درج شماره موتور جدید در برگه سبز راهور و استعلام اصالت فاکتور کارخانه یا نمایندگی را کنترل کنید.\n';
  }
  if (!hasChassisDamage && !hasRollover && !hasEngineIssue) {
    riskSection += '✅ ارزیابی ایمنی مثبت: اسکلت شاسی، ستون‌ها و شاکله اصلی خودرو سالم بوده و ریسک ایمنی ساختاری گزارش نشده است.\n';
  }

  let inspectionSection = '\n۲. نکات کلیدی که در بازدید حضوری با کارشناس حتماً باید تست و چک شوند:\n';
  inspectionSection += '• استفاده از ضخامت‌سنج رنگ دیجیتال برای تطبیق میکرون رنگ در کاپوت، گلگیرها و سقف.\n';
  inspectionSection += '• بررسی زیر اتاق روی جک هیدرولیک جهت چک کردن عدم جوشکاری یا موم‌کشی غیرفابریک در سرشاسی‌ها.\n';
  inspectionSection += '• اتصال دستگاه دیاگ تخصصی جهت تطبیق کارکرد واقعی در ECU با صفحه کیلومتر و خواندن خطاهای سنسور اکسیژن و گیربکس.\n';
  inspectionSection += '• تست درایو کوتاه جهت بررسی صدای جلوبندی در دست‌انداز و چک کردن عدم گیجی فرمان هنگام ترمزگیری ناگهانی.\n';

  let bargainingSection = '\n۳. استراتژی چانه زنی و پیشنهاد قیمت به فروشنده:\n';
  if (askingPrice && askingPrice > fairPrice) {
    const diff = askingPrice - fairPrice;
    bargainingSection += `• با توجه به قیمت منصفانه کارشناسی روز (${fairPrice.toLocaleString('fa-IR')} تومان)، قیمت فروشنده دارای حباب است. به فروشنده یادآور شوید که با توجه به مجموع افت‌های ثبت شده، تخفیف حداقل ${diff.toLocaleString('fa-IR')} تومانی شرط منصفانه بودن معامله است.\n`;
  } else {
    bargainingSection += '• قیمت اعلامی فروشنده به ارزش منصفانه کارشناسی نزدیک است. در صورت تایید سلامت فنی موتور و گیربکس در بازدید حضوری، با اخذ تخفیف جزئی بابت هزینه‌های سرویس اولیه، معامله مناسب ارزیابی می‌شود.\n';
  }

  return `${riskSection}${inspectionSection}${bargainingSection}`;
}

function withTimeout<T>(promise: Promise<T>, ms = 8000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error('Timeout')), ms)),
  ]);
}

function isQuotaError(err: any): boolean {
  const msg = String(err?.message || err || '');
  return err?.status === 429 || msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED');
}

// Endpoint: Fetch real-time market price (IranJib for active models, Divar/Bama/Car.ir/Hamrah average for used & discontinued models)
app.post('/api/car-price', async (req, res) => {
  const { modelName, year, forceRefresh } = req.body;
  if (!modelName || !year) {
    return res.status(400).json({ error: 'نام خودرو و سال تولید الزامی است.' });
  }

  const requestedYear = Number(year);
  const cacheKey = `${normalizeCarText(String(modelName))}__${requestedYear}`;

  if (!forceRefresh) {
    const cached = priceResponseCache.get(cacheKey);
    if (cached && Date.now() - cached.cachedAt < PRICE_RESPONSE_CACHE_TTL_MS) {
      return res.json({
        ...cached.payload,
        serverCacheHit: true,
      });
    }
  }

  const queryYear = requestedYear >= 1406 ? 1405 : requestedYear;
  const isNextYear = requestedYear >= 1406;

  // Step 1: Fetch live IranJib table (cached 30 min)
  const liveCache = await fetchIranJibLivePrices();
  const liveMatch = matchIranJibLiveRow(modelName, liveCache);

  // Step 2: Check whether this vehicle is discontinued (توقف تولید)
  const discontinuedInfo = detectDiscontinuedCar(modelName, queryYear, Boolean(liveMatch));
  const effectiveYear =
    discontinuedInfo.isDiscontinued && discontinuedInfo.lastProductionYear
      ? Math.min(queryYear, discontinuedInfo.lastProductionYear)
      : queryYear;

  const DISCONTINUED_NOTICE =
    'تولید این خودرو متوقف شده است؛ مبلغ نمایش‌داده‌شده «میانگین قیمت آگهی‌های بازار» استخراج‌شده از دیوار، باما و سایت‌های معتبر خودرو است و قیمت روز و دقیق کارخانه‌ای/صفر آن محسوب نمی‌شود.';

  // Active current-year production vehicle found directly on IranJib
  if (!discontinuedInfo.isDiscontinued && liveMatch && effectiveYear >= 1405) {
    const avg = liveMatch.marketPrice;
    const min = Math.round((avg * 0.97) / 1_000_000) * 1_000_000;
    const max = Math.round((avg * 1.03) / 1_000_000) * 1_000_000;
    const payload = {
      success: true,
      min,
      max,
      avg,
      date: liveCache?.dateLabel || 'به‌روزرسانی زنده از ایران‌جیب',
      note: `استعلام مستقیم از جدول قیمت روز ایران‌جیب (${liveMatch.name})`,
      sources: ['سایت تخصصی ایران‌جیب (iranjib.ir)', 'قیمت زنده بازار آزاد خودرو'],
      isNextYearFallback: isNextYear,
      effectiveYear,
      isDiscontinued: false,
      isEstimated: false,
    };
    priceResponseCache.set(cacheKey, { cachedAt: Date.now(), payload });
    return res.json(payload);
  }

  // Step 3: For discontinued cars or older used model years (< 1405), gather live platform averages in parallel
  const shouldFetchDivar = discontinuedInfo.isDiscontinued || effectiveYear < 1405;
  const [carIrCacheResult, divarStats] = await Promise.all([
    fetchCarIrPrices(),
    shouldFetchDivar ? fetchDivarAveragePrice(modelName, effectiveYear) : Promise.resolve(null),
  ]);
  const carIrMatch = matchCarIrRow(modelName, effectiveYear, carIrCacheResult);

  const weightedSamples: { avg: number; min: number; max: number; weight: number }[] = [];
  const collectedSources: string[] = [];

  if (divarStats) {
    weightedSamples.push({
      avg: divarStats.avg,
      min: divarStats.min,
      max: divarStats.max,
      weight: divarStats.sampleCount >= 5 ? 2.2 : 1.5,
    });
    collectedSources.push(`آگهی‌های دیوار (${divarStats.sampleCount.toLocaleString('fa-IR')} آگهی)`);
  }

  if (carIrMatch) {
    weightedSamples.push({
      avg: carIrMatch.avg,
      min: carIrMatch.min,
      max: carIrMatch.max,
      weight: 1.0,
    });
    collectedSources.push('پایگاه قیمت خودرو کار (car.ir)');
  }

  // Also include IranJib year-adjusted baseline as a mild anchor when available for active used models
  if (!discontinuedInfo.isDiscontinued && liveMatch) {
    const yearAdj = applyYearFactor(liveMatch.marketPrice, effectiveYear);
    weightedSamples.push({
      avg: yearAdj.avg,
      min: yearAdj.min,
      max: yearAdj.max,
      weight: 1.1,
    });
    collectedSources.push(`ایران‌جیب (${liveMatch.name} تعدیل‌یافته)`);
  }

  // Step 4: Try Gemini Search Grounding (Divar, Bama, Hamrah Mechanic, Karnameh) when not in cooldown
  let geminiDate: string | null = null;
  let geminiNote: string | null = null;

  if (ai && Date.now() >= geminiCooldownUntil) {
    try {
      const prompt = discontinuedInfo.isDiscontinued
        ? `شما کارشناس قیمت‌گذاری خودروهای کارکرده و توقف تولید در بازار ایران هستید.
تولید خودروی «${modelName}» متوقف شده است. لطفاً آگهی‌های فعال و قیمت‌های معامله‌شده مدل سال ${effectiveYear} شمسی این خودرو را در پلتفرم دیوار (divar.ir)، باما (bama.ir)، همراه مکانیک (hamrah-mechanic.com)، کارنامه (karnameh.com) و کار (car.ir) جستجو کرده و «میانگین قیمت بازار» آن را بر حسب تومان استخراج کنید.

خروجی شما باید منحصراً یک شیء JSON با ساختار زیر باشد و هیچ متن اضافی قبل یا بعد از آن ننویسید:
{
  "min": عدد حداقل قیمت معقول آگهی‌ها به تومان (عدد صحیح بدون کاما),
  "max": عدد حداکثر قیمت معقول آگهی‌ها به تومان (عدد صحیح بدون کاما),
  "avg": عدد میانگین قیمت در دیوار و سایت‌های خودرویی به تومان (عدد صحیح),
  "date": "بازه زمانی استعلام (مثلاً آبان ۱۴۰۵)",
  "note": "میانگین استخراج‌شده از آگهی‌های دیوار، باما و سایت‌های معتبر خودرو",
  "sources": ["دیوار (divar.ir)", "باما (bama.ir)", "همراه مکانیک", "کارنامه"]
}`
        : `شما کارشناس قیمت‌گذاری خودرو در بازار ایران هستید.
لطفاً آخرین قیمت روز بازار آزاد خودروی کارکرده/صفر «${modelName}» مدل سال ${effectiveYear} شمسی را بر اساس سایت ایران‌جیب (iranjib.ir) و آگهی‌های دیوار و باما استخراج نمایید.
قیمت‌ها را دقیقاً بر حسب «تومان» (نه ریال) تعیین کنید.

خروجی شما باید منحصراً یک شیء JSON با ساختار زیر باشد و هیچ متن اضافی قبل یا بعد از آن ننویسید:
{
  "min": عدد حداقل قیمت به تومان (عدد صحیح بدون کاما),
  "max": عدد حداکثر قیمت به تومان (عدد صحیح بدون کاما),
  "avg": عدد میانگین منطقی قیمت روز بازار آزاد به تومان (عدد صحیح),
  "date": "تاریخ گزارش به شمسی (مثلاً آبان ۱۴۰۵)",
  "note": "توضیح کوتاه درباره مبنای قیمت",
  "sources": ["سایت تخصصی ایران‌جیب (iranjib.ir)", "دیوار و باما"]
}`;

      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-4-hydrogen',
          contents: prompt,
          config: {
            tools: [{ googleSearch: {} }],
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          },
        }),
        8000
      );

      const rawText = response.text || '';
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      for (const chunk of groundingChunks) {
        if (chunk.web?.title) {
          collectedSources.push(chunk.web.title);
        } else if (chunk.web?.uri) {
          try {
            collectedSources.push(new URL(chunk.web.uri).hostname);
          } catch {
            // ignore
          }
        }
      }

      let cleaned = rawText.trim();
      if (cleaned.startsWith('```json')) {
        cleaned = cleaned.replace(/^```json\s*/, '').replace(/```\s*$/, '').trim();
      } else if (cleaned.startsWith('```')) {
        cleaned = cleaned.replace(/^```\s*/, '').replace(/```\s*$/, '').trim();
      }

      const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsedData = JSON.parse(jsonMatch[0]);
        const min = Number(parsedData.min) || 0;
        const max = Number(parsedData.max) || 0;
        const avg = Number(parsedData.avg) || Math.round((min + max) / 2) || 0;

        if (avg >= 50_000_000 && min > 0 && max >= min) {
          weightedSamples.push({ avg, min, max, weight: 1.4 });
          if (Array.isArray(parsedData.sources)) {
            collectedSources.push(...parsedData.sources);
          }
          geminiDate = parsedData.date || null;
          geminiNote = parsedData.note || null;
        }
      }
    } catch (error: any) {
      if (isQuotaError(error)) {
        geminiCooldownUntil = Date.now() + GEMINI_COOLDOWN_MS;
        console.log('[AutoScope] Gemini quota reached; switched to live web scrapers + baseline for 5m.');
      } else {
        console.log('[AutoScope] Grounding lookup bypassed, using live web scrapers / baseline fallback.');
      }
    }
  }

  // Step 5: Compute weighted averaged result across live sources (or fallback matrix if none succeeded)
  if (weightedSamples.length > 0) {
    const totalWeight = weightedSamples.reduce((acc, s) => acc + s.weight, 0);
    const avg =
      Math.round(
        weightedSamples.reduce((sum, s) => sum + s.avg * s.weight, 0) / totalWeight / 1_000_000
      ) * 1_000_000;
    const min =
      Math.round(
        weightedSamples.reduce((sum, s) => sum + s.min * s.weight, 0) / totalWeight / 1_000_000
      ) * 1_000_000;
    const max =
      Math.round(
        weightedSamples.reduce((sum, s) => sum + s.max * s.weight, 0) / totalWeight / 1_000_000
      ) * 1_000_000;

    const defaultSources = discontinuedInfo.isDiscontinued
      ? ['دیوار (divar.ir)', 'باما (bama.ir)', 'کار (car.ir)', 'همراه مکانیک']
      : ['سایت تخصصی ایران‌جیب (iranjib.ir)', 'بازار آزاد خودرو'];

    const uniqueSources = Array.from(new Set([...collectedSources, ...defaultSources])).filter(Boolean);

    const payload = {
      success: true,
      min: Math.min(min, avg),
      max: Math.max(max, avg),
      avg,
      date: geminiDate || liveCache?.dateLabel || 'آبان ۱۴۰۵ (میانگین بازار)',
      note: discontinuedInfo.isDiscontinued
        ? geminiNote || 'محاسبه میانگین وزن‌دار بر اساس آگهی‌های دیوار، باما و سایت‌های معتبر خودرو'
        : geminiNote || 'استعلام هوشمند و وزن‌دار از جداول قیمت بازار، دیوار و ایران‌جیب',
      sources: uniqueSources,
      sampleCount: divarStats?.sampleCount,
      isNextYearFallback: isNextYear,
      effectiveYear,
      isDiscontinued: discontinuedInfo.isDiscontinued,
      lastProductionYear: discontinuedInfo.lastProductionYear,
      discontinuedNotice: discontinuedInfo.isDiscontinued ? DISCONTINUED_NOTICE : undefined,
      isEstimated: false,
    };

    priceResponseCache.set(cacheKey, { cachedAt: Date.now(), payload });
    return res.json(payload);
  }

  // Step 6: Fallback using Live IranJib row (year-adjusted) or Baseline Matrix
  const estimate = liveMatch
    ? applyYearFactor(liveMatch.marketPrice, effectiveYear)
    : getOfflineCarPriceEstimate(modelName, effectiveYear);

  const fallbackPayload = {
    success: true,
    min: estimate.min,
    max: estimate.max,
    avg: estimate.avg,
    date: liveCache?.dateLabel || 'آبان ۱۴۰۵',
    note: discontinuedInfo.isDiscontinued
      ? 'میانگین برآوردشده از داده‌های بازار خودروهای کارکرده (دیوار، باما و همراه مکانیک)'
      : liveMatch
      ? `محاسبه‌شده بر اساس قیمت زنده صفر کیلومتر «${liveMatch.name}» در ایران‌جیب و تعدیل سال ساخت`
      : 'استخراج شده از جدول پایه قیمت خودروهای بازار آزاد ایران‌جیب (iranjib.ir)',
    sources: discontinuedInfo.isDiscontinued
      ? ['دیوار (divar.ir)', 'باما (bama.ir)', 'همراه مکانیک', 'کار (car.ir)']
      : ['سایت تخصصی ایران‌جیب (iranjib.ir)', 'جدول رسمی معاملات بازار آزاد خودرو'],
    isNextYearFallback: isNextYear,
    effectiveYear,
    isDiscontinued: discontinuedInfo.isDiscontinued,
    lastProductionYear: discontinuedInfo.lastProductionYear,
    discontinuedNotice: discontinuedInfo.isDiscontinued ? DISCONTINUED_NOTICE : undefined,
    isEstimated: !liveMatch,
  };

  priceResponseCache.set(cacheKey, { cachedAt: Date.now(), payload: fallbackPayload });
  return res.json(fallbackPayload);
});

// Endpoint: Smart AI car inspection assessment and bargaining tips
app.post('/api/car-analysis', async (req, res) => {
  try {
    const {
      carModel,
      year,
      mileage,
      basePrice,
      fairPrice,
      askingPrice,
      dealJudgment,
      damagedParts,
      damagedChassis,
      technicalIssues,
      labels,
    } = req.body;

    if (!ai || Date.now() < geminiCooldownUntil) {
      return res.json({
        success: true,
        analysis: generateFallbackAnalysis(req.body),
      });
    }

    const prompt = `شما یک کارشناس ارشد و باتجربه کارشناسی خودرو در بازار ایران هستید.
گزارش کارشناسی یک خودرو به شرح زیر برای شما ارسال شده است:
- مشخصات خودرو: ${carModel} مدل سال ${year} شمسی
- کارکرد: ${mileage} کیلومتر
- قیمت پایه بازار: ${basePrice} تومان
- قیمت منطقی محاسبه‌شده بر اساس خسارات: ${fairPrice} تومان
- قیمت پیشنهادی فروشنده: ${askingPrice ? askingPrice + ' تومان' : 'مشخص نشده'}
- ارزیابی وضعیت قیمت: ${dealJudgment}
- قطعات بدنه آسیب‌دیده/رنگ‌شده: ${damagedParts && damagedParts.length ? JSON.stringify(damagedParts) : 'کاملاً بدون رنگ و سالم'}
- وضعیت شاسی و ستون‌ها: ${damagedChassis && damagedChassis.length ? JSON.stringify(damagedChassis) : 'کاملاً سالم بدون آسیب'}
- سوابق فنی: تعویض موتور (${technicalIssues?.engineReplaced ? 'بله' : 'خیر'})، سابقه چپ کردن (${technicalIssues?.rolledOver ? 'بله' : 'خیر'})، ایربگ (${technicalIssues?.hasAirbag ? (technicalIssues?.airbagDeployed ? 'باز شده' : 'سالم') : 'ندارد'})
- برچسب‌های عمومی: ${labels && labels.length ? labels.join('، ') : 'عادی'}

لطفاً یک تحلیل جامع، صریح و تخصصی برای خریدار ارائه دهید شامل ۳ بخش با تیترهای مشخص:
۱. تحلیل ریسک‌های خرید و ایمنی (به‌خصوص با توجه به آسیب‌های شاسی و فنی)
۲. نکات کلیدی که در بازدید حضوری با کارشناس حتماً باید تست و چک شوند
۳. استراتژی چانه زنی و پیشنهاد قیمت به فروشنده

پاسخ را با لحن صمیمی اما کارشناسی، با نثر روان فارسی و به صورت ساختاریافته بنویسید.`;

    const response = await withTimeout(
      ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      }),
      8000
    );

    return res.json({
      success: true,
      analysis: response.text || generateFallbackAnalysis(req.body),
    });
  } catch (error: any) {
    if (isQuotaError(error)) {
      geminiCooldownUntil = Date.now() + GEMINI_COOLDOWN_MS;
      console.log('[AutoScope] Gemini quota reached during analysis; using expert offline analysis.');
    } else {
      console.log('[AutoScope] AI analysis fallback activated.');
    }
    return res.json({
      success: true,
      analysis: generateFallbackAnalysis(req.body),
    });
  }
});

// Vite Middleware for development / Static files for production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AutoScope server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
