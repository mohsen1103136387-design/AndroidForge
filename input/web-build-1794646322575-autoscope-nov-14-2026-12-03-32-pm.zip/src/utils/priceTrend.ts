import { gregorianToJalali, toPersianDigits, formatPersianNumber } from './persian';

export interface PricePoint {
  dayIndex: number; // 29 (30 days ago) to 0 (today)
  dateLabel: string; // e.g. "۱۲ مهر"
  fullDate: string; // e.g. "۱۲ مهر ۱۴۰۵"
  price: number;
}

export interface TrendAnalysis {
  points: PricePoint[];
  startPrice: number;
  currentPrice: number;
  minPrice: number;
  maxPrice: number;
  changeAmount: number;
  changePercent: number;
  isGrowth: boolean;
}

const PERSIAN_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

/**
 * Deterministic pseudo-random number based on a seed
 */
function seededRandom(seed: number): number {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

/**
 * Generate 30-day realistic price trend data points leading up to today's base price
 */
export function generate30DayPriceTrend(basePrice: number, carModel: string): TrendAnalysis {
  // Simple hash from car model name
  let hash = 0;
  for (let i = 0; i < carModel.length; i++) {
    hash = (hash << 5) - hash + carModel.charCodeAt(i);
    hash |= 0;
  }
  const baseSeed = Math.abs(hash);

  const totalDays = 30;
  const points: PricePoint[] = [];
  const now = new Date();

  // Create smooth fluctuations that end exactly at basePrice today (dayOffset = 0)
  // Overall 30-day trend drift factor (-1.5% to +3.5%)
  const overallTrendFactor = (seededRandom(baseSeed) * 0.04) - 0.01;

  for (let i = totalDays - 1; i >= 0; i--) {
    const pastDate = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const [jy, jm, jd] = gregorianToJalali(
      pastDate.getFullYear(),
      pastDate.getMonth() + 1,
      pastDate.getDate()
    );

    const dateLabel = `${toPersianDigits(jd)} ${PERSIAN_MONTHS[jm - 1]}`;
    const fullDate = `${toPersianDigits(jd)} ${PERSIAN_MONTHS[jm - 1]} ${toPersianDigits(jy)}`;

    if (i === 0) {
      // Exactly today's price
      points.push({
        dayIndex: i,
        dateLabel: 'امروز',
        fullDate,
        price: basePrice,
      });
    } else {
      // Day progress from 0 (30 days ago) to 1 (yesterday)
      const progress = (totalDays - 1 - i) / (totalDays - 1);
      
      // Multi-frequency wave for natural market movement
      const wave1 = Math.sin((i + (baseSeed % 7)) * 0.35) * 0.012;
      const wave2 = Math.cos((i + (baseSeed % 11)) * 0.6) * 0.008;
      
      // Target deviation from current price
      // As i approaches 0, deviation approaches 0
      const drift = (1 - progress) * (-overallTrendFactor);
      const noise = (wave1 + wave2) * (i / totalDays);
      const multiplier = 1 + drift + noise;

      // Round to nearest 1,000,000 Tomans for realistic Iranian market pricing
      const estimatedPrice = Math.round((basePrice * multiplier) / 1000000) * 1000000;

      points.push({
        dayIndex: i,
        dateLabel,
        fullDate,
        price: Math.max(10000000, estimatedPrice),
      });
    }
  }

  const prices = points.map((p) => p.price);
  const startPrice = prices[0];
  const currentPrice = prices[prices.length - 1];
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const changeAmount = currentPrice - startPrice;
  const changePercent = startPrice > 0 ? Number(((changeAmount / startPrice) * 100).toFixed(1)) : 0;
  const isGrowth = changeAmount >= 0;

  return {
    points,
    startPrice,
    currentPrice,
    minPrice,
    maxPrice,
    changeAmount,
    changePercent,
    isGrowth,
  };
}
