import { User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
  Unsubscribe,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { AppraisalRecord } from '../types';

function stripUndefinedDeep<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((item) => stripUndefinedDeep(item)) as unknown as T;
  }
  if (value !== null && typeof value === 'object') {
    const cleaned: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v !== undefined) {
        cleaned[k] = stripUndefinedDeep(v);
      }
    }
    return cleaned as T;
  }
  return value;
}

function sanitizeRecordId(id: string): string {
  const cleaned = id.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128);
  return cleaned || `rec_${Date.now()}`;
}

export interface UpsertProfileResult {
  theme?: 'dark' | 'light';
}

export async function upsertUserProfile(
  user: User,
  currentTheme: 'dark' | 'light'
): Promise<UpsertProfileResult> {
  const path = `users/${user.uid}`;
  const userRef = doc(db, 'users', user.uid);

  let snap;
  try {
    snap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }

  const displayName = (user.displayName?.trim() || 'کاربر اتو اسکوپ').slice(0, 100);
  const email = (user.email?.trim() || 'user@autoscope.ir').slice(0, 200);
  const photoURL = user.photoURL?.trim() ? user.photoURL.trim().slice(0, 500) : undefined;

  if (!snap.exists()) {
    const createPayload: Record<string, unknown> = {
      uid: user.uid,
      displayName,
      email,
      theme: currentTheme,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      lastLoginAt: serverTimestamp(),
    };
    if (photoURL) {
      createPayload.photoURL = photoURL;
    }

    try {
      await setDoc(userRef, createPayload);
      return { theme: currentTheme };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  } else {
    const existingData = snap.data();
    const updatePayload: Record<string, unknown> = {
      displayName,
      email,
      lastLoginAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (photoURL) {
      updatePayload.photoURL = photoURL;
    }

    try {
      await updateDoc(userRef, updatePayload);
      const savedTheme = existingData?.theme === 'light' || existingData?.theme === 'dark'
        ? (existingData.theme as 'dark' | 'light')
        : currentTheme;
      return { theme: savedTheme };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }
}

export async function updateUserTheme(
  uid: string,
  theme: 'dark' | 'light'
): Promise<void> {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      theme,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

function buildAppraisalPayload(uid: string, record: AppraisalRecord) {
  const safeId = sanitizeRecordId(record.id);
  const safeYear = Math.min(1450, Math.max(1340, Math.round(Number(record.year) || 1400)));
  const safeMileage = Math.min(2000000, Math.max(0, Math.round(Number(record.mileage) || 0)));
  const safeBasePrice = Math.max(1, Number(record.basePrice) || 1);

  const safeResult = stripUndefinedDeep({
    ...record.result,
    rows: Array.isArray(record.result?.rows) ? record.result.rows.slice(0, 50) : [],
  });

  const payload: Record<string, unknown> = {
    id: safeId,
    ownerId: uid,
    carModel: (record.carModel?.trim() || 'خودرو').slice(0, 150),
    year: safeYear,
    mileage: safeMileage,
    basePrice: safeBasePrice,
    bodyParts: stripUndefinedDeep(record.bodyParts || {}),
    chassisParts: stripUndefinedDeep(record.chassisParts || {}),
    technical: stripUndefinedDeep(record.technical || {}),
    labels: Array.isArray(record.labels)
      ? record.labels.slice(0, 10).map((l) => String(l).slice(0, 50))
      : [],
    result: safeResult,
    savedAt: (record.savedAt || new Date().toISOString()).slice(0, 64),
    shamsiDate: (record.shamsiDate || 'نامشخص').slice(0, 64),
    trackingCode: (record.trackingCode || 'AS-000000').slice(0, 32),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (
    typeof record.sellerPrice === 'number' &&
    !Number.isNaN(record.sellerPrice) &&
    record.sellerPrice >= 0
  ) {
    payload.sellerPrice = record.sellerPrice;
  }

  if (record.dayPriceInfo && typeof record.dayPriceInfo === 'object') {
    payload.dayPriceInfo = stripUndefinedDeep(record.dayPriceInfo);
  }

  return { safeId, payload };
}

export async function saveAppraisalToCloud(
  uid: string,
  record: AppraisalRecord
): Promise<void> {
  const { safeId, payload } = buildAppraisalPayload(uid, record);
  const path = `users/${uid}/appraisals/${safeId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'appraisals', safeId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function syncLocalHistoryToCloud(
  uid: string,
  localRecords: AppraisalRecord[]
): Promise<number> {
  if (!localRecords || localRecords.length === 0) return 0;

  const colPath = `users/${uid}/appraisals`;
  const q = query(
    collection(db, 'users', uid, 'appraisals'),
    where('ownerId', '==', uid),
    limit(50)
  );

  let existingSnap;
  try {
    existingSnap = await getDocs(q);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, colPath);
  }

  const existingIds = new Set<string>(existingSnap.docs.map((d) => d.id));
  const missingRecords = localRecords
    .filter((r) => !existingIds.has(sanitizeRecordId(r.id)))
    .slice(0, 50);

  if (missingRecords.length === 0) return 0;

  try {
    const batch = writeBatch(db);
    for (const rec of missingRecords) {
      const { safeId, payload } = buildAppraisalPayload(uid, rec);
      batch.set(doc(db, 'users', uid, 'appraisals', safeId), payload);
    }
    await batch.commit();
    return missingRecords.length;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, colPath);
  }
}

export function subscribeUserAppraisals(
  uid: string,
  onData: (records: AppraisalRecord[]) => void,
  onError?: (err: unknown) => void
): Unsubscribe {
  const colPath = `users/${uid}/appraisals`;
  const q = query(
    collection(db, 'users', uid, 'appraisals'),
    where('ownerId', '==', uid),
    limit(50)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: AppraisalRecord[] = snapshot.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: String(d.id || docSnap.id),
          carModel: String(d.carModel || ''),
          year: Number(d.year || 1400),
          mileage: Number(d.mileage || 0),
          basePrice: Number(d.basePrice || 0),
          sellerPrice: typeof d.sellerPrice === 'number' ? d.sellerPrice : undefined,
          bodyParts: d.bodyParts,
          chassisParts: d.chassisParts,
          technical: d.technical,
          labels: Array.isArray(d.labels) ? d.labels : [],
          result: d.result,
          dayPriceInfo: d.dayPriceInfo ?? null,
          savedAt: String(d.savedAt || ''),
          shamsiDate: String(d.shamsiDate || ''),
          trackingCode: String(d.trackingCode || ''),
        };
      });

      items.sort((a, b) => b.savedAt.localeCompare(a.savedAt));
      onData(items);
    },
    (error) => {
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, colPath);
    }
  );
}

export async function deleteAppraisalFromCloud(
  uid: string,
  id: string
): Promise<void> {
  const safeId = sanitizeRecordId(id);
  const path = `users/${uid}/appraisals/${safeId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'appraisals', safeId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function clearUserAppraisalsFromCloud(
  uid: string,
  ids: string[]
): Promise<void> {
  if (!ids.length) return;
  const colPath = `users/${uid}/appraisals`;
  try {
    const batch = writeBatch(db);
    for (const id of ids) {
      const safeId = sanitizeRecordId(id);
      batch.delete(doc(db, 'users', uid, 'appraisals', safeId));
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, colPath);
  }
}

