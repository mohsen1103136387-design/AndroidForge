/**
 * Persian number and date utilities
 */

const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const ARABIC_DIGITS = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

/**
 * Converts English and Arabic numbers to Persian digits
 */
export function toPersianDigits(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return '';
  const str = input.toString();
  return str
    .replace(/[0-9]/g, (w) => PERSIAN_DIGITS[+w])
    .replace(/[٠-٩]/g, (w) => PERSIAN_DIGITS[ARABIC_DIGITS.indexOf(w)]);
}

/**
 * Converts Persian and Arabic digits in a string to standard English digits
 */
export function toEnglishDigits(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return '';
  let str = input.toString();
  for (let i = 0; i < 10; i++) {
    str = str.replace(new RegExp(PERSIAN_DIGITS[i], 'g'), i.toString());
    str = str.replace(new RegExp(ARABIC_DIGITS[i], 'g'), i.toString());
  }
  return str;
}

/**
 * Cleans string to raw integer number
 */
export function parseNumberInput(input: string): number {
  const english = toEnglishDigits(input).replace(/[^0-9]/g, '');
  if (!english) return 0;
  return parseInt(english, 10);
}

/**
 * Formats a number with Persian thousands separators (٬) and Persian digits
 */
export function formatPersianNumber(value: number | string): string {
  if (value === null || value === undefined || value === '') return '۰';
  const num = typeof value === 'number' ? value : parseNumberInput(value);
  if (isNaN(num)) return '۰';
  const parts = Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
  return toPersianDigits(parts);
}

/**
 * Formats currency amount in Tomans (e.g. «۶۵۰٬۰۰۰٬۰۰۰ تومان»)
 */
export function formatToman(value: number | string): string {
  return `${formatPersianNumber(value)} تومان`;
}

/**
 * Convert Gregorian date to Jalali (Shamsi) date
 */
export function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy: number;
  let gy2 = (gm > 2) ? (gy + 1) : gy;
  let days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
  jy = -1595 + (33 * Math.floor(days / 12053));
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let jm: number;
  let jd: number;
  if (days < 186) {
    jm = 1 + Math.floor(days / 31);
    jd = 1 + (days % 31);
  } else {
    jm = 7 + Math.floor((days - 186) / 30);
    jd = 1 + ((days - 186) % 30);
  }
  return [jy, jm, jd];
}

const PERSIAN_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

/**
 * Get current Shamsi year from system date
 */
export function getCurrentShamsiYear(): number {
  const now = new Date();
  const [jy] = gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  return jy;
}

/**
 * Get formatted current Shamsi date string, e.g. «۱۹ آبان ۱۴۰۵»
 */
export function getFormattedCurrentShamsiDate(dateObj: Date = new Date()): string {
  const [jy, jm, jd] = gregorianToJalali(
    dateObj.getFullYear(),
    dateObj.getMonth() + 1,
    dateObj.getDate()
  );
  return `${toPersianDigits(jd)} ${PERSIAN_MONTHS[jm - 1]} ${toPersianDigits(jy)}`;
}

/**
 * Generate a unique Persian tracking code for appraisal reports
 */
export function generateTrackingCode(): string {
  const random = Math.floor(100000 + Math.random() * 900000);
  return `AS-${random}`;
}
