import * as THREE from 'three';
import type { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

export interface WebGLCapabilitiesProbe {
  supported: boolean;
  isSoftwareGl: boolean;
}

/**
 * Safely probes WebGL support and whether the renderer is software-emulated
 * (SwiftShader / llvmpipe / Basic Render) without leaking a WebGL context.
 */
export function detectSoftwareWebGL(): WebGLCapabilitiesProbe {
  if (typeof document === 'undefined') {
    return { supported: false, isSoftwareGl: false };
  }

  const canvas = document.createElement('canvas');
  const gl =
    (canvas.getContext('webgl2') as WebGL2RenderingContext | null) ||
    (canvas.getContext('webgl') as WebGLRenderingContext | null);

  if (!gl) {
    return { supported: false, isSoftwareGl: false };
  }

  let isSoftwareGl = false;
  try {
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    isSoftwareGl = /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    isSoftwareGl = false;
  } finally {
    try {
      gl.getExtension('WEBGL_lose_context')?.loseContext();
    } catch {
      // Ignore if extension is unavailable
    }
  }

  return { supported: true, isSoftwareGl };
}

/**
 * Creates a procedural radial showroom floor texture (zero external network fetches)
 * with subtle concentric inspection rings and proper sRGB color space.
 */
export function createStudioFloorTexture(
  anisotropy: number = 4,
  accentHex: string = '#38bdf8'
): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;

  const ctx = canvas.getContext('2d');
  if (ctx) {
    const cx = size / 2;
    const cy = size / 2;

    // Deep slate base
    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, size, size);

    // Subtle radial spotlight gradient
    const radial = ctx.createRadialGradient(cx, cy, 12, cx, cy, size * 0.48);
    radial.addColorStop(0, 'rgba(56, 189, 248, 0.16)');
    radial.addColorStop(0.35, 'rgba(30, 41, 59, 0.45)');
    radial.addColorStop(0.75, 'rgba(11, 17, 32, 0.92)');
    radial.addColorStop(1, 'rgba(7, 11, 20, 1)');
    ctx.fillStyle = radial;
    ctx.fillRect(0, 0, size, size);

    // Subtle tech grid lines
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.06)';
    ctx.lineWidth = 1;
    const step = size / 16;
    for (let i = step; i < size; i += step) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, size);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(size, i);
      ctx.stroke();
    }

    // Concentric turntable rings
    const ringRadii = [size * 0.22, size * 0.34, size * 0.43];
    ringRadii.forEach((radius, idx) => {
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.strokeStyle = idx === 1 ? `${accentHex}38` : 'rgba(148, 163, 184, 0.14)';
      ctx.lineWidth = idx === 1 ? 2 : 1;
      if (idx === 2) {
        ctx.setLineDash([8, 10]);
      } else {
        ctx.setLineDash([]);
      }
      ctx.stroke();
    });
    ctx.setLineDash([]);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = Math.max(1, anisotropy);
  texture.needsUpdate = true;
  return texture;
}

const TEXTURE_SLOTS = [
  'map',
  'normalMap',
  'roughnessMap',
  'metalnessMap',
  'aoMap',
  'emissiveMap',
  'alphaMap',
  'envMap',
  'bumpMap',
  'displacementMap',
  'lightMap',
  'clearcoatMap',
  'clearcoatRoughnessMap',
  'clearcoatNormalMap',
  'specularMap',
  'specularColorMap',
  'specularIntensityMap',
  'thicknessMap',
  'transmissionMap',
  'sheenColorMap',
  'sheenRoughnessMap',
  'iridescenceMap',
  'iridescenceThicknessMap',
  'anisotropyMap',
  'gradientMap',
] as const;

/**
 * Disposes every unique texture attached to a material.
 */
export function disposeMaterialTextures(
  material: THREE.Material,
  disposedTextures: Set<THREE.Texture>
): void {
  const record = material as unknown as Record<string, unknown>;
  for (const slot of TEXTURE_SLOTS) {
    const candidate = record[slot];
    if (candidate instanceof THREE.Texture && !disposedTextures.has(candidate)) {
      candidate.dispose();
      disposedTextures.add(candidate);
    }
  }
}

export interface DisposeThreeSceneOptions {
  scene: THREE.Scene;
  renderer: THREE.WebGLRenderer;
  controls?: OrbitControls | null;
  extraGeometries?: THREE.BufferGeometry[];
  extraMaterials?: THREE.Material[];
  extraTextures?: THREE.Texture[];
}

/**
 * Thoroughly disposes all Geometries, Materials, Textures (including PMREM environment),
 * OrbitControls, render lists, and WebGLRenderer resources on unmount to prevent mobile GPU memory leaks.
 */
export function disposeThreeScene({
  scene,
  renderer,
  controls,
  extraGeometries = [],
  extraMaterials = [],
  extraTextures = [],
}: DisposeThreeSceneOptions): void {
  const disposedGeometries = new Set<THREE.BufferGeometry>();
  const disposedMaterials = new Set<THREE.Material>();
  const disposedTextures = new Set<THREE.Texture>();

  // 1. Dispose OrbitControls DOM/pointer listeners
  if (controls) {
    controls.dispose();
  }

  // 2. Traverse scene graph and collect + dispose all geometries, materials, and attached textures
  scene.traverse((object) => {
    const renderable = object as THREE.Object3D & {
      geometry?: THREE.BufferGeometry;
      material?: THREE.Material | THREE.Material[];
    };

    if (renderable.geometry && !disposedGeometries.has(renderable.geometry)) {
      renderable.geometry.dispose();
      disposedGeometries.add(renderable.geometry);
    }

    if (renderable.material) {
      const materials = Array.isArray(renderable.material)
        ? renderable.material
        : [renderable.material];

      for (const mat of materials) {
        if (!mat) continue;
        disposeMaterialTextures(mat, disposedTextures);
        if (!disposedMaterials.has(mat)) {
          mat.dispose();
          disposedMaterials.add(mat);
        }
      }
    }
  });

  // 3. Dispose scene-level environment / background textures (e.g. RoomEnvironment PMREM)
  if (scene.environment instanceof THREE.Texture && !disposedTextures.has(scene.environment)) {
    scene.environment.dispose();
    disposedTextures.add(scene.environment);
  }
  scene.environment = null;

  if (scene.background instanceof THREE.Texture && !disposedTextures.has(scene.background)) {
    scene.background.dispose();
    disposedTextures.add(scene.background);
  }

  // 4. Dispose any manually tracked off-graph resources
  for (const geo of extraGeometries) {
    if (geo && !disposedGeometries.has(geo)) {
      geo.dispose();
      disposedGeometries.add(geo);
    }
  }

  for (const mat of extraMaterials) {
    if (!mat) continue;
    disposeMaterialTextures(mat, disposedTextures);
    if (!disposedMaterials.has(mat)) {
      mat.dispose();
      disposedMaterials.add(mat);
    }
  }

  for (const tex of extraTextures) {
    if (tex && !disposedTextures.has(tex)) {
      tex.dispose();
      disposedTextures.add(tex);
    }
  }

  // 5. Clear scene graph & dispose renderer internal caches + WebGL context
  scene.clear();
  renderer.renderLists?.dispose();
  renderer.dispose();

  const domEl = renderer.domElement;
  if (domEl && domEl.parentNode) {
    domEl.parentNode.removeChild(domEl);
  }
}
