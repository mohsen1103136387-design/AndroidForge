import { DayPriceInfo } from '../types';
import { STORAGE_CONFIG } from './config';
import { toEnglishDigits } from './persian';
import { getCachedDayPrice, setCachedDayPrice } from './storage';

const DB_NAME = 'AutoScopePriceCacheDB';
const DB_VERSION = 1;
const STORE_NAME = 'day_prices';

interface PriceCacheRecord {
  cacheKey: string;
  modelName: string;
  year: number;
  data: DayPriceInfo;
  cachedAt: number;
}

/**
 * Normalize model name + year into a consistent cache key regardless of Persian/Arabic digits or ZWNJ
 */
export function buildPriceCacheKey(modelName: string, year: number): string {
  const normalized = toEnglishDigits(modelName)
    .toLowerCase()
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\s\u200c()\[\]\/\-_.،,]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return `${normalized}__${year}`;
}

function openPriceCacheDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }

  return new Promise((resolve) => {
    try {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'cacheKey' });
          store.createIndex('cachedAt', 'cachedAt', { unique: false });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
      request.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

/**
 * Check IndexedDB first for a valid price entry (< 6 hours old) before querying backend/Gemini/Search.
 * Falls back cleanly to localStorage if IndexedDB is blocked or unavailable.
 */
export async function getCachedDayPriceAsync(
  modelName: string,
  year: number
): Promise<DayPriceInfo | null> {
  const cacheKey = buildPriceCacheKey(modelName, year);
  const ttlMs = STORAGE_CONFIG.PRICE_CACHE_TTL_MS;
  const db = await openPriceCacheDb();

  if (!db) {
    const legacy = getCachedDayPrice(modelName, year);
    return legacy ? { ...legacy, fromLocalCache: true } : null;
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const getReq = store.get(cacheKey);

      getReq.onsuccess = () => {
        const record = getReq.result as PriceCacheRecord | undefined;
        if (!record || !record.cachedAt) {
          db.close();
          resolve(null);
          return;
        }

        const ageMs = Date.now() - record.cachedAt;
        if (ageMs >= ttlMs) {
          // Expired: purge stale record from IndexedDB
          try {
            store.delete(cacheKey);
          } catch {
            // ignore cleanup error
          }
          db.close();
          resolve(null);
          return;
        }

        db.close();
        resolve({
          ...record.data,
          cachedAt: record.cachedAt,
          fromLocalCache: true,
        });
      };

      getReq.onerror = () => {
        db.close();
        const legacy = getCachedDayPrice(modelName, year);
        resolve(legacy ? { ...legacy, fromLocalCache: true } : null);
      };
    } catch {
      try {
        db.close();
      } catch {
        // ignore
      }
      const legacy = getCachedDayPrice(modelName, year);
      resolve(legacy ? { ...legacy, fromLocalCache: true } : null);
    }
  });
}

/**
 * Persist fetched market price into IndexedDB (with 6-hour TTL metadata) and mirror to localStorage fallback.
 */
export async function setCachedDayPriceAsync(
  modelName: string,
  year: number,
  info: DayPriceInfo
): Promise<void> {
  const now = Date.now();
  const payload: DayPriceInfo = {
    ...info,
    cachedAt: now,
    fromLocalCache: false,
  };

  // Mirror to localStorage fallback
  setCachedDayPrice(modelName, year, payload);

  const db = await openPriceCacheDb();
  if (!db) return;

  const cacheKey = buildPriceCacheKey(modelName, year);
  const record: PriceCacheRecord = {
    cacheKey,
    modelName,
    year,
    data: payload,
    cachedAt: now,
  };

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.put(record);
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        resolve();
      };
    } catch {
      try {
        db.close();
      } catch {
        // ignore
      }
      resolve();
    }
  });
}
