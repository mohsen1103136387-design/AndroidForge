import { ActivePage, AppraisalRecord, DayPriceInfo, OnboardingSlideId, UsageOnboardingState } from '../types';
import { toPersianDigits } from './persian';
import { APP_DEFAULTS, ONBOARDING_CONFIG, STORAGE_CONFIG } from './config';

const STORAGE_KEY_HISTORY = STORAGE_CONFIG.KEYS.HISTORY;
const STORAGE_KEY_THEME = STORAGE_CONFIG.KEYS.THEME;
const STORAGE_KEY_ONBOARDING = STORAGE_CONFIG.KEYS.ONBOARDING_SEEN;
const STORAGE_KEY_USAGE_ONBOARDING = STORAGE_CONFIG.KEYS.USAGE_ONBOARDING;
const STORAGE_KEY_PRICE_PREFIX = STORAGE_CONFIG.KEYS.DAY_PRICE_PREFIX;
const PRICE_CACHE_TTL_MS = STORAGE_CONFIG.PRICE_CACHE_TTL_MS;

const ALL_SLIDE_IDS = ONBOARDING_CONFIG.ALL_SLIDE_IDS;

/**
 * Check whether the user has already completed or dismissed the welcome guide
 */
export function hasSeenOnboarding(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY_ONBOARDING) === 'true';
  } catch {
    return false;
  }
}

/**
 * Persist that the welcome guide has been viewed
 */
export function markOnboardingSeen(): void {
  try {
    localStorage.setItem(STORAGE_KEY_ONBOARDING, 'true');
  } catch (e) {
    console.error('Failed to save onboarding state', e);
  }
}

/**
 * Load user's usage & seen-slide onboarding profile
 */
export function loadUsageOnboardingState(): UsageOnboardingState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USAGE_ONBOARDING);
    if (!raw) {
      return { visitedPages: ['home'], seenSlideIds: [] };
    }
    const parsed = JSON.parse(raw) as Partial<UsageOnboardingState>;
    return {
      visitedPages: Array.isArray(parsed.visitedPages) ? parsed.visitedPages : ['home'],
      seenSlideIds: Array.isArray(parsed.seenSlideIds) ? parsed.seenSlideIds : [],
      dismissedSmartSuggestAt: parsed.dismissedSmartSuggestAt,
      completedFullTour: Boolean(parsed.completedFullTour),
    };
  } catch {
    return { visitedPages: ['home'], seenSlideIds: [] };
  }
}

function saveUsageOnboardingState(state: UsageOnboardingState): void {
  try {
    localStorage.setItem(STORAGE_KEY_USAGE_ONBOARDING, JSON.stringify(state));
  } catch (e) {
    console.error('Failed saving usage onboarding state', e);
  }
}

export function recordVisitedPage(page: ActivePage): UsageOnboardingState {
  const current = loadUsageOnboardingState();
  if (current.visitedPages.includes(page)) return current;
  const next: UsageOnboardingState = {
    ...current,
    visitedPages: [...current.visitedPages, page],
  };
  saveUsageOnboardingState(next);
  return next;
}

export function recordViewedOnboardingSlide(slideId: OnboardingSlideId): UsageOnboardingState {
  const current = loadUsageOnboardingState();
  const seenSlideIds = current.seenSlideIds.includes(slideId)
    ? current.seenSlideIds
    : [...current.seenSlideIds, slideId];
  const completedFullTour =
    current.completedFullTour || ALL_SLIDE_IDS.every((id) => seenSlideIds.includes(id));
  const next: UsageOnboardingState = {
    ...current,
    seenSlideIds,
    completedFullTour,
  };
  saveUsageOnboardingState(next);
  return next;
}

export function dismissSmartOnboardingSuggestion(): UsageOnboardingState {
  const current = loadUsageOnboardingState();
  const next: UsageOnboardingState = {
    ...current,
    dismissedSmartSuggestAt: Date.now(),
  };
  saveUsageOnboardingState(next);
  return next;
}

/**
 * Get saved theme, defaults to dark
 */
export function getSavedTheme(): 'dark' | 'light' {
  try {
    const val = localStorage.getItem(STORAGE_KEY_THEME);
    return val === 'light' ? 'light' : APP_DEFAULTS.THEME;
  } catch {
    return APP_DEFAULTS.THEME;
  }
}

/**
 * Save theme preference
 */
export function saveTheme(theme: 'dark' | 'light'): void {
  try {
    localStorage.setItem(STORAGE_KEY_THEME, theme);
  } catch (e) {
    console.error('Failed to save theme in localStorage', e);
  }
}

/**
 * Get cached day price for a car model and year
 */
export function getCachedDayPrice(modelName: string, year: number): DayPriceInfo | null {
  try {
    const key = `${STORAGE_KEY_PRICE_PREFIX}${modelName}_${year}`;
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const data: DayPriceInfo = JSON.parse(raw);
    if (!data.cachedAt || Date.now() - data.cachedAt > PRICE_CACHE_TTL_MS) {
      localStorage.removeItem(key);
      return null;
    }
    return data;
  } catch (e) {
    console.error('Failed reading day price cache', e);
    return null;
  }
}

/**
 * Cache day price for a car model and year
 */
export function setCachedDayPrice(modelName: string, year: number, info: DayPriceInfo): void {
  try {
    const key = `${STORAGE_KEY_PRICE_PREFIX}${modelName}_${year}`;
    const toSave: DayPriceInfo = {
      ...info,
      cachedAt: Date.now(),
    };
    localStorage.setItem(key, JSON.stringify(toSave));
  } catch (e) {
    console.error('Failed writing day price cache', e);
  }
}

/**
 * Load history records (max 50)
 */
export function loadHistory(): AppraisalRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_HISTORY);
    if (!raw) return [];
    const items: AppraisalRecord[] = JSON.parse(raw);
    return Array.isArray(items) ? items : [];
  } catch (e) {
    console.error('Failed loading history from localStorage', e);
    return [];
  }
}

/**
 * Save a new record to history, keeping max 50 items
 */
export function saveToHistory(record: AppraisalRecord): AppraisalRecord[] {
  try {
    const current = loadHistory();
    // Prepend new record, filter duplicates by id
    const filtered = current.filter((item) => item.id !== record.id);
    const updated = [record, ...filtered].slice(0, STORAGE_CONFIG.MAX_HISTORY_ITEMS);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Failed saving record to history', e);
    return [];
  }
}

/**
 * Delete a single record by ID
 */
export function deleteHistoryItem(id: string): AppraisalRecord[] {
  try {
    const current = loadHistory();
    const updated = current.filter((item) => item.id !== id);
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error('Failed deleting history item', e);
    return [];
  }
}

/**
 * Clear all history
 */
export function clearAllHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY_HISTORY);
  } catch (e) {
    console.error('Failed clearing history', e);
  }
}

/**
 * Export history records to CSV with UTF-8 BOM
 */
export function exportHistoryToCSV(records: AppraisalRecord[]): void {
  if (!records || records.length === 0) return;

  const headers = [
    'کد پیگیری',
    'تاریخ شمسی',
    'مدل خودرو',
    'سال تولید',
    'کارکرد (کیلومتر)',
    'قیمت پایه روز (تومان)',
    'قیمت منصفانه کارشناسی (تومان)',
    'قیمت اعلامی فروشنده (تومان)',
    'ارزیابی معامله',
    'درصد کل کسورات'
  ];

  const rows = records.map((r) => [
    `"${r.trackingCode}"`,
    `"${r.shamsiDate}"`,
    `"${r.carModel}"`,
    r.year,
    r.mileage,
    r.basePrice,
    r.result.fairPrice,
    r.sellerPrice || '',
    `"${r.result.dealJudgment.title.replace(/"/g, '""')}"`,
    `"${toPersianDigits(r.result.totalDeductionPercentage)}٪"`
  ]);

  const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\r\n');
  
  // UTF-8 BOM (\uFEFF) ensures Persian text opens properly in Microsoft Excel
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `autoscope-history-${Date.now()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
