import { BodyPartId, CarCategory, CarLabelId, ChassisPartId, ChassisSeverity } from '../types';
import { PRICING_COEFFICIENTS } from './config';

export interface CarModelItem {
  id: string;
  name: string;
  brand: string;
  category: CarCategory;
  categoryLabel: string;
}

export const CAR_MODELS: CarModelItem[] = [
  // ایران خودرو (IKCO)
  { id: '206_t2', name: 'پژو ۲۰۶ تیپ ۲', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: '206_t5', name: 'پژو ۲۰۶ تیپ ۵', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: '207_man', name: 'پژو ۲۰۷ دنده‌ای TU5', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: '207_auto', name: 'پژو ۲۰۷ اتوماتیک TU5P', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: '207_pan', name: 'پژو ۲۰۷ پانوراما (سقف شیشه‌ای)', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'pars_sal', name: 'پژو پارس سال (XU7 / XUP)', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'pars_tu5', name: 'پژو پارس TU5 LX', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'peugeot_405', name: 'پژو ۴۰۵ GLX / SLX', brand: 'پژو', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'samand_lx', name: 'سمند LX ساده / EF7', brand: 'سمند', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'soren_plus', name: 'سمند سورن پلاس EF7', brand: 'سمند', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'dena', name: 'دنا معمولی تیپ ۲', brand: 'دنا', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'dena_plus', name: 'دنا پلاس دنده‌ای', brand: 'دنا', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'dena_turbo_auto', name: 'دنا پلاس توربو اتوماتیک', brand: 'دنا', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'runna', name: 'رانا LX / پلاس', brand: 'رانا', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'runna_pan', name: 'رانا پلاس پانوراما (۶ دنده)', brand: 'رانا', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'tara_man', name: 'تارا دنده‌ای V1 / V1P', brand: 'تارا', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'tara_auto', name: 'تارا اتوماتیک V2 / V4', brand: 'تارا', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'haima_s7', name: 'هایما S7 توربو پلاس', brand: 'هایما', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'haima_s5', name: 'هایما S5 توربو ۶AT', brand: 'هایما', category: 'ikco', categoryLabel: 'ایران‌خودرو' },
  { id: 'haima_8s', name: 'هایما 8S اتوماتیک', brand: 'هایما', category: 'ikco', categoryLabel: 'ایران‌خودرو' },

  // سایپا (SAIPA)
  { id: 'pride_111', name: 'پراید ۱۱۱ هاچ‌بک EX/SX', brand: 'پراید', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'pride_131', name: 'پراید ۱۳۱ صندوق‌دار SE', brand: 'پراید', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'pride_132', name: 'پراید ۱۳۲ ساده/SE', brand: 'پراید', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'pride_151', name: 'پراید ۱۵۱ وانت', brand: 'پراید', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'tiba_1', name: 'تیبا صندوق‌دار SX/EX', brand: 'تیبا', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'tiba_2', name: 'تیبا ۲ هاچ‌بک EX/پلاس', brand: 'تیبا', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'saina_s', name: 'ساینا S دنده‌ای', brand: 'ساینا', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'saina_auto', name: 'ساینا پلاس / اتوماتیک', brand: 'ساینا', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'quick_man', name: 'کوییک دنده‌ای ساده', brand: 'کوییک', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'quick_r', name: 'کوییک R دو رنگ', brand: 'کوییک', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'quick_s', name: 'کوییک S / GXR', brand: 'کوییک', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'quick_auto', name: 'کوییک اتوماتیک پلاس', brand: 'کوییک', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'shahin_g', name: 'شاهین G دنده‌ای توربو', brand: 'شاهین', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'shahin_auto', name: 'شاهین اتوماتیک CVT / پلاس', brand: 'شاهین', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'atlas_g', name: 'اطلس G دنده‌ای', brand: 'اطلس', category: 'saipa', categoryLabel: 'سایپا' },
  { id: 'sahand_s', name: 'سهند S دنده‌ای', brand: 'سهند', category: 'saipa', categoryLabel: 'سایپا' },

  // مونتاژی و چینی پرفروش
  { id: 'l90_e2', name: 'تندر ۹۰ (L90 E2 پارس خودرو)', brand: 'تندر', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'sandero', name: 'رنو ساندرو معمولی / استپ‌وی', brand: 'ساندرو', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'jac_j4', name: 'جک J4 اتوماتیک', brand: 'جک', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'jac_s5', name: 'جک S5 اتوماتیک ۲ لیتری / ۱.۵ توربو', brand: 'جک', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'mvm_x22', name: 'ام‌وی‌ام X22 دنده‌ای / پرو', brand: 'ام‌وی‌ام', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'mvm_x33', name: 'ام‌وی‌ام X33 S / کراس', brand: 'ام‌وی‌ام', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'chery_tiggo5', name: 'چری تیگو ۵ اکسلنت / TE', brand: 'چری', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'chery_tiggo7', name: 'چری تیگو ۷ پرو / اکسلنت', brand: 'چری', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'arrizo_5', name: 'چری آریزو ۵ TE / FL', brand: 'آریزو', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'arrizo_6', name: 'فونیکس آریزو ۶ پرو', brand: 'آریزو', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'brilliance_h330', name: 'برلیانس H330 اتوماتیک', brand: 'برلیانس', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'dongfeng_h30', name: 'دانگ‌فنگ H30 کراس اتوماتیک', brand: 'دانگ‌فنگ', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'fidelity_prime', name: 'فیدلیتی پرایم ۵ و ۷ نفره', brand: 'فیدلیتی', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'dignity_prime', name: 'دیگنیتی پرایم / پرستیژ', brand: 'دیگنیتی', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'lamari_eama', name: 'لاماری ایما ۱.۵ توربو GDI', brand: 'لاماری', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'respect_prime', name: 'ریسپکت پرایم اتوماتیک', brand: 'ریسپکت', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'besturn_b30', name: 'بسترن B30 اتوماتیک', brand: 'بسترن', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },
  { id: 'fownix_fx', name: 'فونیکس FX پریمیوم', brand: 'فونیکس', category: 'assembled', categoryLabel: 'مونتاژی و چینی' },

  // وارداتی پرفروش
  { id: 'hyundai_santafe', name: 'هیوندای سانتافه Grand / DM', brand: 'هیوندای', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'hyundai_sonata', name: 'هیوندای سوناتا YF / LF', brand: 'هیوندای', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'hyundai_elantra', name: 'هیوندای الانترا ۱.۸ / ۲.۰', brand: 'هیوندای', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'kia_sportage', name: 'کیا اسپورتیج SL / QL', brand: 'کیا', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'kia_cerato', name: 'کیا سراتو وارداتی / مونتاژ سایپا', brand: 'کیا', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'kia_optima', name: 'کیا اپتیما TF / JF', brand: 'کیا', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'toyota_corolla', name: 'تویوتا کرولا GLI / XLI', brand: 'تویوتا', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'toyota_rav4', name: 'تویوتا راو۴ ۲.۵ لیتری', brand: 'تویوتا', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'renault_talisman', name: 'رنو تلیسمان E3', brand: 'رنو', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
  { id: 'nissan_juke', name: 'نیسان جوک پلاتینیوم / اسپرت', brand: 'نیسان', category: 'imported', categoryLabel: 'وارداتی پرفروش' },
];

export interface BodyPartMeta {
  id: BodyPartId;
  name: string;
  category: 'structural' | 'panel' | 'bumper';
  damagePercent: number;
  paintPercent: number;
  supportsPaint: boolean;
}

export const BODY_PARTS_INFO: Record<BodyPartId, BodyPartMeta> = {
  front_bumper: { id: 'front_bumper', name: 'سپر جلو', category: 'bumper', damagePercent: 1.5, paintPercent: 0.5, supportsPaint: true },
  hood: { id: 'hood', name: 'کاپوت', category: 'panel', damagePercent: 2.0, paintPercent: 2.0, supportsPaint: true },
  windshield: { id: 'windshield', name: 'شیشه جلو', category: 'structural', damagePercent: 8.0, paintPercent: 0, supportsPaint: false },
  roof: { id: 'roof', name: 'سقف', category: 'structural', damagePercent: 8.0, paintPercent: 3.0, supportsPaint: true },
  rear_windshield: { id: 'rear_windshield', name: 'شیشه عقب', category: 'structural', damagePercent: 8.0, paintPercent: 0, supportsPaint: false },
  trunk: { id: 'trunk', name: 'صندوق عقب', category: 'panel', damagePercent: 4.0, paintPercent: 2.0, supportsPaint: true },
  rear_bumper: { id: 'rear_bumper', name: 'سپر عقب', category: 'bumper', damagePercent: 1.5, paintPercent: 0.5, supportsPaint: true },
  fender_front_right: { id: 'fender_front_right', name: 'گلگیر جلو راست', category: 'panel', damagePercent: 3.0, paintPercent: 1.0, supportsPaint: true },
  fender_front_left: { id: 'fender_front_left', name: 'گلگیر جلو چپ', category: 'panel', damagePercent: 3.0, paintPercent: 1.0, supportsPaint: true },
  fender_rear_right: { id: 'fender_rear_right', name: 'گلگیر عقب راست', category: 'panel', damagePercent: 3.0, paintPercent: 1.0, supportsPaint: true },
  fender_rear_left: { id: 'fender_rear_left', name: 'گلگیر عقب چپ', category: 'panel', damagePercent: 3.0, paintPercent: 1.0, supportsPaint: true },
  door_front_right: { id: 'door_front_right', name: 'درب جلو راست', category: 'panel', damagePercent: 2.5, paintPercent: 1.2, supportsPaint: true },
  door_front_left: { id: 'door_front_left', name: 'درب جلو چپ', category: 'panel', damagePercent: 2.5, paintPercent: 1.2, supportsPaint: true },
  door_rear_right: { id: 'door_rear_right', name: 'درب عقب راست', category: 'panel', damagePercent: 2.5, paintPercent: 1.2, supportsPaint: true },
  door_rear_left: { id: 'door_rear_left', name: 'درب عقب چپ', category: 'panel', damagePercent: 2.5, paintPercent: 1.2, supportsPaint: true },
};

export interface ChassisPartMeta {
  id: ChassisPartId;
  name: string;
}

export const CHASSIS_PARTS_INFO: Record<ChassisPartId, ChassisPartMeta> = {
  pillar_a_r: { id: 'pillar_a_r', name: 'ستون A راست' },
  pillar_a_l: { id: 'pillar_a_l', name: 'ستون A چپ' },
  pillar_b_r: { id: 'pillar_b_r', name: 'ستون B راست' },
  pillar_b_l: { id: 'pillar_b_l', name: 'ستون B چپ' },
  pillar_c_r: { id: 'pillar_c_r', name: 'ستون C راست' },
  pillar_c_l: { id: 'pillar_c_l', name: 'ستون C چپ' },
  rail_front_r: { id: 'rail_front_r', name: 'ریل/لنگه شاسی جلو راست' },
  rail_front_l: { id: 'rail_front_l', name: 'ریل/لنگه شاسی جلو چپ' },
  rail_rear_r: { id: 'rail_rear_r', name: 'ریل شاسی عقب راست' },
  rail_rear_l: { id: 'rail_rear_l', name: 'ریل شاسی عقب چپ' },
  floor_pan: { id: 'floor_pan', name: 'کفپوش / کف خودرو' },
  rocker_r: { id: 'rocker_r', name: 'رکاب (آستانه) راست' },
  rocker_l: { id: 'rocker_l', name: 'رکاب (آستانه) چپ' },
  tray_front: { id: 'tray_front', name: 'سینی جلو (پل جلو)' },
  tray_rear: { id: 'tray_rear', name: 'سینی عقب (زیر صندوق)' },
  roof_crossmember: { id: 'roof_crossmember', name: 'تیر سقف' },
};

export const CHASSIS_SEVERITY_RATES: Record<ChassisSeverity, number> =
  PRICING_COEFFICIENTS.CHASSIS.SEVERITY_RATES;

export const CHASSIS_SEVERITY_LABELS: Record<ChassisSeverity, string> = {
  none: 'سالم',
  minor: 'ضربه جزئی - ترمیم شده (۸٪)',
  moderate: 'آسیب متوسط (۱۴٪)',
  severe: 'شکستگی یا تعویض (۲۲٪)',
};

export interface CarLabelMeta {
  id: CarLabelId;
  name: string;
  percent: number;
  description: string;
}

export const CAR_LABELS_INFO: Record<CarLabelId, CarLabelMeta> = {
  sun_faded: { id: 'sun_faded', name: 'آفتاب‌سوخته', percent: 2.0, description: 'کدری و آسیب لایه کلیر و رنگ به دلیل تابش مداوم آفتاب' },
  city_used: { id: 'city_used', name: 'کارکرده شهری', percent: 3.0, description: 'استهلاک ناشی از ترافیک سنگین شهری، کلاچ‌گیری مداوم و دست‌انداز' },
  imported_used: { id: 'imported_used', name: 'وارداتی دست‌دوم', percent: 1.5, description: 'هزینه نگهداری و حساسیت قطعات وارداتی' },
  taxi_snapp: { id: 'taxi_snapp', name: 'استفاده تاکسی / اسنپ', percent: 5.0, description: 'استهلاک سنگین قطعات جلوبندی، گیربکس و اتاق به دلیل استفاده ناوگانی' },
};
