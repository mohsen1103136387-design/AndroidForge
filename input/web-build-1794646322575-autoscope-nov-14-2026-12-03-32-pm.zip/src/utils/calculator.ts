import {
  BodyPartId,
  BodyPartState,
  CalculationResult,
  CarLabelId,
  ChassisPartId,
  ChassisSeverity,
  DealJudgment,
  DeductionRow,
  TechnicalStatus,
} from '../types';
import {
  BODY_PARTS_INFO,
  CAR_LABELS_INFO,
  CHASSIS_PARTS_INFO,
  CHASSIS_SEVERITY_RATES,
} from './carData';
import { PRICING_COEFFICIENTS } from './config';
import { getCurrentShamsiYear } from './persian';

/**
 * Extracts Brand Factor (bf) using regex on car model name after removing whitespace and ZWNJ
 */
export function getBrandFactor(carModelName: string): { bf: number; categoryName: string } {
  const normalized = carModelName.replace(/[\s\u200c]+/g, '');
  const { IKCO, SAIPA, ASSEMBLED, OTHER } = PRICING_COEFFICIENTS.BRAND_FACTORS;

  if (IKCO.pattern.test(normalized)) {
    return { bf: IKCO.bf, categoryName: IKCO.categoryName };
  }
  if (SAIPA.pattern.test(normalized)) {
    return { bf: SAIPA.bf, categoryName: SAIPA.categoryName };
  }
  if (ASSEMBLED.pattern.test(normalized)) {
    return { bf: ASSEMBLED.bf, categoryName: ASSEMBLED.categoryName };
  }
  return { bf: OTHER.bf, categoryName: OTHER.categoryName };
}

function getPaintAgeSensitivityMultiplier(age: number): number {
  const {
    NEW_CAR_MAX_AGE,
    NEW_CAR_MULTIPLIER,
    MID_CAR_MAX_AGE,
    MID_CAR_MULTIPLIER,
    MATURE_CAR_MAX_AGE,
    MATURE_CAR_MULTIPLIER,
    CLASSIC_CAR_MULTIPLIER,
  } = PRICING_COEFFICIENTS.PAINT_AGE_SENSITIVITY;

  if (age <= NEW_CAR_MAX_AGE) return NEW_CAR_MULTIPLIER;
  if (age <= MID_CAR_MAX_AGE) return MID_CAR_MULTIPLIER;
  if (age <= MATURE_CAR_MAX_AGE) return MATURE_CAR_MULTIPLIER;
  return CLASSIC_CAR_MULTIPLIER;
}

function roundToMarketStep(amount: number, basePrice: number): number {
  const unit = basePrice >= 50_000_000 ? PRICING_COEFFICIENTS.FAIR_PRICE_ROUNDING_UNIT : 100_000;
  return Math.max(0, Math.round(amount / unit) * unit);
}

export interface AppraisalInput {
  carModel: string;
  year: number;
  mileage: number;
  basePrice: number;
  sellerPrice?: number;
  bodyParts: Record<BodyPartId, BodyPartState>;
  chassisParts: Record<ChassisPartId, ChassisSeverity>;
  technical: TechnicalStatus;
  labels: CarLabelId[];
  /**
   * True when basePrice was already fetched for this exact model year (e.g., Divar/Car.ir used-year average),
   * preventing double-counting annual age depreciation.
   */
  isYearSpecificBasePrice?: boolean;
  /**
   * True when basePrice came from live market data rather than a rough manual fallback.
   */
  hasLiveMarketSources?: boolean;
}

export function calculateAppraisal(input: AppraisalInput): CalculationResult {
  const {
    carModel,
    year,
    mileage,
    basePrice,
    sellerPrice,
    bodyParts,
    chassisParts,
    technical,
    labels,
    isYearSpecificBasePrice = false,
    hasLiveMarketSources = false,
  } = input;

  const currentYear = getCurrentShamsiYear();
  const age = Math.max(0, currentYear - year);
  const { bf } = getBrandFactor(carModel);

  const rawRows: DeductionRow[] = [];

  // 1. Age deduction (skip when basePrice already reflects the specific model year's market average)
  const { BASE_ANNUAL_RATE, MAX_ANNUAL_RATE, MAX_AGE_DEDUCTION_RATIO } =
    PRICING_COEFFICIENTS.AGE_DEPRECIATION;
  if (age > 0 && !isYearSpecificBasePrice) {
    const rate = Math.min(BASE_ANNUAL_RATE * bf, MAX_ANNUAL_RATE);
    const amount = Math.min(basePrice * rate * age, basePrice * MAX_AGE_DEDUCTION_RATIO);
    const percentage = basePrice > 0 ? (amount / basePrice) * 100 : 0;
    rawRows.push({
      factor: `افت سن (${age} سال کارکرد مدل ${year})`,
      percentage: Number(percentage.toFixed(2)),
      amount: Math.round(amount),
      description: `نرخ استهلاک سالانه ${(rate * 100).toFixed(1)}٪ با ضریب برند ${bf} نسبت به قیمت صفر`,
    });
  } else if (age > 0 && isYearSpecificBasePrice) {
    rawRows.push({
      factor: `مبنای اختصاصی مدل ${year}`,
      percentage: 0,
      amount: 0,
      description: 'افت سال ساخت در میانگین قیمت بازار همین سال تولید لحاظ شده و کسر مضاعف اعمال نشد',
    });
  }

  // 2. Mileage variance (Excess Mileage Deduction OR Low-Mileage Value Premium)
  const {
    STANDARD_ANNUAL_KM,
    EXTRA_KM_STEP,
    RATE_PER_100K_KM,
    MIN_BRAND_FACTOR,
    LOW_MILEAGE_THRESHOLD_RATIO,
    LOW_MILEAGE_MAX_BONUS_RATIO,
    LOW_MILEAGE_BONUS_PER_100K_SAVED,
  } = PRICING_COEFFICIENTS.MILEAGE;

  const damagedChassisEntries = Object.entries(chassisParts).filter(
    ([, sev]) => sev !== 'none'
  ) as [ChassisPartId, ChassisSeverity][];

  const stdKm = age * STANDARD_ANNUAL_KM;
  const extraKm = Math.max(0, mileage - stdKm);

  if (extraKm > 0 && basePrice > 0) {
    const kmAmount =
      basePrice * (extraKm / EXTRA_KM_STEP) * RATE_PER_100K_KM * Math.max(MIN_BRAND_FACTOR, bf);
    const percentage = (kmAmount / basePrice) * 100;
    rawRows.push({
      factor: `کارکرد اضافی (${extraKm.toLocaleString('fa-IR')} کیلومتر مازاد)`,
      percentage: Number(percentage.toFixed(2)),
      amount: Math.round(kmAmount),
      description: `پیمایش استاندارد: ${stdKm.toLocaleString('fa-IR')} کیلومتر (${age} سال × ${STANDARD_ANNUAL_KM.toLocaleString('fa-IR')})`,
    });
  } else if (
    age >= 2 &&
    basePrice > 0 &&
    mileage < stdKm * LOW_MILEAGE_THRESHOLD_RATIO &&
    !technical.rolledOver &&
    damagedChassisEntries.length === 0
  ) {
    const savedKm = stdKm - mileage;
    const rawBonusRatio = (savedKm / EXTRA_KM_STEP) * LOW_MILEAGE_BONUS_PER_100K_SAVED;
    const bonusRatio = Math.min(LOW_MILEAGE_MAX_BONUS_RATIO, rawBonusRatio);
    if (bonusRatio >= 0.005) {
      const bonusAmount = basePrice * bonusRatio;
      rawRows.push({
        factor: `ارزش افزوده کم‌کارکرد (${mileage.toLocaleString('fa-IR')} کیلومتر)`,
        percentage: -Number((bonusRatio * 100).toFixed(2)),
        amount: -Math.round(bonusAmount),
        description: `کارکرد حدود ${savedKm.toLocaleString('fa-IR')} کیلومتر کمتر از عرف بازار (${stdKm.toLocaleString('fa-IR')} کیلومتر)`,
      });
    }
  }

  // 3. Body Parts damage and age-aware paint sensitivity
  const paintMultiplier = getPaintAgeSensitivityMultiplier(age);
  Object.entries(bodyParts).forEach(([partId, state]) => {
    const meta = BODY_PARTS_INFO[partId as BodyPartId];
    if (!meta) return;

    if (state.damaged) {
      const amount = (basePrice * meta.damagePercent) / 100;
      rawRows.push({
        factor: `ضربه خوردگی ${meta.name}`,
        percentage: meta.damagePercent,
        amount: Math.round(amount),
        description: `آسیب فیزیکی به قطعه ${meta.name}`,
      });
    }

    if (state.painted && meta.supportsPaint) {
      const effectivePaintPct = Number((meta.paintPercent * paintMultiplier).toFixed(2));
      const amount = (basePrice * effectivePaintPct) / 100;
      rawRows.push({
        factor: `رنگ شدگی ${meta.name}`,
        percentage: effectivePaintPct,
        amount: Math.round(amount),
        description:
          paintMultiplier !== 1
            ? `لکه یا پوشش رنگ در قطعه ${meta.name} (تعدیل‌شده با ضریب سن خودرو ${paintMultiplier}×)`
            : `لکه یا پوشش رنگ در قطعه ${meta.name}`,
      });
    }
  });

  // 4. Chassis & Pillars deduction
  if (damagedChassisEntries.length > 0 && basePrice > 0) {
    const rates = damagedChassisEntries.map(([, sev]) => CHASSIS_SEVERITY_RATES[sev]);
    const maxIntensity = Math.max(...rates);
    const extraDamagedPartsCount = damagedChassisEntries.length - 1;
    const { EXTRA_DAMAGED_PART_RATE, MAX_CHASSIS_DEDUCTION_RATIO } = PRICING_COEFFICIENTS.CHASSIS;
    const chassisRate = Math.min(
      MAX_CHASSIS_DEDUCTION_RATIO,
      maxIntensity + extraDamagedPartsCount * EXTRA_DAMAGED_PART_RATE
    );
    const chassisAmount = basePrice * chassisRate;

    const damagedNames = damagedChassisEntries
      .map(
        ([id, sev]) =>
          `${CHASSIS_PARTS_INFO[id]?.name || id} (${
            sev === 'minor' ? 'جزئی' : sev === 'moderate' ? 'متوسط' : 'تعویض/شکستگی'
          })`
      )
      .join('، ');

    rawRows.push({
      factor: 'آسیب ساختاری شاسی و ستون‌ها',
      percentage: Number((chassisRate * 100).toFixed(2)),
      amount: Math.round(chassisAmount),
      description: `اجزای آسیب‌دیده: ${damagedNames}`,
    });
  }

  // 5. Technical and Accidental issues
  const { ENGINE_REPLACED, ROLLED_OVER, NO_AIRBAG, AIRBAG_DEPLOYED } =
    PRICING_COEFFICIENTS.TECHNICAL_DEDUCTIONS;

  if (technical.engineReplaced && basePrice > 0) {
    const amount = basePrice * ENGINE_REPLACED;
    rawRows.push({
      factor: 'سابقه تعویض کامل موتور',
      percentage: ENGINE_REPLACED * 100,
      amount: Math.round(amount),
      description: 'تعویض سیلندر و ثبت شماره موتور در سند، افت محسوس بازار',
    });
  }

  if (technical.rolledOver && basePrice > 0) {
    const amount = basePrice * ROLLED_OVER;
    rawRows.push({
      factor: 'سابقه واژگونی و چپ‌کردگی',
      percentage: ROLLED_OVER * 100,
      amount: Math.round(amount),
      description: 'تغییر هندسه اتاق و ضعف شدید ایمنی کلاف خودرو',
    });
  }

  if (!technical.hasAirbag && basePrice > 0) {
    const amount = basePrice * NO_AIRBAG;
    rawRows.push({
      factor: 'فاقد کیسه هوا (ایربگ)',
      percentage: NO_AIRBAG * 100,
      amount: Math.round(amount),
      description: 'نقص تجهیزات ایمنی پایه سرنشینان',
    });
  } else if (technical.hasAirbag && technical.airbagDeployed && basePrice > 0) {
    const amount = basePrice * AIRBAG_DEPLOYED;
    rawRows.push({
      factor: 'سابقه باز شدن کیسه هوا (ایربگ)',
      percentage: AIRBAG_DEPLOYED * 100,
      amount: Math.round(amount),
      description: 'نشان‌دهنده تصادف شدید از جلو و هزینه‌بر بودن احیای یونیت',
    });
  }

  // 6. General Condition Labels
  labels.forEach((labelId) => {
    const meta = CAR_LABELS_INFO[labelId];
    if (meta && basePrice > 0) {
      const amount = (basePrice * meta.percent) / 100;
      rawRows.push({
        factor: meta.name,
        percentage: meta.percent,
        amount: Math.round(amount),
        description: meta.description,
      });
    }
  });

  // Calculate net deduction (positive = deduction, negative = low-mileage premium) and enforce ceiling
  const rawNetDeduction = rawRows.reduce((acc, row) => acc + row.amount, 0);
  const maxAllowedDeduction = basePrice * PRICING_COEFFICIENTS.MAX_TOTAL_DEDUCTION_RATIO;
  const isCapped = rawNetDeduction > maxAllowedDeduction && basePrice > 0;

  let finalRows: DeductionRow[];
  let finalTotalDeduction = rawNetDeduction;

  if (isCapped && rawNetDeduction > 0) {
    finalTotalDeduction = maxAllowedDeduction;
    const positiveSum = rawRows.reduce((acc, r) => (r.amount > 0 ? acc + r.amount : acc), 0);
    const scaleFactor = positiveSum > 0 ? maxAllowedDeduction / positiveSum : 1;
    finalRows = rawRows.map((r) => {
      if (r.amount <= 0) return r;
      const scaledAmount = Math.round(r.amount * scaleFactor);
      const scaledPercentage = Number(((scaledAmount / basePrice) * 100).toFixed(2));
      return {
        ...r,
        amount: scaledAmount,
        percentage: scaledPercentage,
      };
    });
  } else {
    finalRows = rawRows;
  }

  const rawFairPrice = Math.max(0, basePrice - finalTotalDeduction);
  const fairPrice = roundToMarketStep(rawFairPrice, basePrice);
  const spread = PRICING_COEFFICIENTS.FAIR_RANGE_SPREAD_RATIO;
  const fairPriceMin = roundToMarketStep(fairPrice * (1 - spread), basePrice);
  const fairPriceMax = roundToMarketStep(fairPrice * (1 + spread), basePrice);

  const totalDeductionPercentage =
    basePrice > 0 ? Number(((finalTotalDeduction / basePrice) * 100).toFixed(1)) : 0;

  const confidenceLevel: 'high' | 'medium' | 'estimated' = hasLiveMarketSources
    ? isYearSpecificBasePrice
      ? 'high'
      : 'medium'
    : 'estimated';

  // Deal Judgment
  let dealJudgment: DealJudgment;
  const { EXCELLENT_MAX_DIFF_PERCENT, FAIR_MAX_DIFF_PERCENT, HIGH_MAX_DIFF_PERCENT } =
    PRICING_COEFFICIENTS.DEAL_JUDGMENT_THRESHOLDS;

  if (sellerPrice && sellerPrice > 0 && fairPrice > 0) {
    const dp = ((sellerPrice - fairPrice) / fairPrice) * 100;
    if (dp <= EXCELLENT_MAX_DIFF_PERCENT) {
      dealJudgment = {
        level: 'excellent',
        title: '🎉 معامله عالی',
        description:
          'قیمت فروشنده به‌طور محسوسی پایین‌تر از ارزش کارشناسی است. حتماً اصالت اسناد، هویت فروشنده و دلیل ارزانی را بررسی کنید.',
        diffPercent: Number(dp.toFixed(1)),
        badgeClass: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      };
    } else if (dp <= FAIR_MAX_DIFF_PERCENT) {
      dealJudgment = {
        level: 'fair',
        title: '✅ قیمت منصفانه',
        description:
          'قیمت اعلامی فروشنده کاملاً در محدوده ارزش واقعی و منطقی کارشناسی روز خودرو قرار دارد.',
        diffPercent: Number(dp.toFixed(1)),
        badgeClass: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
      };
    } else if (dp <= HIGH_MAX_DIFF_PERCENT) {
      dealJudgment = {
        level: 'high',
        title: '⚠️ قیمت بالا، تخفیف بگیرید',
        description:
          'قیمت فروشنده تا ۱۵٪ بالاتر از ارزش کارشناسی است. پیشنهاد می‌شود با استناد به جدول کسورات تخفیف بگیرید.',
        diffPercent: Number(dp.toFixed(1)),
        badgeClass: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      };
    } else {
      dealJudgment = {
        level: 'very_high',
        title: '❌ قیمت خیلی بالا، توصیه نمی‌شود',
        description:
          'قیمت اعلامی فروشنده حباب دارد و بیش از ۱۵٪ گران‌تر از ارزش واقعی است. خرید با این رقم توصیه نمی‌شود.',
        diffPercent: Number(dp.toFixed(1)),
        badgeClass: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
      };
    }
  } else {
    dealJudgment = {
      level: 'none',
      title: 'قیمت منطقی محاسبه شد',
      description:
        'برای مقایسه با قیمت بازار و ارزیابی معامله، می‌توانید قیمت پیشنهادی فروشنده را نیز وارد کنید.',
      diffPercent: 0,
      badgeClass: 'bg-slate-700/50 text-slate-300 border-slate-600/30',
    };
  }

  return {
    basePrice,
    fairPrice,
    fairPriceMin,
    fairPriceMax,
    totalDeductions: Math.round(finalTotalDeduction),
    totalDeductionPercentage,
    isCapped,
    yearAdjustedBaseUsed: isYearSpecificBasePrice,
    confidenceLevel,
    rows: finalRows,
    dealJudgment,
    calculatedAt: new Date().toISOString(),
  };
}
