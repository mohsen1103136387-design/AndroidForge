import { ChassisSeverity, OnboardingSlideId } from '../types';

/**
 * LocalStorage keys, cache TTLs, and history limits
 */
export const STORAGE_CONFIG = {
  KEYS: {
    HISTORY: 'autoscope_history_v1',
    THEME: 'autoscope_theme',
    ONBOARDING_SEEN: 'autoscope_onboarding_seen_v1',
    USAGE_ONBOARDING: 'autoscope_usage_onboarding_v1',
    DAY_PRICE_PREFIX: 'autoscope_dayprice_v2_',
  },
  MAX_HISTORY_ITEMS: 50,
  PRICE_CACHE_TTL_MS: 6 * 60 * 60 * 1000, // 6 hours
} as const;

/**
 * UI & network timing constants (milliseconds)
 */
export const APP_TIMINGS = {
  SPLASH_DURATION_MS: 1100,
  TOAST_DURATION_MS: 4000,
  SMART_ONBOARDING_COOLDOWN_MS: 24 * 60 * 60 * 1000, // 24 hours
  PRICE_FETCH_DEBOUNCE_MS: 400,
} as const;

/**
 * Default application values, year boundaries, and quick-access models
 */
export const APP_DEFAULTS = {
  THEME: 'dark' as 'dark' | 'light',
  CAR_MODEL: 'پژو ۲۰۶ تیپ ۵',
  YEAR: 1400,
  MILEAGE: 85_000,
  MILEAGE_DISPLAY: '۸۵٬۰۰۰',
  MIN_SHAMSI_YEAR: 1350,
  MAX_FUTURE_YEAR_OFFSET: 1,
  POPULAR_CARS: [
    'پژو ۲۰۷ دنده‌ای TU5',
    'دنا پلاس توربو اتوماتیک',
    'کوییک S / GXR',
    'تارا اتوماتیک V2 / V4',
    'پژو پارس TU5 LX',
    'شاهین G دنده‌ای توربو',
    'هایما S7 توربو پلاس',
    'جک S5 اتوماتیک',
  ],
} as const;

/**
 * Onboarding slide identifiers and interaction thresholds
 */
export const ONBOARDING_CONFIG = {
  ALL_SLIDE_IDS: ['welcome', 'market-price', '3d-inspection', 'cloud-pdf'] as OnboardingSlideId[],
  SWIPE_THRESHOLD_PX: 60,
} as const;

/**
 * Centralized car appraisal pricing & deduction coefficients
 */
export const PRICING_COEFFICIENTS = {
  BRAND_FACTORS: {
    IKCO: {
      bf: 1.0,
      categoryName: 'ایران‌خودرو',
      pattern: /پژو|سمند|دنا|رانا|تارا|هایما/,
    },
    SAIPA: {
      bf: 1.15,
      categoryName: 'سایپا',
      pattern: /پراید|تیبا|ساینا|کوییک|کوئیک|شاهین|اطلس|سهند/,
    },
    ASSEMBLED: {
      bf: 0.9,
      categoryName: 'مونتاژی/چینی',
      pattern: /تندر|ساندرو|جک|امویام|چری|برلیانس|دانگفنگ|فیدلیتی|دیگنیتی|لاماری|ریسپکت|آریزو|بسترن|فونیکس/,
    },
    OTHER: {
      bf: 1.0,
      categoryName: 'سایر برندها',
    },
  },
  AGE_DEPRECIATION: {
    BASE_ANNUAL_RATE: 0.05,
    MAX_ANNUAL_RATE: 0.07,
    MAX_AGE_DEDUCTION_RATIO: 0.55,
  },
  MILEAGE: {
    STANDARD_ANNUAL_KM: 20_000,
    EXTRA_KM_STEP: 100_000,
    RATE_PER_100K_KM: 0.03,
    MIN_BRAND_FACTOR: 0.7,
    LOW_MILEAGE_THRESHOLD_RATIO: 0.65,
    LOW_MILEAGE_MAX_BONUS_RATIO: 0.06,
    LOW_MILEAGE_BONUS_PER_100K_SAVED: 0.025,
  },
  PAINT_AGE_SENSITIVITY: {
    NEW_CAR_MAX_AGE: 2,
    NEW_CAR_MULTIPLIER: 1.15,
    MID_CAR_MAX_AGE: 6,
    MID_CAR_MULTIPLIER: 1.0,
    MATURE_CAR_MAX_AGE: 11,
    MATURE_CAR_MULTIPLIER: 0.85,
    CLASSIC_CAR_MULTIPLIER: 0.7,
  },
  CHASSIS: {
    EXTRA_DAMAGED_PART_RATE: 0.02,
    MAX_CHASSIS_DEDUCTION_RATIO: 0.35,
    SEVERITY_RATES: {
      none: 0,
      minor: 0.08,    // ضربه جزئی - ترمیم شده (۸٪)
      moderate: 0.14, // آسیب متوسط (۱۴٪)
      severe: 0.22,   // شکستگی یا تعویض (۲۲٪)
    } as Record<ChassisSeverity, number>,
  },
  TECHNICAL_DEDUCTIONS: {
    ENGINE_REPLACED: 0.12,
    ROLLED_OVER: 0.25,
    NO_AIRBAG: 0.05,
    AIRBAG_DEPLOYED: 0.08,
  },
  MAX_TOTAL_DEDUCTION_RATIO: 0.90,
  FAIR_PRICE_ROUNDING_UNIT: 1_000_000,
  FAIR_RANGE_SPREAD_RATIO: 0.025,
  DEAL_JUDGMENT_THRESHOLDS: {
    EXCELLENT_MAX_DIFF_PERCENT: -5,
    FAIR_MAX_DIFF_PERCENT: 5,
    HIGH_MAX_DIFF_PERCENT: 15,
  },
} as const;

