export type CarCategory = 'ikco' | 'saipa' | 'assembled' | 'imported';

export interface CarModelItem {
  id: string;
  name: string;
  brand: string;
  category: CarCategory;
  categoryLabel: string;
}

export type BodyPartId =
  | 'front_bumper'
  | 'hood'
  | 'windshield'
  | 'roof'
  | 'rear_windshield'
  | 'trunk'
  | 'rear_bumper'
  | 'fender_front_right'
  | 'fender_front_left'
  | 'fender_rear_right'
  | 'fender_rear_left'
  | 'door_front_right'
  | 'door_front_left'
  | 'door_rear_right'
  | 'door_rear_left';

export interface BodyPartState {
  damaged: boolean;
  painted: boolean;
}

export type ChassisPartId =
  | 'pillar_a_r'
  | 'pillar_a_l'
  | 'pillar_b_r'
  | 'pillar_b_l'
  | 'pillar_c_r'
  | 'pillar_c_l'
  | 'rail_front_r'
  | 'rail_front_l'
  | 'rail_rear_r'
  | 'rail_rear_l'
  | 'floor_pan'
  | 'rocker_r'
  | 'rocker_l'
  | 'tray_front'
  | 'tray_rear'
  | 'roof_crossmember';

export type ChassisSeverity = 'none' | 'minor' | 'moderate' | 'severe';

export interface TechnicalStatus {
  engineReplaced: boolean;
  rolledOver: boolean;
  hasAirbag: boolean;
  airbagDeployed: boolean;
}

export type CarLabelId = 'sun_faded' | 'city_used' | 'imported_used' | 'taxi_snapp';

export interface DeductionRow {
  factor: string;
  percentage: number;
  amount: number;
  description?: string;
}

export interface DealJudgment {
  level: 'excellent' | 'fair' | 'high' | 'very_high' | 'none';
  title: string;
  description: string;
  diffPercent: number;
  badgeClass: string;
}

export interface CalculationResult {
  basePrice: number;
  fairPrice: number;
  fairPriceMin?: number;
  fairPriceMax?: number;
  totalDeductions: number;
  totalDeductionPercentage: number;
  isCapped: boolean;
  yearAdjustedBaseUsed?: boolean;
  confidenceLevel?: 'high' | 'medium' | 'estimated';
  rows: DeductionRow[];
  dealJudgment: DealJudgment;
  calculatedAt: string;
}

export interface DayPriceInfo {
  min: number;
  max: number;
  avg: number;
  date: string;
  note?: string;
  sources: string[];
  isNextYearFallback?: boolean;
  effectiveYear: number;
  cachedAt?: number;
  isDiscontinued?: boolean;
  lastProductionYear?: number;
  discontinuedNotice?: string;
  fromLocalCache?: boolean;
  sampleCount?: number;
}

export interface AppraisalRecord {
  id: string;
  carModel: string;
  year: number;
  mileage: number;
  basePrice: number;
  sellerPrice?: number;
  bodyParts: Record<BodyPartId, BodyPartState>;
  chassisParts: Record<ChassisPartId, ChassisSeverity>;
  technical: TechnicalStatus;
  labels: CarLabelId[];
  result: CalculationResult;
  dayPriceInfo?: DayPriceInfo | null;
  savedAt: string; // ISO string
  shamsiDate: string;
  trackingCode: string;
}

export type ActivePage = 'home' | 'pricing' | 'result' | 'history' | 'print' | 'faq' | 'about' | 'account';

export type OnboardingSlideId = 'welcome' | 'market-price' | '3d-inspection' | 'cloud-pdf';

export interface UsageOnboardingState {
  visitedPages: ActivePage[];
  seenSlideIds: OnboardingSlideId[];
  dismissedSmartSuggestAt?: number;
  completedFullTour?: boolean;
}

