import React, { useState, useEffect, useRef } from 'react';
import {
  BodyPartId,
  BodyPartState,
  CarLabelId,
  ChassisPartId,
  ChassisSeverity,
  DayPriceInfo,
  CalculationResult,
} from '../types';
import { CAR_MODELS, CarModelItem, CAR_LABELS_INFO } from '../utils/carData';
import {
  toPersianDigits,
  toEnglishDigits,
  formatPersianNumber,
  formatToman,
  getCurrentShamsiYear,
  parseNumberInput,
} from '../utils/persian';
import { getCachedDayPriceAsync, setCachedDayPriceAsync } from '../utils/priceCacheDb';
import { calculateAppraisal } from '../utils/calculator';
import { APP_DEFAULTS, APP_TIMINGS } from '../utils/config';
import { ThreeCarBody } from './ThreeCarBody';
import { ThreeChassis } from './ThreeChassis';
import {
  Search,
  Sparkles,
  RefreshCw,
  Calendar,
  Gauge,
  CircleDollarSign,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Tag,
  Wrench,
  Shield,
  Layers,
  ChevronDown,
  X,
  ExternalLink,
  Flame,
  Database,
} from 'lucide-react';

interface PricingFormProps {
  onCalculate: (result: {
    carModel: string;
    year: number;
    mileage: number;
    basePrice: number;
    sellerPrice?: number;
    bodyParts: Record<BodyPartId, BodyPartState>;
    chassisParts: Record<ChassisPartId, ChassisSeverity>;
    technical: {
      engineReplaced: boolean;
      rolledOver: boolean;
      hasAirbag: boolean;
      airbagDeployed: boolean;
    };
    labels: CarLabelId[];
    calculationResult: CalculationResult;
    dayPriceInfo: DayPriceInfo | null;
  }) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  initialValues?: any;
}

export const PricingForm: React.FC<PricingFormProps> = ({
  onCalculate,
  showToast,
  initialValues,
}) => {
  const currentShamsiYear = getCurrentShamsiYear();
  const maxYear = currentShamsiYear + APP_DEFAULTS.MAX_FUTURE_YEAR_OFFSET;
  const minYear = APP_DEFAULTS.MIN_SHAMSI_YEAR;

  // Form State
  const [carModel, setCarModel] = useState<string>(initialValues?.carModel || APP_DEFAULTS.CAR_MODEL);
  const [year, setYear] = useState<number>(initialValues?.year || APP_DEFAULTS.YEAR);
  const [yearText, setYearText] = useState<string>(toPersianDigits(initialValues?.year || APP_DEFAULTS.YEAR));
  const [mileageInput, setMileageInput] = useState<string>(
    initialValues?.mileage ? formatPersianNumber(initialValues.mileage) : APP_DEFAULTS.MILEAGE_DISPLAY
  );
  const [basePriceInput, setBasePriceInput] = useState<string>(
    initialValues?.basePrice ? formatPersianNumber(initialValues.basePrice) : ''
  );
  const [isBasePriceManual, setIsBasePriceManual] = useState<boolean>(Boolean(initialValues?.basePrice));
  const [sellerPriceInput, setSellerPriceInput] = useState<string>(
    initialValues?.sellerPrice ? formatPersianNumber(initialValues.sellerPrice) : ''
  );

  // Modals
  const [showModelModal, setShowModelModal] = useState<boolean>(false);
  const [modelSearch, setModelSearch] = useState<string>('');
  const [modelCategoryTab, setModelCategoryTab] = useState<'all' | 'ikco' | 'saipa' | 'assembled' | 'imported'>('all');
  const [showYearModal, setShowYearModal] = useState<boolean>(false);

  // Day Price State
  const [dayPrice, setDayPrice] = useState<DayPriceInfo | null>(null);
  const [isPriceLoading, setIsPriceLoading] = useState<boolean>(false);
  const [priceError, setPriceError] = useState<string | null>(null);
  const priceRequestIdRef = useRef<number>(0);

  // Body Parts State
  const [bodyParts, setBodyParts] = useState<Record<BodyPartId, BodyPartState>>(() => {
    if (initialValues?.bodyParts) return initialValues.bodyParts;
    const initial: any = {};
    return initial;
  });

  // Chassis Parts State
  const [chassisParts, setChassisParts] = useState<Record<ChassisPartId, ChassisSeverity>>(() => {
    if (initialValues?.chassisParts) return initialValues.chassisParts;
    const initial: any = {};
    return initial;
  });

  // Technical Status
  const [engineReplaced, setEngineReplaced] = useState<boolean>(initialValues?.technical?.engineReplaced || false);
  const [rolledOver, setRolledOver] = useState<boolean>(initialValues?.technical?.rolledOver || false);
  const [hasAirbag, setHasAirbag] = useState<boolean>(initialValues?.technical?.hasAirbag !== undefined ? initialValues.technical.hasAirbag : true);
  const [airbagDeployed, setAirbagDeployed] = useState<boolean>(initialValues?.technical?.airbagDeployed || false);

  // Labels
  const [selectedLabels, setSelectedLabels] = useState<CarLabelId[]>(initialValues?.labels || []);

  // Fetch Day Price (IndexedDB 6h cache first -> /api/car-price)
  const fetchDayPrice = async (forceRefresh = false) => {
    const trimmedModel = carModel.trim();
    if (!trimmedModel || !year || year < minYear || year > maxYear) return;

    const reqId = ++priceRequestIdRef.current;

    if (!forceRefresh) {
      const cached = await getCachedDayPriceAsync(trimmedModel, year);
      if (cached) {
        if (reqId !== priceRequestIdRef.current) return;
        setDayPrice(cached);
        setPriceError(null);
        if ((!isBasePriceManual || !basePriceInput) && cached.avg > 0) {
          setBasePriceInput(formatPersianNumber(cached.avg));
        }
        return;
      }
    }

    setIsPriceLoading(true);
    setPriceError(null);

    try {
      const res = await fetch('/api/car-price', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ modelName: trimmedModel, year, forceRefresh }),
      });

      const data = await res.json();
      if (reqId !== priceRequestIdRef.current) return;

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'خطا در دریافت قیمت روز');
      }

      const priceInfo: DayPriceInfo = {
        min: data.min,
        max: data.max,
        avg: data.avg,
        date: data.date,
        note: data.note,
        sources: data.sources || [],
        isNextYearFallback: data.isNextYearFallback,
        effectiveYear: data.effectiveYear,
        isDiscontinued: Boolean(data.isDiscontinued),
        lastProductionYear: data.lastProductionYear,
        discontinuedNotice: data.discontinuedNotice,
        sampleCount: typeof data.sampleCount === 'number' ? data.sampleCount : undefined,
        fromLocalCache: false,
      };

      setDayPrice(priceInfo);
      await setCachedDayPriceAsync(trimmedModel, year, priceInfo);

      // Auto-populate base price input if not manually overridden
      if ((!isBasePriceManual || !basePriceInput) && priceInfo.avg > 0) {
        setBasePriceInput(formatPersianNumber(priceInfo.avg));
      }
    } catch (err: any) {
      if (reqId !== priceRequestIdRef.current) return;
      console.error(err);
      setPriceError('دریافت خودکار قیمت روز با مشکل مواجه شد. لطفاً قیمت بازار را به صورت دستی وارد کنید.');
    } finally {
      if (reqId === priceRequestIdRef.current) {
        setIsPriceLoading(false);
      }
    }
  };

  // Debounced trigger for day price on model or year change
  useEffect(() => {
    const trimmed = carModel.trim();
    if (!trimmed || year < minYear || year > maxYear) return;

    const timer = setTimeout(() => {
      fetchDayPrice(false);
    }, APP_TIMINGS.PRICE_FETCH_DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [carModel, year]);

  // Handle Quick Presets for Body Parts
  const handleBodyPreset = (preset: 'clean' | 'manual' | 'sides_painted' | 'all_painted') => {
    if (preset === 'clean') {
      setBodyParts({} as any);
      showToast('کلیه قطعات بدنه سالم و بدون رنگ تنظیم شدند.', 'info');
    } else if (preset === 'sides_painted') {
      // دور رنگ: درها، گلگیرها، سپرها، صندوق رنگ شده
      const updated: Record<BodyPartId, BodyPartState> = { ...bodyParts };
      const sideParts: BodyPartId[] = [
        'fender_front_right',
        'fender_front_left',
        'fender_rear_right',
        'fender_rear_left',
        'door_front_right',
        'door_front_left',
        'door_rear_right',
        'door_rear_left',
        'trunk',
        'front_bumper',
        'rear_bumper',
      ];
      sideParts.forEach((p) => {
        updated[p] = { damaged: false, painted: true };
      });
      // سقف و کاپوت و شیشه‌ها سالم بمانند
      const cleared = { ...updated };
      delete (cleared as any)['roof'];
      delete (cleared as any)['hood'];
      delete (cleared as any)['windshield'];
      delete (cleared as any)['rear_windshield'];
      setBodyParts(cleared);
      showToast('حالت «دور رنگ» برای قطعات جانبی اعمال شد.', 'info');
    } else if (preset === 'all_painted') {
      const updated: Record<BodyPartId, BodyPartState> = { ...bodyParts };
      const allPaintable: BodyPartId[] = [
        'front_bumper',
        'hood',
        'roof',
        'trunk',
        'rear_bumper',
        'fender_front_right',
        'fender_front_left',
        'fender_rear_right',
        'fender_rear_left',
        'door_front_right',
        'door_front_left',
        'door_rear_right',
        'door_rear_left',
      ];
      allPaintable.forEach((p) => {
        updated[p] = { damaged: false, painted: true };
      });
      setBodyParts(updated);
      showToast('حالت «تمام رنگ» برای کلیه قطعات اعمال شد.', 'info');
    }
  };

  // Number input handlers with formatting
  const handleNumberChange = (raw: string, setter: (val: string) => void) => {
    const num = parseNumberInput(raw);
    if (num === 0 && raw.trim() === '') {
      setter('');
    } else {
      setter(formatPersianNumber(num));
    }
  };

  // Label toggle
  const toggleLabel = (labelId: CarLabelId) => {
    setSelectedLabels((prev) =>
      prev.includes(labelId) ? prev.filter((l) => l !== labelId) : [...prev, labelId]
    );
  };

  // Form submission & validation
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!carModel.trim()) {
      showToast('لطفاً نام یا مدل خودرو را مشخص کنید.', 'error');
      return;
    }

    if (!year || year < minYear || year > maxYear) {
      showToast(`سال تولید باید بین ${toPersianDigits(minYear)} تا ${toPersianDigits(maxYear)} باشد.`, 'error');
      return;
    }

    const mileage = parseNumberInput(mileageInput);
    if (mileage > 2000000) {
      showToast('کارکرد خودرو نمی‌تواند بیش از ۲٬۰۰۰٬۰۰۰ کیلومتر باشد.', 'error');
      return;
    }

    const basePrice = parseNumberInput(basePriceInput);
    if (!basePrice || basePrice <= 0) {
      showToast('وارد کردن «قیمت نو / قیمت بازار» الزامی است.', 'error');
      return;
    }

    const sellerPrice = parseNumberInput(sellerPriceInput);

    const isYearSpecificBasePrice = Boolean(
      !isBasePriceManual &&
        dayPrice &&
        dayPrice.avg > 0 &&
        (dayPrice.isDiscontinued || dayPrice.effectiveYear === year || year < currentShamsiYear)
    );
    const hasLiveMarketSources = Boolean(
      !isBasePriceManual && dayPrice && dayPrice.sources && dayPrice.sources.length > 0
    );

    const calculationResult = calculateAppraisal({
      carModel,
      year,
      mileage,
      basePrice,
      sellerPrice: sellerPrice > 0 ? sellerPrice : undefined,
      bodyParts,
      chassisParts,
      technical: {
        engineReplaced,
        rolledOver,
        hasAirbag,
        airbagDeployed: hasAirbag ? airbagDeployed : false,
      },
      labels: selectedLabels,
      isYearSpecificBasePrice,
      hasLiveMarketSources,
    });

    onCalculate({
      carModel,
      year,
      mileage,
      basePrice,
      sellerPrice: sellerPrice > 0 ? sellerPrice : undefined,
      bodyParts,
      chassisParts,
      technical: {
        engineReplaced,
        rolledOver,
        hasAirbag,
        airbagDeployed: hasAirbag ? airbagDeployed : false,
      },
      labels: selectedLabels,
      calculationResult,
      dayPriceInfo: dayPrice,
    });
  };

  // Filtered cars for modal
  const filteredCars = CAR_MODELS.filter((car) => {
    const matchesCategory = modelCategoryTab === 'all' || car.category === modelCategoryTab;
    const matchesSearch =
      !modelSearch.trim() ||
      car.name.toLowerCase().includes(modelSearch.trim().toLowerCase()) ||
      car.brand.toLowerCase().includes(modelSearch.trim().toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Year options list
  const yearOptions: number[] = [];
  for (let y = maxYear; y >= minYear; y--) {
    yearOptions.push(y);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-3xl mx-auto pb-10">
      {/* ── CARD 1: اطلاعات پایه ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-5 pb-3 border-b border-slate-800">
          <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-sm">
            ۱
          </div>
          <div>
            <h2 className="text-base md:text-lg font-bold text-slate-100">اطلاعات پایه خودرو</h2>
            <p className="text-xs text-slate-400">مدل، سال ساخت، کارکرد و ارزش پایه بازار را مشخص کنید</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Model selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              مدل خودرو <span className="text-rose-400">*</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={carModel}
                onChange={(e) => setCarModel(e.target.value)}
                placeholder="مثلاً: پژو ۲۰۶ تیپ ۵ یا دنا پلاس"
                className="w-full bg-slate-950/70 border border-slate-700/80 rounded-2xl px-4 py-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-sky-500 transition"
              />
              <button
                type="button"
                onClick={() => setShowModelModal(true)}
                className="shrink-0 bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 rounded-2xl px-4 py-3 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
              >
                <Search className="w-4 h-4 text-sky-400" />
                <span className="hidden sm:inline">انتخاب از لیست</span>
                <span className="sm:hidden">لیست</span>
              </button>
            </div>
          </div>

          {/* Year & Mileage grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Year */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                سال تولید شمسی <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={yearText}
                  onChange={(e) => {
                    const raw = e.target.value;
                    if (!raw.trim()) {
                      setYearText('');
                      return;
                    }
                    const parsed = parseNumberInput(raw);
                    setYearText(toPersianDigits(parsed));
                    if (parsed >= minYear && parsed <= maxYear) {
                      setYear(parsed);
                    }
                  }}
                  onBlur={() => {
                    const parsed = parseNumberInput(yearText);
                    if (parsed >= minYear && parsed <= maxYear) {
                      setYear(parsed);
                      setYearText(toPersianDigits(parsed));
                    } else {
                      setYearText(toPersianDigits(year));
                    }
                  }}
                  className="w-full bg-slate-950/70 border border-slate-700/80 rounded-2xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-sky-500 transition pl-12"
                />
                <button
                  type="button"
                  onClick={() => setShowYearModal(true)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-sky-400 p-1.5"
                  title="انتخاب سال از لیست"
                >
                  <Calendar className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                سقف سال مجاز: {toPersianDigits(maxYear)} (سال جاری + ۱)
              </p>
            </div>

            {/* Mileage */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                کارکرد (کیلومتر) <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={mileageInput}
                  onChange={(e) => handleNumberChange(e.target.value, setMileageInput)}
                  placeholder="مثلاً: ۱۲۰٬۰۰۰"
                  className="w-full bg-slate-950/70 border border-slate-700/80 rounded-2xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-sky-500 transition pl-10"
                />
                <Gauge className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                حداکثر تا ۲٬۰۰۰٬۰۰۰ کیلومتر
              </p>
            </div>
          </div>

          {/* ★ Real-Time Day Price Card (Grounding) */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-sky-950/30 border border-sky-500/30 shadow-md">
            <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
              <div className="flex items-center gap-2 flex-wrap">
                <Sparkles className="w-4 h-4 text-sky-400" />
                <span className="text-xs font-bold text-sky-300">
                  {dayPrice?.isDiscontinued
                    ? 'میانگین قیمت در آگهی‌های بازار'
                    : 'قیمت روز خودرو در بازار ایران'}
                </span>
                {dayPrice?.isDiscontinued ? (
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                    توقف تولید • میانگین دیوار و سایت‌های معتبر
                  </span>
                ) : (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
                    مرجع: ایران‌جیب (iranjib.ir)
                  </span>
                )}
              </div>

              <button
                type="button"
                onClick={() => fetchDayPrice(true)}
                disabled={isPriceLoading}
                className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 disabled:opacity-50 transition"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isPriceLoading ? 'animate-spin' : ''}`} />
                <span>به‌روزرسانی قیمت</span>
              </button>
            </div>

            {isPriceLoading ? (
              <div className="py-4 text-center">
                <div className="inline-block w-5 h-5 border-2 border-sky-400 border-t-transparent rounded-full animate-spin mb-1.5" />
                <p className="text-xs text-slate-400">
                  در حال جستجو و استعلام قیمت از ایران‌جیب، دیوار، باما و سایت‌های معتبر خودرو...
                </p>
              </div>
            ) : dayPrice ? (
              <div className="space-y-2.5">
                {dayPrice.isDiscontinued && (
                  <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-500/35 text-amber-200 text-xs leading-relaxed flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <span className="font-bold block text-amber-300">
                        اطلاعیه خودروهای توقف تولید (قیمت میانگین):
                      </span>
                      <p>
                        {dayPrice.discontinuedNotice ||
                          'تولید این خودرو متوقف شده است؛ قیمت نمایش‌داده‌شده میانگین آگهی‌های دیوار، باما و سایت‌های معتبر خودرو بوده و به دلیل توقف تولید، قیمت روز و دقیق آن محسوب نمی‌شود.'}
                      </p>
                      {dayPrice.lastProductionYear && year > dayPrice.lastProductionYear && (
                        <p className="text-[11px] opacity-90">
                          آخرین سال تولید رسمی این مدل حدود سال {toPersianDigits(dayPrice.lastProductionYear)} بوده و میانگین بر اساس آخرین مدل‌های موجود ({toPersianDigits(dayPrice.effectiveYear)}) محاسبه شده است.
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {dayPrice.isNextYearFallback && !dayPrice.isDiscontinued && (
                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>
                      برای مدل {toPersianDigits(year)} هنوز قیمت بازار رسمی وجود ندارد؛ قیمت مدل {toPersianDigits(dayPrice.effectiveYear)} نمایش داده شده و محاسبات با همین مبنا انجام می‌شود.
                    </span>
                  </div>
                )}

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[10px] mb-0.5">
                      {dayPrice.isDiscontinued ? 'میانگین قیمت آگهی‌ها' : 'میانگین منطقی روز'}
                    </span>
                    <span className="font-bold text-sky-300 text-sm">
                      {formatPersianNumber(dayPrice.avg)} تومان
                    </span>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block text-[10px] mb-0.5">بازه معاملاتی</span>
                    <span className="font-semibold text-slate-200 text-xs">
                      {formatPersianNumber(dayPrice.min)} الی {formatPersianNumber(dayPrice.max)}
                    </span>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 col-span-2 sm:col-span-1">
                    <span className="text-slate-400 block text-[10px] mb-0.5">تاریخ استعلام</span>
                    <span className="text-slate-300 text-xs">{dayPrice.date}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap text-[11px]">
                  <div className="flex items-center gap-1.5 flex-wrap text-slate-400">
                    {dayPrice.fromLocalCache && (
                      <span className="inline-flex items-center gap-1 bg-sky-500/15 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded-full text-[10px] font-semibold">
                        <Database className="w-3 h-3" />
                        <span>بازیابی فوری از دیتابیس محلی (&lt; ۶ ساعت)</span>
                      </span>
                    )}
                    {typeof dayPrice.sampleCount === 'number' && dayPrice.sampleCount > 0 && (
                      <span className="inline-flex items-center gap-1 bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full text-[10px] font-semibold">
                        <span>بر اساس {toPersianDigits(dayPrice.sampleCount)} آگهی تأییدشده</span>
                      </span>
                    )}
                  </div>
                </div>

                {dayPrice.sources && dayPrice.sources.length > 0 && (
                  <div className="text-[11px] text-slate-400 flex items-center gap-1.5 flex-wrap">
                    <span>منابع استعلام:</span>
                    {dayPrice.sources.map((src, idx) => (
                      <span key={idx} className="bg-slate-800 px-2 py-0.5 rounded text-slate-300 text-[10px]">
                        {src}
                      </span>
                    ))}
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setIsBasePriceManual(false);
                    setBasePriceInput(formatPersianNumber(dayPrice.avg));
                    showToast('قیمت میانگین بازار در فیلد قیمت نو اعمال شد.', 'success');
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-sky-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-98"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-sky-400" />
                  <span>
                    {dayPrice.isDiscontinued
                      ? `استفاده از میانگین بازار (${formatToman(dayPrice.avg)})`
                      : `استفاده از این قیمت (${formatToman(dayPrice.avg)})`}
                  </span>
                </button>
              </div>
            ) : priceError ? (
              <div className="text-xs text-amber-300/90 py-1">
                {priceError}
              </div>
            ) : (
              <p className="text-xs text-slate-400">در حال دریافت داده...</p>
            )}
          </div>

          {/* Base Price & Asking Price inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Base Price */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                قیمت نو / قیمت بازار (تومان) <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={basePriceInput}
                  onChange={(e) => {
                    setIsBasePriceManual(true);
                    handleNumberChange(e.target.value, setBasePriceInput);
                  }}
                  placeholder="مثلاً: ۷۵۰٬۰۰۰٬۰۰۰"
                  className="w-full bg-slate-950/70 border border-slate-700/80 rounded-2xl px-4 py-3 text-sm text-slate-100 font-medium focus:outline-none focus:border-sky-500 transition pl-10"
                />
                <CircleDollarSign className="w-4 h-4 text-sky-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">مبنای محاسبه افت قیمت‌ها</p>
            </div>

            {/* Seller Asking Price (Optional) */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>قیمت اعلامی فروشنده (تومان)</span>
                <span className="text-[10px] text-slate-400 font-normal">اختیاری</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={sellerPriceInput}
                  onChange={(e) => handleNumberChange(e.target.value, setSellerPriceInput)}
                  placeholder="مثلاً: ۷۲۰٬۰۰۰٬۰۰۰"
                  className="w-full bg-slate-950/70 border border-slate-700/80 rounded-2xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-sky-500 transition pl-10"
                />
                <Tag className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">جهت سنجش ارزش خرید و داوری منصفانه</p>
            </div>
          </div>
        </div>
      </div>

      {/* ── CARD 2: بدنه و قطعات (سه بعدی) ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-800">
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-sm">
            ۲
          </div>
          <div>
            <h2 className="text-base md:text-lg font-bold text-slate-100">کارشناسی سه‌بعدی بدنه و قطعات</h2>
            <p className="text-xs text-slate-400">قطعه مورد نظر را روی مدل لمس کرده و وضعیت رنگ یا ضربه را ثبت کنید</p>
          </div>
        </div>

        <ThreeCarBody
          bodyParts={bodyParts}
          onChange={(newParts) => setBodyParts(newParts)}
          onSelectPreset={handleBodyPreset}
        />
      </div>

      {/* ── CARD 3: شاسی و ستون‌ها (سه بعدی) ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-800">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm">
            ۳
          </div>
          <div>
            <h2 className="text-base md:text-lg font-bold text-slate-100">کارشناسی سه‌بعدی اسکلت شاسی و ستون‌ها</h2>
            <p className="text-xs text-slate-400">بررسی سلامت لنگه‌های شاسی، ستون‌های A/B/C، سینی‌ها و تیر سقف</p>
          </div>
        </div>

        <ThreeChassis
          chassisParts={chassisParts}
          onChange={(newParts) => setChassisParts(newParts)}
        />
      </div>

      {/* ── CARD 4: وضعیت فنی و تصادفات ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-5 pb-3 border-b border-slate-800">
          <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-sm">
            ۴
          </div>
          <div>
            <h2 className="text-base md:text-lg font-bold text-slate-100">وضعیت فنی و تصادفات اساسی</h2>
            <p className="text-xs text-slate-400">سوابق تعویض موتور، واژگونی و عملکرد سیستم ایربگ</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Engine Replaced */}
          <div
            onClick={() => setEngineReplaced(!engineReplaced)}
            className={`p-3.5 rounded-2xl border cursor-pointer select-none transition flex items-center justify-between ${
              engineReplaced
                ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
            }`}
          >
            <div>
              <span className="text-sm font-semibold block">تعویض موتور (۱۲٪ افت)</span>
              <span className="text-[11px] text-slate-400 block mt-0.5">ثبت تعویض سیلندر در سند خودرو</span>
            </div>
            <div className={`w-5 h-5 rounded-lg flex items-center justify-center text-xs font-bold border ${
              engineReplaced ? 'bg-rose-500 text-white border-rose-400' : 'border-slate-700 bg-slate-900'
            }`}>
              {engineReplaced && '✓'}
            </div>
          </div>

          {/* Rolled Over */}
          <div
            onClick={() => setRolledOver(!rolledOver)}
            className={`p-3.5 rounded-2xl border cursor-pointer select-none transition flex items-center justify-between ${
              rolledOver
                ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
            }`}
          >
            <div>
              <span className="text-sm font-semibold block">سابقه واژگونی / چپ‌کردگی (۲۵٪ افت)</span>
              <span className="text-[11px] text-slate-400 block mt-0.5">آسیب سقف و کلاف اتاق خودرو</span>
            </div>
            <div className={`w-5 h-5 rounded-lg flex items-center justify-center text-xs font-bold border ${
              rolledOver ? 'bg-rose-500 text-white border-rose-400' : 'border-slate-700 bg-slate-900'
            }`}>
              {rolledOver && '✓'}
            </div>
          </div>

          {/* Has Airbag */}
          <div
            onClick={() => setHasAirbag(!hasAirbag)}
            className={`p-3.5 rounded-2xl border cursor-pointer select-none transition flex items-center justify-between ${
              !hasAirbag
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-200'
                : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
            }`}
          >
            <div>
              <span className="text-sm font-semibold block">فاقد ایربگ کارخانه‌ای (۵٪ افت)</span>
              <span className="text-[11px] text-slate-400 block mt-0.5">مدل‌های فاقد کیسه هوای سرنشین</span>
            </div>
            <div className={`w-5 h-5 rounded-lg flex items-center justify-center text-xs font-bold border ${
              !hasAirbag ? 'bg-amber-500 text-white border-amber-400' : 'border-slate-700 bg-slate-900'
            }`}>
              {!hasAirbag && '✓'}
            </div>
          </div>

          {/* Airbag Deployed */}
          {hasAirbag && (
            <div
              onClick={() => setAirbagDeployed(!airbagDeployed)}
              className={`p-3.5 rounded-2xl border cursor-pointer select-none transition flex items-center justify-between ${
                airbagDeployed
                  ? 'bg-rose-500/15 border-rose-500/40 text-rose-200'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
              }`}
            >
              <div>
                <span className="text-sm font-semibold block">ایربگ باز شده در تصادف (۸٪ افت)</span>
                <span className="text-[11px] text-slate-400 block mt-0.5">عملکرد چاشنی کیسه هوا در برخورد</span>
              </div>
              <div className={`w-5 h-5 rounded-lg flex items-center justify-center text-xs font-bold border ${
                airbagDeployed ? 'bg-rose-500 text-white border-rose-400' : 'border-slate-700 bg-slate-900'
              }`}>
                {airbagDeployed && '✓'}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── CARD 5: برچسب وضعیت کلی ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-800">
          <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-sm">
            ۵
          </div>
          <div>
            <h2 className="text-base md:text-lg font-bold text-slate-100">برچسب وضعیت کلی (اختیاری)</h2>
            <p className="text-xs text-slate-400">ویژگی‌ها و نوع کاربری خودرو که بر قیمت تاثیر دارند</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {(Object.entries(CAR_LABELS_INFO) as [CarLabelId, any][]).map(([labelId, meta]) => {
            const isSelected = selectedLabels.includes(labelId);
            return (
              <div
                key={labelId}
                onClick={() => toggleLabel(labelId)}
                className={`p-3.5 rounded-2xl border cursor-pointer select-none transition flex items-center justify-between ${
                  isSelected
                    ? 'bg-sky-500/15 border-sky-500/40 text-sky-200'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold">{meta.name}</span>
                    <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-sky-300">
                      {meta.percent}٪ افت
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-1">{meta.description}</span>
                </div>
                <div className={`w-5 h-5 rounded-lg flex items-center justify-center text-xs font-bold border ${
                  isSelected ? 'bg-sky-500 text-white border-sky-400' : 'border-slate-700 bg-slate-900'
                }`}>
                  {isSelected && '✓'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── CARD 6: دکمه اقدام نهایی ── */}
      <div className="pt-2">
        <button
          type="submit"
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-l from-sky-500 via-indigo-600 to-purple-600 hover:from-sky-400 hover:to-purple-500 text-white font-extrabold text-base md:text-lg shadow-xl shadow-sky-500/25 active:scale-98 transition flex items-center justify-center gap-2.5 cursor-pointer"
        >
          <Sparkles className="w-5 h-5" />
          <span>محاسبهٔ قیمت منطقی و ارزش خرید</span>
        </button>
      </div>

      {/* MODAL: انتخاب خودرو */}
      {showModelModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-slate-100 text-sm">انتخاب خودرو از لیست بازار ایران</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowModelModal(false)}
                className="p-1 text-slate-400 hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Search Box */}
            <div className="p-3 border-b border-slate-800/80">
              <input
                type="text"
                value={modelSearch}
                onChange={(e) => setModelSearch(e.target.value)}
                placeholder="جستجوی مدل (مثلاً پارس، دنا، کوییک، جک)..."
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-sky-500"
                autoFocus
              />

              {/* Categories Tabs */}
              <div className="flex gap-1.5 overflow-x-auto pt-2.5">
                {[
                  { id: 'all', label: 'همه' },
                  { id: 'ikco', label: 'ایران‌خودرو' },
                  { id: 'saipa', label: 'سایپا' },
                  { id: 'assembled', label: 'مونتاژی/چینی' },
                  { id: 'imported', label: 'وارداتی' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setModelCategoryTab(tab.id as any)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition ${
                      modelCategoryTab === tab.id
                        ? 'bg-sky-500 text-white'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* List */}
            <div className="p-3 overflow-y-auto flex-1 space-y-1.5">
              {filteredCars.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  خودرویی با این مشخصات یافت نشد. می‌توانید نام را دستی وارد کنید.
                </div>
              ) : (
                filteredCars.map((car) => (
                  <div
                    key={car.id}
                    onClick={() => {
                      setIsBasePriceManual(false);
                      setCarModel(car.name);
                      setShowModelModal(false);
                      setModelSearch('');
                    }}
                    className="p-3 rounded-xl bg-slate-950/60 hover:bg-sky-500/15 hover:border-sky-500/40 border border-slate-800/60 cursor-pointer flex items-center justify-between text-xs transition"
                  >
                    <span className="font-semibold text-slate-200">{car.name}</span>
                    <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                      {car.categoryLabel}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: انتخاب سال */}
      {showYearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-sm max-h-[75vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-slate-100 text-sm">انتخاب سال تولید شمسی</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowYearModal(false)}
                className="p-1 text-slate-400 hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 overflow-y-auto flex-1 grid grid-cols-3 gap-2">
              {yearOptions.map((y) => (
                <button
                  key={y}
                  type="button"
                  onClick={() => {
                    setIsBasePriceManual(false);
                    setYear(y);
                    setYearText(toPersianDigits(y));
                    setShowYearModal(false);
                  }}
                  className={`py-2 px-1 text-center rounded-xl text-xs font-bold transition ${
                    year === y
                      ? 'bg-sky-500 text-white'
                      : 'bg-slate-950/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                >
                  {toPersianDigits(y)}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </form>
  );
};
