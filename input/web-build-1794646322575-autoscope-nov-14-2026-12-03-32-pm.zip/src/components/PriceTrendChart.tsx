import React, { useState, useMemo, useEffect } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { generate30DayPriceTrend, PricePoint } from '../utils/priceTrend';
import {
  toPersianDigits,
  formatPersianNumber,
  formatToman,
} from '../utils/persian';
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Maximize2,
  Minimize2,
} from 'lucide-react';

interface PriceTrendChartProps {
  basePrice: number;
  carModel: string;
}

export const PriceTrendChart: React.FC<PriceTrendChartProps> = ({
  basePrice,
  carModel,
}) => {
  const [rangeDays, setRangeDays] = useState<30 | 15 | 7>(30);
  const [isLightTheme, setIsLightTheme] = useState<boolean>(() =>
    typeof document !== 'undefined' ? document.documentElement.classList.contains('theme-light') : false
  );

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    const syncTheme = () => setIsLightTheme(root.classList.contains('theme-light'));
    syncTheme();
    const observer = new MutationObserver(syncTheme);
    observer.observe(root, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  // Generate full 30-day trend data
  const trendAnalysis = useMemo(() => {
    return generate30DayPriceTrend(basePrice, carModel);
  }, [basePrice, carModel]);

  // Filter points according to selected range
  const chartData = useMemo(() => {
    const sliceCount = rangeDays;
    return trendAnalysis.points.slice(trendAnalysis.points.length - sliceCount);
  }, [trendAnalysis.points, rangeDays]);

  // Compute stats for current visible range
  const rangeStats = useMemo(() => {
    const prices = chartData.map((d) => d.price);
    const start = prices[0];
    const end = prices[prices.length - 1];
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const diff = end - start;
    const percent = start > 0 ? Number(((diff / start) * 100).toFixed(1)) : 0;
    const isUp = diff >= 0;
    return { start, end, min, max, diff, percent, isUp };
  }, [chartData]);

  // Y-Axis tick formatter: format as Billion or Million Tomans in Persian
  const formatYAxisTick = (val: number) => {
    if (val >= 1000000000) {
      const billions = (val / 1000000000).toFixed(2).replace(/\.00$/, '');
      return `${toPersianDigits(billions)} م.ت`;
    }
    const millions = Math.round(val / 1000000);
    return `${toPersianDigits(millions)} م`;
  };

  // Custom Interactive Tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data: PricePoint = payload[0].payload;
      const diffFromStart = data.price - rangeStats.start;
      const diffPercent = rangeStats.start > 0 ? ((diffFromStart / rangeStats.start) * 100).toFixed(1) : '0';

      return (
        <div className="bg-slate-900/95 border border-slate-700/80 p-3 rounded-2xl shadow-2xl backdrop-blur-md text-right text-xs space-y-1.5 min-w-[190px]">
          <div className="flex items-center justify-between text-slate-400 pb-1 border-b border-slate-800 text-[11px]">
            <span className="flex items-center gap-1 font-medium">
              <Calendar className="w-3 h-3 text-sky-400" />
              <span>{data.fullDate}</span>
            </span>
            {data.dayIndex === 0 && (
              <span className="bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded text-[10px] font-bold">
                امروز
              </span>
            )}
          </div>

          <div>
            <span className="text-[10px] text-slate-400 block">قیمت روز بازار آزاد:</span>
            <span className="font-extrabold text-sm text-sky-300 font-mono">
              {formatPersianNumber(data.price)}{' '}
              <span className="text-[10px] text-slate-400 font-normal">تومان</span>
            </span>
          </div>

          {data.dayIndex !== chartData[0].dayIndex && (
            <div className="text-[10px] pt-1 border-t border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">تغییر نسبت به ابتدای بازه:</span>
              <span
                className={`font-semibold flex items-center gap-0.5 ${
                  diffFromStart >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {diffFromStart >= 0 ? '+' : ''}
                {toPersianDigits(diffPercent)}٪
              </span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm space-y-4">
      {/* Chart Header & Trend Summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm md:text-base font-bold text-slate-100">
              روند نوسانات قیمت ۳۰ روز اخیر در بازار
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            تحلیل تاریخی تغییرات ارزش بازار خودروی {carModel}
          </p>
        </div>

        {/* Range Selector Pills */}
        <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          {[
            { days: 30, label: '۳۰ روز' },
            { days: 15, label: '۱۵ روز' },
            { days: 7, label: '۷ روز' },
          ].map((tab) => (
            <button
              key={tab.days}
              type="button"
              onClick={() => setRangeDays(tab.days as any)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                rangeDays === tab.days
                  ? 'bg-sky-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Range Key Performance Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
        {/* Trend Indicator */}
        <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 block mb-0.5">
              روند {toPersianDigits(rangeDays)} روزه
            </span>
            <div
              className={`font-black text-xs md:text-sm flex items-center gap-1 ${
                rangeStats.isUp ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {rangeStats.isUp ? (
                <ArrowUpRight className="w-4 h-4 shrink-0" />
              ) : (
                <ArrowDownRight className="w-4 h-4 shrink-0" />
              )}
              <span>
                {rangeStats.isUp ? '+' : ''}
                {toPersianDigits(rangeStats.percent)}٪{' '}
                {rangeStats.isUp ? '(رشد)' : '(افت)'}
              </span>
            </div>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">
            {formatPersianNumber(Math.abs(rangeStats.diff))} ت
          </span>
        </div>

        {/* Highest Price */}
        <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400">بالاترین قیمت بازه</span>
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400/80" />
          </div>
          <span className="font-bold text-xs md:text-sm text-slate-200 mt-0.5 block font-mono">
            {formatPersianNumber(rangeStats.max)} تومان
          </span>
        </div>

        {/* Lowest Price */}
        <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400">پایین‌ترین قیمت بازه</span>
            <TrendingDown className="w-3.5 h-3.5 text-rose-400/80" />
          </div>
          <span className="font-bold text-xs md:text-sm text-slate-200 mt-0.5 block font-mono">
            {formatPersianNumber(rangeStats.min)} تومان
          </span>
        </div>
      </div>

      {/* Recharts Area Chart */}
      <div className="w-full h-[240px] md:h-[270px] pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={chartData}
            margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
          >
            <defs>
              <linearGradient id="priceTrendGradient" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="5%"
                  stopColor={rangeStats.isUp ? '#0ea5e9' : '#f43f5e'}
                  stopOpacity={0.45}
                />
                <stop
                  offset="95%"
                  stopColor={rangeStats.isUp ? '#0ea5e9' : '#f43f5e'}
                  stopOpacity={0.0}
                />
              </linearGradient>
            </defs>

            <CartesianGrid
              strokeDasharray="3 3"
              stroke={isLightTheme ? '#e2e8f0' : '#1e293b'}
              vertical={false}
            />

            <XAxis
              dataKey="dateLabel"
              tickLine={false}
              axisLine={{ stroke: isLightTheme ? '#cbd5e1' : '#334155' }}
              tick={{ fill: isLightTheme ? '#475569' : '#94a3b8', fontSize: 10, fontFamily: 'Vazirmatn' }}
              interval="preserveStartEnd"
              minTickGap={25}
            />

            <YAxis
              domain={['dataMin - 20000000', 'dataMax + 20000000']}
              tickFormatter={formatYAxisTick}
              tickLine={false}
              axisLine={{ stroke: isLightTheme ? '#cbd5e1' : '#334155' }}
              tick={{ fill: isLightTheme ? '#475569' : '#94a3b8', fontSize: 10, fontFamily: 'Vazirmatn' }}
              width={65}
            />

            <Tooltip content={<CustomTooltip />} />

            <Area
              type="monotone"
              dataKey="price"
              stroke={rangeStats.isUp ? '#38bdf8' : '#fb7185'}
              strokeWidth={2.5}
              fillOpacity={1}
              fill="url(#priceTrendGradient)"
              activeDot={{
                r: 5,
                stroke: '#ffffff',
                strokeWidth: 2,
                fill: rangeStats.isUp ? '#0284c7' : '#e11d48',
              }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Chart Footer Notice */}
      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-800/80">
        <span>مرجع داده‌های بازار: معاملات ثبت‌شده بازار آزاد و ایران‌جیب</span>
        <span>واحد مبالغ: تومان</span>
      </div>
    </div>
  );
};
