import React, { useState } from 'react';
import { User, signInWithPopup, signOut } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { toPersianDigits } from '../utils/persian';
import {
  UserCircle2,
  Cloud,
  ShieldCheck,
  History,
  Calculator,
  LogOut,
  RefreshCw,
  Sun,
  Moon,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Smartphone,
} from 'lucide-react';

interface AccountViewProps {
  user: User | null;
  authReady: boolean;
  recordsCount: number;
  localGuestCount: number;
  isSyncing: boolean;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onGoToHistory: () => void;
  onGoToPricing: () => void;
  onManualSync: () => Promise<void>;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

function mapAuthErrorToPersian(err: unknown): string {
  const code = (err as { code?: string })?.code || '';
  switch (code) {
    case 'auth/popup-closed-by-user':
      return 'پنجره ورود گوگل بسته شد. برای ورود دوباره تلاش کنید.';
    case 'auth/cancelled-popup-request':
      return 'درخواست قبلی ورود لغو شد. لطفاً مجدداً روی دکمه ورود کلیک کنید.';
    case 'auth/popup-blocked':
      return 'مرورگر پنجره بازشو (Popup) را مسدود کرده است. لطفاً دسترسی Popup را برای این صفحه فعال کنید.';
    case 'auth/network-request-failed':
      return 'خطا در اتصال به اینترنت. لطفاً وضعیت شبکه خود را بررسی کنید.';
    case 'auth/too-many-requests':
      return 'تعداد تلاش‌های ورود بیش از حد مجاز بوده است. چند لحظه بعد دوباره امتحان کنید.';
    default:
      return 'ورود با حساب گوگل با خطا مواجه شد. لطفاً دوباره تلاش کنید.';
  }
}

export const AccountView: React.FC<AccountViewProps> = ({
  user,
  authReady,
  recordsCount,
  localGuestCount,
  isSyncing,
  theme,
  onToggleTheme,
  onGoToHistory,
  onGoToPricing,
  onManualSync,
  showToast,
}) => {
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [avatarError, setAvatarError] = useState(false);

  const handleGoogleSignIn = async () => {
    setAuthError(null);
    setIsLoggingIn(true);
    try {
      await signInWithPopup(auth, googleProvider);
      showToast('ورود با حساب گوگل با موفقیت انجام شد.', 'success');
    } catch (err) {
      const msg = mapAuthErrorToPersian(err);
      setAuthError(msg);
      showToast(msg, 'error');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await signOut(auth);
      showToast('با موفقیت از حساب کاربری خود خارج شدید.', 'info');
    } catch {
      showToast('خطا در خروج از حساب کاربری.', 'error');
    } finally {
      setIsLoggingOut(false);
    }
  };

  if (!authReady) {
    return (
      <div className="max-w-xl mx-auto py-16 text-center space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-sky-500/15 text-sky-400 flex items-center justify-center mx-auto animate-pulse">
          <UserCircle2 className="w-6 h-6" />
        </div>
        <p className="text-xs text-slate-400">در حال بررسی وضعیت حساب کاربری...</p>
      </div>
    );
  }

  // ── Logged-In Account Dashboard ──
  if (user) {
    return (
      <div className="max-w-2xl mx-auto space-y-6 pb-12 animate-in fade-in duration-300">
        {/* Profile Header Card */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl relative overflow-hidden">
          <div className="absolute -top-20 -left-20 w-52 h-52 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-right">
            {user.photoURL && !avatarError ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'تصویر کاربر'}
                onError={() => setAvatarError(true)}
                referrerPolicy="no-referrer"
                className="w-20 h-20 rounded-3xl object-cover border-2 border-sky-500/40 shadow-lg shrink-0"
              />
            ) : (
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white text-2xl font-black shadow-lg shrink-0">
                {(user.displayName || user.email || 'A').charAt(0).toUpperCase()}
              </div>
            )}

            <div className="flex-1 space-y-1.5">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h1 className="text-lg md:text-xl font-black text-slate-100">
                  {user.displayName || 'کاربر اتو اسکوپ'}
                </h1>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  تأیید شده با گوگل
                </span>
              </div>

              <p className="text-xs text-slate-400 font-mono" dir="ltr">
                {user.email}
              </p>

              <div className="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="inline-flex items-center gap-1.5 text-[11px] text-sky-300 bg-sky-500/10 border border-sky-500/20 px-3 py-1 rounded-xl">
                  <Cloud className={`w-3.5 h-3.5 ${isSyncing ? 'animate-pulse' : ''}`} />
                  {isSyncing ? 'در حال همگام‌سازی ابری...' : 'همگام‌سازی ابری فعال'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Account Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center shrink-0">
              <History className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] text-slate-400 block">گزارش‌های ذخیره‌شده</span>
              <span className="text-lg font-black text-slate-100">
                {toPersianDigits(recordsCount)} <span className="text-xs font-normal text-slate-400">مورد</span>
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onToggleTheme}
            className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 rounded-2xl p-4 flex items-center gap-3 text-right transition active:scale-95"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0">
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5 text-sky-400" />}
            </div>
            <div>
              <span className="text-[11px] text-slate-400 block">تم ظاهری ذخیره شده</span>
              <span className="text-sm font-bold text-slate-100">
                {theme === 'dark' ? 'حالت تیره (شب)' : 'حالت روشن (روز)'}
              </span>
            </div>
          </button>
        </div>

        {/* Quick Actions */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-3">
          <h2 className="text-sm font-bold text-slate-200 mb-2">مدیریت حساب و فعالیت‌ها</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={onGoToPricing}
              className="py-3 px-4 rounded-2xl bg-gradient-to-l from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 transition active:scale-95"
            >
              <Calculator className="w-4 h-4" />
              <span>کارشناسی خودروی جدید</span>
            </button>

            <button
              type="button"
              onClick={onGoToHistory}
              className="py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-bold flex items-center justify-center gap-2 border border-slate-700 transition active:scale-95"
            >
              <History className="w-4 h-4 text-sky-400" />
              <span>مشاهده تاریخچه کارشناسی‌ها</span>
            </button>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={onManualSync}
              disabled={isSyncing}
              className="flex-1 py-2.5 px-4 rounded-2xl bg-slate-950/60 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2 transition disabled:opacity-60"
            >
              <RefreshCw className={`w-4 h-4 text-emerald-400 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>به‌روزرسانی و همگام‌سازی سوابق</span>
            </button>

            <button
              type="button"
              onClick={handleLogout}
              disabled={isLoggingOut}
              className="flex-1 py-2.5 px-4 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center justify-center gap-2 transition disabled:opacity-60"
            >
              <LogOut className="w-4 h-4" />
              <span>{isLoggingOut ? 'در حال خروج...' : 'خروج از حساب کاربری'}</span>
            </button>
          </div>
        </div>

        {/* Security Note */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex items-start gap-3 text-xs text-slate-400 leading-relaxed">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <p>
            تمامی گزارش‌های کارشناسی و تنظیمات ظاهری شما به صورت اختصاصی و رمزگذاری‌شده به حساب گوگل شما متصل هستند و با ورود در هر دستگاه دیگری بلافاصله بازیابی می‌شوند.
          </p>
        </div>
      </div>
    );
  }

  // ── Logged-Out Login Screen ──
  return (
    <div className="max-w-lg mx-auto space-y-6 pb-12 animate-in fade-in duration-300">
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-56 h-56 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-56 h-56 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative text-center space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-sky-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white mx-auto shadow-xl shadow-sky-500/25">
            <UserCircle2 className="w-9 h-9" />
          </div>

          <div className="space-y-1.5">
            <h1 className="text-xl md:text-2xl font-black text-slate-100">
              ورود و ساخت حساب کاربری
            </h1>
            <p className="text-xs md:text-sm text-slate-400 leading-relaxed">
              با ورود از طریق حساب گوگل، تمام کارشناسی‌ها و سوابق قیمت‌گذاری شما برای همیشه در فضای ابری ذخیره می‌شوند.
            </p>
          </div>

          {/* Feature Highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-right pt-2">
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 space-y-1">
              <Cloud className="w-4 h-4 text-sky-400" />
              <div className="text-xs font-bold text-slate-200">ذخیره دائمی ابری</div>
              <p className="text-[11px] text-slate-400">جلوگیری از پاک شدن سوابق با بستن مرورگر</p>
            </div>
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 space-y-1">
              <Smartphone className="w-4 h-4 text-indigo-400" />
              <div className="text-xs font-bold text-slate-200">دسترسی چنددستگاهی</div>
              <p className="text-[11px] text-slate-400">مشاهده گزارش‌ها در موبایل و لپ‌تاپ</p>
            </div>
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 space-y-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <div className="text-xs font-bold text-slate-200">امنیت و حریم خصوصی</div>
              <p className="text-[11px] text-slate-400">دسترسی اختصاصی تنها برای خود شما</p>
            </div>
          </div>

          {localGuestCount > 0 && (
            <div className="bg-sky-500/10 border border-sky-500/30 rounded-2xl p-3.5 text-xs text-sky-200 flex items-start gap-2.5 text-right">
              <Sparkles className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <span>
                شما هم‌اکنون{' '}
                <strong className="font-black text-slate-100">
                  {toPersianDigits(localGuestCount)} کارشناسی
                </strong>{' '}
                در این دستگاه دارید که بلافاصله پس از ورود به حساب گوگل منتقل و ذخیره خواهند شد.
              </span>
            </div>
          )}

          {authError && (
            <div className="bg-rose-500/10 border border-rose-500/30 rounded-2xl p-3.5 text-xs text-rose-200 flex items-start gap-2 text-right">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{authError}</span>
            </div>
          )}

          {/* Google Sign-In Button */}
          <div className="pt-2 space-y-3">
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isLoggingIn}
              className="w-full py-3.5 px-5 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-sm shadow-xl transition active:scale-[0.98] flex items-center justify-center gap-3 disabled:opacity-60 border border-slate-200"
            >
              {isLoggingIn ? (
                <RefreshCw className="w-5 h-5 animate-spin text-sky-600" />
              ) : (
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
                  />
                </svg>
              )}
              <span>
                {isLoggingIn ? 'در حال اتصال به حساب گوگل...' : 'ورود سریع با حساب گوگل (Google)'}
              </span>
            </button>

            <button
              type="button"
              onClick={onGoToPricing}
              className="w-full py-2.5 px-4 rounded-2xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold transition"
            >
              ادامه بدون ورود (ذخیره موقت در همین دستگاه)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
