import React from 'react';
import { AppraisalRecord } from '../types';
import { toPersianDigits, formatPersianNumber } from '../utils/persian';
import { APP_DEFAULTS } from '../utils/config';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  History,
  HelpCircle,
  TrendingUp,
  Layers,
  ChevronLeft,
  Car,
} from 'lucide-react';

interface HomeViewProps {
  onStartPricing: (presetModel?: string) => void;
  onGoToHistory: () => void;
  onGoToFaq: () => void;
  lastRecord: AppraisalRecord | null;
  onSelectRecord: (record: AppraisalRecord) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onStartPricing,
  onGoToHistory,
  onGoToFaq,
  lastRecord,
  onSelectRecord,
}) => {
  const POPULAR_CARS = APP_DEFAULTS.POPULAR_CARS;

  return (
    <div className="space-y-6 max-w-3xl mx-auto pb-12 animate-in fade-in duration-300">
      {/* ── Hero Banner ── */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-sky-950/60 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-72 h-72 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-300 text-xs font-semibold mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>سامانه کارشناسی هوشمند خودرو بازار ایران</span>
          </div>

          <h1 className="text-2xl md:text-3xl font-black text-slate-100 leading-snug">
            ارزیابی دقیق ارزش خودرو، <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-l from-sky-400 via-teal-300 to-indigo-400">
              با هوش مصنوعی و مدل سه‌بعدی
            </span>
          </h1>

          <p className="text-xs md:text-sm text-slate-300 max-w-xl mt-3 leading-relaxed">
            مشخصات، سوابق رنگ، ضربه بدنه و شاسی خودرو را وارد کنید تا قیمت منصفانه، جدول کسورات استاندارد و ارزیابی ارزش خرید را در لحظه دریافت کنید.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-3 mt-6">
            <button
              type="button"
              onClick={() => onStartPricing()}
              className="w-full sm:w-auto py-3.5 px-7 rounded-2xl bg-gradient-to-l from-sky-500 via-indigo-600 to-purple-600 hover:from-sky-400 hover:to-purple-500 text-white font-extrabold text-sm shadow-xl shadow-sky-500/25 active:scale-95 transition flex items-center justify-center gap-2"
            >
              <Car className="w-4 h-4" />
              <span>شروع کارشناسی خودرو</span>
              <ArrowRight className="w-4 h-4 rotate-180" />
            </button>

            <button
              type="button"
              onClick={onGoToFaq}
              className="w-full sm:w-auto py-3.5 px-5 rounded-2xl bg-slate-850 hover:bg-slate-800 text-slate-300 border border-slate-700/80 text-xs font-semibold transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <HelpCircle className="w-4 h-4 text-sky-400" />
              <span>راهنمای خرید امن</span>
            </button>
          </div>
        </div>
      </div>

      {/* ── Last Appraisal Quick Card (if exists) ── */}
      {lastRecord && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl backdrop-blur-sm">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-sky-400" />
              <span className="text-xs font-bold text-slate-200">آخرین ارزیابی شما</span>
            </div>
            <button
              type="button"
              onClick={onGoToHistory}
              className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1"
            >
              <span>مشاهده همه</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>

          <div
            onClick={() => onSelectRecord(lastRecord)}
            className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-sky-500/40 cursor-pointer transition flex items-center justify-between gap-3"
          >
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-100">{lastRecord.carModel}</span>
                <span className="text-[11px] text-slate-400">مدل {toPersianDigits(lastRecord.year)}</span>
              </div>
              <span className="text-[11px] text-slate-400 block mt-1">
                کارکرد: {formatPersianNumber(lastRecord.mileage)} کیلومتر | {lastRecord.shamsiDate}
              </span>
            </div>

            <div className="text-left">
              <span className="text-[10px] text-slate-400 block">ارزش منطقی</span>
              <span className="text-sm font-black text-sky-300">
                {formatPersianNumber(lastRecord.result.fairPrice)} تومان
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ── Popular Cars Quick Access ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <h2 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4 text-sky-400" />
          <span>خودروهای پرتقاضا در بازار امروز:</span>
        </h2>

        <div className="flex flex-wrap gap-2">
          {POPULAR_CARS.map((car, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => onStartPricing(car)}
              className="text-xs bg-slate-950/80 hover:bg-sky-500/15 hover:border-sky-500/40 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 transition active:scale-95"
            >
              {car}
            </button>
          ))}
        </div>
      </div>

      {/* ── Features Highlights Grid ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="w-9 h-9 rounded-xl bg-purple-500/15 text-purple-400 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-xs font-bold text-slate-100">کارشناسی سه‌بعدی تعاملی</h3>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            مدل‌های سه‌بعدی بدنه و اسکلت شاسی با قابلیت چرخش، لمس و ثبت دقیق لکه‌های رنگ و ضربه.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="w-9 h-9 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <h3 className="text-xs font-bold text-slate-100">استعلام زنده قیمت بازار</h3>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            جستجوی آخرین آگهی‌های باما و دیوار با ابزار Google Search Grounding و تعیین بازه قیمت روز.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-xs font-bold text-slate-100">گزارش چاپی رسمی A4</h3>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            صدور گواهی کارشناسی با کد رهگیری اختصاصی، جدول ریز کسورات و سازگار با ذخیره در قالب PDF.
          </p>
        </div>
      </div>
    </div>
  );
};
