import React, { useState } from 'react';
import { User } from 'firebase/auth';
import { ActivePage } from '../types';
import {
  Menu,
  Moon,
  Sun,
  ArrowRight,
  UserCircle2,
  LogIn,
} from 'lucide-react';

interface HeaderProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onOpenDrawer: () => void;
  user: User | null;
}

export const Header: React.FC<HeaderProps> = ({
  activePage,
  onNavigate,
  theme,
  onToggleTheme,
  onOpenDrawer,
  user,
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800/80 transition-colors">
      <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Right side: Menu button + Brand */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenDrawer}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition active:scale-95"
            title="منوی برنامه"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 cursor-pointer select-none group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-sm shadow-md shadow-sky-500/20 group-hover:scale-105 transition">
              AS
            </div>
            <div>
              <span className="font-extrabold text-sm md:text-base text-slate-100 block tracking-tight">
                اتو اسکوپ <span className="text-sky-400 font-medium text-xs">| AutoScope</span>
              </span>
              <span className="text-[10px] text-slate-400 block -mt-1 hidden sm:block">
                کارشناسی هوشمند خودرو
              </span>
            </div>
          </div>
        </div>

        {/* Left side: Back button (if subpage) + Account + Theme switcher */}
        <div className="flex items-center gap-2">
          {activePage !== 'home' && (
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="flex items-center gap-1 py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition active:scale-95"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">بازگشت</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => onNavigate('account')}
            className={`flex items-center gap-1.5 py-1.5 px-2.5 rounded-xl border text-xs font-semibold transition active:scale-95 ${
              activePage === 'account'
                ? 'bg-sky-500/20 border-sky-500/40 text-sky-300'
                : user
                ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                : 'bg-sky-500/15 hover:bg-sky-500/25 border-sky-500/30 text-sky-300'
            }`}
            title={user ? `حساب کاربری: ${user.displayName || user.email}` : 'ورود / حساب کاربری'}
          >
            {user ? (
              <>
                {user.photoURL && !imgError ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'کاربر'}
                    onError={() => setImgError(true)}
                    referrerPolicy="no-referrer"
                    className="w-5 h-5 rounded-lg object-cover"
                  />
                ) : (
                  <UserCircle2 className="w-4 h-4 text-sky-400" />
                )}
                <span className="hidden sm:inline max-w-[90px] truncate">
                  {user.displayName?.split(' ')[0] || 'حساب من'}
                </span>
              </>
            ) : (
              <>
                <LogIn className="w-3.5 h-3.5" />
                <span>ورود</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onToggleTheme}
            className="p-2 rounded-xl text-slate-300 hover:text-amber-400 hover:bg-slate-800 transition active:scale-95"
            title={theme === 'dark' ? 'تغییر به تم روشن' : 'تغییر به تم تیره'}
          >
            {theme === 'dark' ? (
              <Sun className="w-5 h-5 text-amber-400" />
            ) : (
              <Moon className="w-5 h-5 text-sky-400" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
