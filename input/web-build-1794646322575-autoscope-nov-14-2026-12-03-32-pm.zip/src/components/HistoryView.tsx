import React, { useState } from 'react';
import { AppraisalRecord } from '../types';
import {
  toPersianDigits,
  formatPersianNumber,
  formatToman,
} from '../utils/persian';
import {
  deleteHistoryItem,
  clearAllHistory,
  exportHistoryToCSV,
} from '../utils/storage';
import {
  History,
  Search,
  Trash2,
  Eye,
  AlertCircle,
  FileSpreadsheet,
  ArrowRight,
  Cloud,
  LogIn,
} from 'lucide-react';

interface HistoryViewProps {
  records: AppraisalRecord[];
  onSelectRecord: (record: AppraisalRecord) => void;
  onRefreshRecords: (records: AppraisalRecord[]) => void;
  onDeleteRecord?: (id: string) => Promise<void> | void;
  onClearAll?: () => Promise<void> | void;
  isAuthenticated?: boolean;
  onGoToAccount?: () => void;
  onGoToPricing: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  records,
  onSelectRecord,
  onRefreshRecords,
  onDeleteRecord,
  onClearAll,
  isAuthenticated = false,
  onGoToAccount,
  onGoToPricing,
  showToast,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);

  // Search filter
  const filteredRecords = records.filter((r) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.trim().toLowerCase();
    return (
      r.carModel.toLowerCase().includes(term) ||
      r.trackingCode.toLowerCase().includes(term) ||
      r.shamsiDate.includes(term) ||
      r.year.toString().includes(term)
    );
  });

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onDeleteRecord) {
      await onDeleteRecord(id);
    } else {
      const updated = deleteHistoryItem(id);
      onRefreshRecords(updated);
      showToast('مورد با موفقیت از تاریخچه حذف شد.', 'info');
    }
  };

  const handleClearAll = async () => {
    if (onClearAll) {
      await onClearAll();
      setShowClearConfirm(false);
    } else {
      clearAllHistory();
      onRefreshRecords([]);
      setShowClearConfirm(false);
      showToast('کلیه موارد تاریخچه حذف شدند.', 'info');
    }
  };

  const handleExportCSV = () => {
    if (records.length === 0) {
      showToast('موردی برای خروجی اکسل وجود ندارد.', 'error');
      return;
    }
    exportHistoryToCSV(records);
    showToast('فایل اکسل (CSV) با موفقیت دانلود شد.', 'success');
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto pb-12 animate-in fade-in duration-300">
      {/* Header Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-sky-400" />
            <h1 className="text-lg md:text-xl font-bold text-slate-100">تاریخچه کارشناسی‌ها</h1>
            {isAuthenticated && (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                <Cloud className="w-3 h-3" />
                همگام با حساب گوگل
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            ذخیره تا ۵۰ ارزیابی اخیر شما همراه با جزئیات کامل و امکان خروجی اکسل
          </p>
        </div>

        {records.length > 0 && (
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleExportCSV}
              className="flex-1 sm:flex-none min-h-[42px] py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-700 transition active:scale-95 shadow-md"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>خروجی اکسل (CSV)</span>
            </button>

            <button
              type="button"
              onClick={() => setShowClearConfirm(true)}
              className="py-2.5 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold flex items-center justify-center gap-1 border border-rose-500/30 transition active:scale-95"
              title="پاکسازی همه"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">حذف همه</span>
            </button>
          </div>
        )}
      </div>

      {/* Guest Cloud Backup Banner */}
      {!isAuthenticated && onGoToAccount && (
        <div className="bg-sky-500/10 border border-sky-500/25 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs text-slate-200">
            <Cloud className="w-5 h-5 text-sky-400 shrink-0" />
            <span>
              سوابق فعلی فقط روی همین مرورگر ذخیره می‌شوند. برای حفظ همیشگی فعالیت‌ها، با حساب گوگل وارد شوید.
            </span>
          </div>
          <button
            type="button"
            onClick={onGoToAccount}
            className="shrink-0 py-2 px-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>ورود با گوگل</span>
          </button>
        </div>
      )}

      {/* Search Input */}
      {records.length > 0 && (
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="جستجو در بین کارشناسی‌ها (مدل خودرو، سال، کد پیگیری)..."
            className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl px-4 py-3 text-xs md:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-sky-500 transition pl-10"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      )}

      {/* Records List */}
      {records.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-10 text-center">
          <div className="w-16 h-16 rounded-3xl bg-sky-500/10 text-sky-400 flex items-center justify-center mx-auto mb-4">
            <History className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-200">هنوز کارشناسی ذخیره نشده است</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1 mb-6">
            با تکمیل فرم کارشناسی، نتایج به طور خودکار در حافظه دستگاه شما ذخیره می‌شوند.
          </p>
          <button
            type="button"
            onClick={onGoToPricing}
            className="py-3 px-6 rounded-2xl bg-gradient-to-l from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-sky-500/20 transition active:scale-95 inline-flex items-center gap-2"
          >
            <span>شروع اولین کارشناسی</span>
            <ArrowRight className="w-4 h-4 rotate-180" />
          </button>
        </div>
      ) : filteredRecords.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-8 text-center text-slate-400 text-xs">
          موردی متناسب با عبارت جستجو یافت نشد.
        </div>
      ) : (
        <div className="space-y-3">
          {filteredRecords.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectRecord(item)}
              className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800/80 hover:border-sky-500/40 rounded-2xl p-4 md:p-5 transition shadow-lg cursor-pointer group"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-lg border border-sky-500/20">
                      {item.trackingCode}
                    </span>
                    <span className="text-[11px] text-slate-400">{item.shamsiDate}</span>
                    {item.result.dealJudgment.level !== 'none' && (
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border font-bold ${item.result.dealJudgment.badgeClass}`}>
                        {item.result.dealJudgment.title}
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-slate-100 mt-1.5 group-hover:text-sky-300 transition">
                    {item.carModel}{' '}
                    <span className="text-slate-400 font-normal text-xs">
                      مدل {toPersianDigits(item.year)}
                    </span>
                  </h3>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                    <span>کارکرد: {formatPersianNumber(item.mileage)} کیلومتر</span>
                    <span>•</span>
                    <span>افت قیمت: {toPersianDigits(item.result.totalDeductionPercentage)}٪</span>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800">
                  <div className="text-right sm:text-left">
                    <span className="text-[10px] text-slate-400 block">قیمت منطقی</span>
                    <span className="text-base font-black text-sky-300">
                      {formatPersianNumber(item.result.fairPrice)}{' '}
                      <span className="text-xs font-normal text-slate-400">تومان</span>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectRecord(item);
                      }}
                      className="p-2 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 text-sky-300 transition"
                      title="مشاهده نتیجه"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleDelete(item.id, e)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition"
                      title="حذف از تاریخچه"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Confirmation Modal for Clearing History */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/15 text-rose-400 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">حذف کلیه موارد تاریخچه؟</h3>
              <p className="text-xs text-slate-400 mt-1">
                این عملیات برگشت‌پذیر نیست و تمامی گزارش‌های کارشناسی ذخیره شده در دستگاه شما پاک خواهند شد.
              </p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleClearAll}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition"
              >
                بله، همه را حذف کن
              </button>
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
