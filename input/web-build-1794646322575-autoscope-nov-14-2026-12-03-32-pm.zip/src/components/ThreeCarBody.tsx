import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { BodyPartId, BodyPartState } from '../types';
import { BODY_PARTS_INFO } from '../utils/carData';
import {
  createStudioFloorTexture,
  detectSoftwareWebGL,
  disposeThreeScene,
} from '../utils/threeCleanup';
import {
  RotateCcw,
  Check,
  AlertTriangle,
  Paintbrush,
  Info,
  X,
  Smartphone,
} from 'lucide-react';

interface ThreeCarBodyProps {
  bodyParts: Record<BodyPartId, BodyPartState>;
  onChange: (newBodyParts: Record<BodyPartId, BodyPartState>) => void;
  onSelectPreset: (preset: 'clean' | 'manual' | 'sides_painted' | 'all_painted') => void;
}

const DEFAULT_CAMERA_POS = new THREE.Vector3(4.35, 2.55, 4.45);
const DEFAULT_TARGET = new THREE.Vector3(0, 0.68, -0.05);

export const ThreeCarBody: React.FC<ThreeCarBodyProps> = ({
  bodyParts,
  onChange,
  onSelectPreset,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedPartId, setSelectedPartId] = useState<BodyPartId | null>(null);
  const [webGlSupported, setWebGlSupported] = useState<boolean>(true);
  const [activePreset, setActivePreset] = useState<'clean' | 'manual' | 'sides_painted' | 'all_painted'>('manual');

  // Three.js internal references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const meshesRef = useRef<Map<BodyPartId, THREE.Mesh>>(new Map());
  const selectionOutlineRef = useRef<THREE.LineSegments | null>(null);
  const requestRenderRef = useRef<(() => void) | null>(null);
  const cameraTransitionRef = useRef<{
    active: boolean;
    position: THREE.Vector3;
    target: THREE.Vector3;
  }>({
    active: false,
    position: DEFAULT_CAMERA_POS.clone(),
    target: DEFAULT_TARGET.clone(),
  });

  const bodyPartsRef = useRef(bodyParts);
  bodyPartsRef.current = bodyParts;

  // Colors
  const COLOR_DEFAULT = 0xcbd5e1;   // Crisp Pearl Metallic Silver
  const COLOR_GLASS = 0x334155;     // Tinted Automotive Glass
  const COLOR_DAMAGED = 0xef4444;   // Crimson Red
  const COLOR_PAINTED = 0xf59e0b;   // Amber Orange
  const COLOR_BOTH = 0xa855f7;      // Vivid Purple

  const getPartColor = (partId: BodyPartId): number => {
    const state = bodyPartsRef.current[partId];
    const isGlass = partId === 'windshield' || partId === 'rear_windshield';
    if (!state) return isGlass ? COLOR_GLASS : COLOR_DEFAULT;
    if (state.damaged && state.painted) return COLOR_BOTH;
    if (state.damaged) return COLOR_DAMAGED;
    if (state.painted) return COLOR_PAINTED;
    return isGlass ? COLOR_GLASS : COLOR_DEFAULT;
  };

  const updateMeshMaterials = () => {
    meshesRef.current.forEach((mesh, partId) => {
      const mat = mesh.material as THREE.MeshPhysicalMaterial;
      if (mat) {
        const color = getPartColor(partId);
        mat.color.setHex(color);
        if (selectedPartId === partId) {
          mat.emissive.setHex(0x0ea5e9);
          mat.emissiveIntensity = 0.42;
        } else {
          mat.emissive.setHex(0x000000);
          mat.emissiveIntensity = 0;
        }
      }
    });

    // Update crisp selection wireframe outline around active part
    const oldOutline = selectionOutlineRef.current;
    if (oldOutline) {
      oldOutline.parent?.remove(oldOutline);
      oldOutline.geometry.dispose();
      (oldOutline.material as THREE.Material).dispose();
      selectionOutlineRef.current = null;
    }

    if (selectedPartId) {
      const selectedMesh = meshesRef.current.get(selectedPartId);
      if (selectedMesh) {
        const edgesGeo = new THREE.EdgesGeometry(selectedMesh.geometry, 28);
        const edgesMat = new THREE.LineBasicMaterial({
          color: 0x38bdf8,
          transparent: true,
          opacity: 0.9,
        });
        const outline = new THREE.LineSegments(edgesGeo, edgesMat);
        outline.scale.setScalar(1.003);
        selectedMesh.add(outline);
        selectionOutlineRef.current = outline;
      }
    }

    requestRenderRef.current?.();
  };

  useEffect(() => {
    updateMeshMaterials();
  }, [bodyParts, selectedPartId]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const probe = detectSoftwareWebGL();
    if (!probe.supported) {
      setWebGlSupported(false);
      return;
    }

    const isSoftwareGl = probe.isSoftwareGl;
    const width = container.clientWidth || 360;
    const height = 360;

    // Scene & Camera
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x070b14);
    scene.fog = new THREE.FogExp2(0x070b14, 0.045);

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 80);
    cameraRef.current = camera;
    camera.position.copy(DEFAULT_CAMERA_POS);

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const domEl = renderer.domElement;
    domEl.style.display = 'block';
    domEl.style.width = '100%';
    domEl.style.height = '100%';
    container.appendChild(domEl);

    // Studio Reflection Environment (RoomEnvironment via PMREM)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envRT = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envRT.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // Studio Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x0f172a, 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 2.1);
    keyLight.position.set(4.5, 7.5, 5.0);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.camera.near = 1;
      keyLight.shadow.camera.far = 20;
      keyLight.shadow.camera.left = -3.5;
      keyLight.shadow.camera.right = 3.5;
      keyLight.shadow.camera.top = 3.5;
      keyLight.shadow.camera.bottom = -3.5;
      keyLight.shadow.bias = -0.0005;
    }
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.35);
    rimLight.position.set(-5.0, 3.8, -4.5);
    scene.add(rimLight);

    const underFill = new THREE.DirectionalLight(0x818cf8, 0.55);
    underFill.position.set(0, 1.5, -5.5);
    scene.add(underFill);

    // Showroom Floor with Procedural Studio Texture
    const maxAnisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    const floorTex = createStudioFloorTexture(maxAnisotropy, '#38bdf8');
    const floorGeo = new THREE.CircleGeometry(5.5, 64);
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTex,
      roughness: 0.72,
      metalness: 0.25,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = 0;
    floor.receiveShadow = !isSoftwareGl;
    scene.add(floor);

    // Subtle Turntable Glow Ring
    const ringGeo = new THREE.RingGeometry(2.42, 2.47, 72);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
    });
    const turntableRing = new THREE.Mesh(ringGeo, ringMat);
    turntableRing.rotation.x = -Math.PI / 2;
    turntableRing.position.y = 0.004;
    scene.add(turntableRing);

    // OrbitControls
    const controls = new OrbitControls(camera, domEl);
    controlsRef.current = controls;
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.enablePan = false;
    controls.maxPolarAngle = Math.PI / 2 - 0.04;
    controls.minPolarAngle = 0.14;
    controls.minDistance = 2.8;
    controls.maxDistance = 8.2;
    controls.target.copy(DEFAULT_TARGET);
    controls.update();

    // Helper for creating side-profile extruded geometries aligned cleanly with world Z (front=+Z) & Y
    const createProfileGeometry = (
      drawShape: (shape: THREE.Shape) => void,
      width: number,
      bevelSize = 0.025,
      bevelThickness = 0.025,
      curveSegments = 20
    ): THREE.BufferGeometry => {
      const shape = new THREE.Shape();
      drawShape(shape);
      const geo = new THREE.ExtrudeGeometry(shape, {
        depth: width,
        bevelEnabled: bevelSize > 0,
        bevelSegments: 3,
        steps: 1,
        bevelSize,
        bevelThickness,
        curveSegments,
      });
      // Center extrusion along local Z, then rotate -90 deg around Y so:
      // 2D shape X -> world +Z, 2D shape Y -> world +Y, extrusion depth -> world X
      geo.translate(0, 0, -width / 2);
      geo.rotateY(-Math.PI / 2);
      geo.computeVertexNormals();
      return geo;
    };

    // Build Beautified 3D Sport Sedan Model
    const carGroup = new THREE.Group();
    meshesRef.current.clear();

    const createPartMaterial = (partId: BodyPartId) => {
      const isGlass = partId === 'windshield' || partId === 'rear_windshield';
      if (isGlass) {
        return new THREE.MeshPhysicalMaterial({
          color: getPartColor(partId),
          metalness: 0.2,
          roughness: 0.06,
          clearcoat: 1.0,
          clearcoatRoughness: 0.05,
          transparent: true,
          opacity: 0.82,
        });
      }
      return new THREE.MeshPhysicalMaterial({
        color: getPartColor(partId),
        metalness: 0.42,
        roughness: 0.22,
        clearcoat: 1.0,
        clearcoatRoughness: 0.12,
      });
    };

    const addPart = (
      id: BodyPartId,
      geometry: THREE.BufferGeometry,
      position: [number, number, number] = [0, 0, 0],
      rotation: [number, number, number] = [0, 0, 0]
    ) => {
      const mat = createPartMaterial(id);
      const mesh = new THREE.Mesh(geometry, mat);
      mesh.position.set(...position);
      mesh.rotation.set(...rotation);
      mesh.castShadow = !isSoftwareGl;
      mesh.receiveShadow = !isSoftwareGl;
      mesh.userData = { partId: id };
      carGroup.add(mesh);
      meshesRef.current.set(id, mesh);
      return mesh;
    };

    // --- 1. Hood (کاپوت) - sculpted aerodynamic slope ---
    const hoodGeo = createProfileGeometry(
      (s) => {
        s.moveTo(0.80, 0.92);
        s.quadraticCurveTo(1.38, 0.91, 1.93, 0.78);
        s.lineTo(1.93, 0.72);
        s.quadraticCurveTo(1.36, 0.84, 0.80, 0.86);
        s.closePath();
      },
      1.36,
      0.025,
      0.03
    );
    addPart('hood', hoodGeo);

    // --- 2. Front Bumper (سپر جلو) - sculpted aero nose ---
    const frontBumperGeo = createProfileGeometry(
      (s) => {
        s.moveTo(1.86, 0.22);
        s.lineTo(2.19, 0.23);
        s.quadraticCurveTo(2.26, 0.44, 2.18, 0.67);
        s.quadraticCurveTo(2.09, 0.75, 1.94, 0.74);
        s.lineTo(1.86, 0.56);
        s.closePath();
      },
      1.54,
      0.03,
      0.04
    );
    addPart('front_bumper', frontBumperGeo);

    // --- 3. Windshield (شیشه جلو) ---
    const windshieldGeo = new RoundedBoxGeometry(1.26, 0.035, 0.86, 3, 0.014);
    addPart('windshield', windshieldGeo, [0, 1.19, 0.50], [Math.PI / 4.7, 0, 0]);

    // --- 4. Roof (سقف) - sleek cambered canopy ---
    const roofGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-0.96, 1.40);
        s.quadraticCurveTo(-0.32, 1.49, 0.24, 1.41);
        s.lineTo(0.24, 1.36);
        s.quadraticCurveTo(-0.32, 1.43, -0.96, 1.35);
        s.closePath();
      },
      1.24,
      0.025,
      0.03
    );
    addPart('roof', roofGeo);

    // --- 5. Rear Windshield (شیشه عقب) ---
    const rearWindshieldGeo = new RoundedBoxGeometry(1.24, 0.035, 0.82, 3, 0.014);
    addPart('rear_windshield', rearWindshieldGeo, [0, 1.21, -1.25], [-Math.PI / 4.5, 0, 0]);

    // --- 6. Trunk (صندوق عقب) - sculpted decklid with integrated ducktail lip ---
    const trunkGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-2.12, 0.94);
        s.lineTo(-2.06, 0.99); // subtle ducktail lip
        s.quadraticCurveTo(-1.82, 0.96, -1.53, 1.00);
        s.lineTo(-1.53, 0.92);
        s.lineTo(-2.11, 0.86);
        s.closePath();
      },
      1.34,
      0.024,
      0.03
    );
    addPart('trunk', trunkGeo);

    // --- 7. Rear Bumper (سپر عقب) ---
    const rearBumperGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-2.22, 0.25);
        s.lineTo(-1.90, 0.23);
        s.lineTo(-1.90, 0.66);
        s.lineTo(-2.13, 0.84);
        s.quadraticCurveTo(-2.24, 0.64, -2.22, 0.25);
        s.closePath();
      },
      1.54,
      0.03,
      0.04
    );
    addPart('rear_bumper', rearBumperGeo);

    // --- 8 & 9. Front Fenders (گلگیر جلو) with Curved Wheel-Arch Cutout ---
    const frontFenderGeo = createProfileGeometry(
      (s) => {
        s.moveTo(0.80, 0.24);
        s.lineTo(0.92, 0.24);
        s.absarc(1.32, 0.34, 0.40, Math.PI, 0, true);
        s.lineTo(1.90, 0.26);
        s.quadraticCurveTo(1.94, 0.60, 1.91, 0.74);
        s.quadraticCurveTo(1.36, 0.88, 0.80, 0.92);
        s.closePath();
      },
      0.13,
      0.025,
      0.025,
      28
    );
    addPart('fender_front_right', frontFenderGeo, [0.75, 0, 0]);
    addPart('fender_front_left', frontFenderGeo, [-0.75, 0, 0]);

    // --- 10 & 11. Front Doors (درب جلو) ---
    const frontDoorGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-0.04, 0.24);
        s.lineTo(0.80, 0.24);
        s.lineTo(0.80, 0.93);
        s.lineTo(-0.04, 0.96);
        s.closePath();
      },
      0.11,
      0.022,
      0.022
    );
    addPart('door_front_right', frontDoorGeo, [0.76, 0, 0]);
    addPart('door_front_left', frontDoorGeo, [-0.76, 0, 0]);

    // --- 12 & 13. Rear Doors (درب عقب) ---
    const rearDoorGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-0.90, 0.24);
        s.lineTo(-0.04, 0.24);
        s.lineTo(-0.04, 0.96);
        s.lineTo(-0.90, 0.99);
        s.closePath();
      },
      0.11,
      0.022,
      0.022
    );
    addPart('door_rear_right', rearDoorGeo, [0.76, 0, 0]);
    addPart('door_rear_left', rearDoorGeo, [-0.76, 0, 0]);

    // --- 14 & 15. Rear Fenders (گلگیر عقب) with Curved Wheel-Arch Cutout ---
    const rearFenderGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-2.10, 0.30);
        s.lineTo(-1.76, 0.24);
        s.absarc(-1.36, 0.34, 0.40, 0, Math.PI, false);
        s.lineTo(-0.90, 0.24);
        s.lineTo(-0.90, 0.99);
        s.quadraticCurveTo(-1.45, 1.03, -2.10, 0.89);
        s.closePath();
      },
      0.13,
      0.025,
      0.025,
      28
    );
    addPart('fender_rear_right', rearFenderGeo, [0.75, 0, 0]);
    addPart('fender_rear_left', rearFenderGeo, [-0.75, 0, 0]);

    // =========================================================================
    // Decorative Non-Selectable Coachwork & Mechanical Details
    // (Separated from meshesRef so raycasting & recoloring stay strictly clean)
    // =========================================================================

    // Dark Core Chassis & Wheel-Well Tub (prevents see-through gaps)
    const darkCoreMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.85,
      metalness: 0.2,
    });
    const coreTubGeo = new RoundedBoxGeometry(1.30, 0.56, 3.65, 2, 0.04);
    const coreTub = new THREE.Mesh(coreTubGeo, darkCoreMat);
    coreTub.position.set(0, 0.56, -0.06);
    carGroup.add(coreTub);

    // Side Window Greenhouse + Pillars (gloss black frame + tinted side glass)
    const sideGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e293b,
      metalness: 0.25,
      roughness: 0.06,
      clearcoat: 1.0,
      transparent: true,
      opacity: 0.85,
    });
    const sideGreenhouseGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-1.44, 0.99);
        s.lineTo(0.76, 0.94);
        s.lineTo(0.23, 1.37);
        s.lineTo(-0.92, 1.37);
        s.closePath();
      },
      1.27,
      0.015,
      0.015
    );
    const sideGreenhouse = new THREE.Mesh(sideGreenhouseGeo, sideGlassMat);
    carGroup.add(sideGreenhouse);

    // Gloss Black B-Pillar Trim Bars
    const glossTrimMat = new THREE.MeshStandardMaterial({
      color: 0x090d16,
      roughness: 0.18,
      metalness: 0.6,
    });
    const bPillarGeo = new THREE.BoxGeometry(0.03, 0.42, 0.09);
    const bPillarR = new THREE.Mesh(bPillarGeo, glossTrimMat);
    bPillarR.position.set(0.655, 1.16, -0.04);
    bPillarR.rotation.z = 0.2;
    const bPillarL = new THREE.Mesh(bPillarGeo, glossTrimMat);
    bPillarL.position.set(-0.655, 1.16, -0.04);
    bPillarL.rotation.z = -0.2;
    carGroup.add(bPillarR, bPillarL);

    // Side Rocker Skirt Strips (sporty dark lower sill accent)
    const skirtGeo = new RoundedBoxGeometry(0.08, 0.08, 1.80, 2, 0.02);
    const skirtR = new THREE.Mesh(skirtGeo, glossTrimMat);
    skirtR.position.set(0.79, 0.22, -0.04);
    const skirtL = new THREE.Mesh(skirtGeo, glossTrimMat);
    skirtL.position.set(-0.79, 0.22, -0.04);
    carGroup.add(skirtR, skirtL);

    // Door Handles (chrome accent)
    const chromeMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.92,
      roughness: 0.14,
    });
    const handleGeo = new RoundedBoxGeometry(0.035, 0.032, 0.16, 2, 0.01);
    const handleCoords: [number, number, number][] = [
      [0.835, 0.78, 0.15],
      [-0.835, 0.78, 0.15],
      [0.835, 0.80, -0.68],
      [-0.835, 0.80, -0.68],
    ];
    handleCoords.forEach(([hx, hy, hz]) => {
      const handle = new THREE.Mesh(handleGeo, chromeMat);
      handle.position.set(hx, hy, hz);
      carGroup.add(handle);
    });

    // Side Wing Mirrors
    const mirrorGeo = new RoundedBoxGeometry(0.16, 0.09, 0.12, 2, 0.025);
    const mirrorStemGeo = new THREE.BoxGeometry(0.08, 0.04, 0.05);
    [1, -1].forEach((side) => {
      const mirror = new THREE.Mesh(mirrorGeo, glossTrimMat);
      mirror.position.set(side * 0.88, 0.99, 0.56);
      mirror.rotation.y = side * -0.18;
      const stem = new THREE.Mesh(mirrorStemGeo, glossTrimMat);
      stem.position.set(side * 0.78, 0.96, 0.56);
      carGroup.add(mirror, stem);
    });

    // Panoramic Roof Glass Inset & Shark-Fin Antenna
    const sunroofGeo = new RoundedBoxGeometry(0.92, 0.02, 0.68, 2, 0.01);
    const sunroof = new THREE.Mesh(sunroofGeo, glossTrimMat);
    sunroof.position.set(0, 1.455, -0.24);
    carGroup.add(sunroof);

    const finGeo = createProfileGeometry(
      (s) => {
        s.moveTo(-0.08, 0);
        s.lineTo(0.08, 0);
        s.lineTo(-0.04, 0.075);
        s.closePath();
      },
      0.022,
      0.006,
      0.006
    );
    const sharkFin = new THREE.Mesh(finGeo, glossTrimMat);
    sharkFin.position.set(0, 1.43, -0.82);
    carGroup.add(sharkFin);

    // Front Grille & Lower Splitter Lip
    const grilleGeo = new RoundedBoxGeometry(0.90, 0.18, 0.06, 2, 0.02);
    const grille = new THREE.Mesh(grilleGeo, glossTrimMat);
    grille.position.set(0, 0.52, 2.24);
    const splitterGeo = new RoundedBoxGeometry(1.52, 0.035, 0.14, 2, 0.012);
    const splitter = new THREE.Mesh(splitterGeo, glossTrimMat);
    splitter.position.set(0, 0.20, 2.18);
    carGroup.add(grille, splitter);

    // Sleek LED Headlights + DRL Bars
    const headlightMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      emissive: 0xbae6fd,
      emissiveIntensity: 1.35,
      roughness: 0.12,
    });
    const hlGeo = new RoundedBoxGeometry(0.34, 0.075, 0.10, 2, 0.02);
    [1, -1].forEach((side) => {
      const hl = new THREE.Mesh(hlGeo, headlightMat);
      hl.position.set(side * 0.56, 0.66, 2.16);
      hl.rotation.y = side * 0.18;
      carGroup.add(hl);
    });

    // Rear Diffuser + Dual Chrome Exhaust Tips + LED Taillight Bar
    const diffuserGeo = new RoundedBoxGeometry(1.36, 0.11, 0.08, 2, 0.02);
    const diffuser = new THREE.Mesh(diffuserGeo, glossTrimMat);
    diffuser.position.set(0, 0.27, -2.23);
    carGroup.add(diffuser);

    const exhaustGeo = new THREE.CylinderGeometry(0.038, 0.038, 0.12, 16);
    exhaustGeo.rotateX(Math.PI / 2);
    [-0.50, 0.50].forEach((ex) => {
      const tip = new THREE.Mesh(exhaustGeo, chromeMat);
      tip.position.set(ex, 0.26, -2.27);
      carGroup.add(tip);
    });

    const taillightMat = new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xdc2626,
      emissiveIntensity: 1.2,
      roughness: 0.15,
    });
    const tlGeo = new RoundedBoxGeometry(0.36, 0.07, 0.08, 2, 0.02);
    [1, -1].forEach((side) => {
      const tl = new THREE.Mesh(tlGeo, taillightMat);
      tl.position.set(side * 0.56, 0.79, -2.16);
      tl.rotation.y = side * -0.14;
      carGroup.add(tl);
    });
    const lightBarGeo = new RoundedBoxGeometry(0.76, 0.025, 0.05, 1, 0.008);
    const lightBar = new THREE.Mesh(lightBarGeo, taillightMat);
    lightBar.position.set(0, 0.79, -2.19);
    carGroup.add(lightBar);

    // Detailed Multi-Part Wheels (Sculpted Tire + 5-Spoke Alloy Rim + Brake Disc + Caliper)
    const tirePoints = [
      new THREE.Vector2(0.22, -0.115),
      new THREE.Vector2(0.31, -0.115),
      new THREE.Vector2(0.34, -0.09),
      new THREE.Vector2(0.34, 0.09),
      new THREE.Vector2(0.31, 0.115),
      new THREE.Vector2(0.22, 0.115),
    ];
    const tireGeo = new THREE.LatheGeometry(tirePoints, 32);
    tireGeo.rotateZ(Math.PI / 2);
    const tireMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.88,
      metalness: 0.05,
    });

    const rimBarrelGeo = new THREE.CylinderGeometry(0.225, 0.225, 0.18, 24, 1, true);
    rimBarrelGeo.rotateZ(Math.PI / 2);
    const rimBarrelMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.75,
      roughness: 0.3,
      side: THREE.DoubleSide,
    });

    const hubGeo = new THREE.CylinderGeometry(0.065, 0.065, 0.21, 18);
    hubGeo.rotateZ(Math.PI / 2);

    const spokeGeo = new THREE.BoxGeometry(0.03, 0.38, 0.032);
    const rotorGeo = new THREE.CylinderGeometry(0.17, 0.17, 0.03, 22);
    rotorGeo.rotateZ(Math.PI / 2);
    const rotorMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.85,
      roughness: 0.32,
    });
    const caliperGeo = new THREE.BoxGeometry(0.045, 0.095, 0.06);
    const caliperMat = new THREE.MeshStandardMaterial({
      color: 0x0ea5e9,
      metalness: 0.5,
      roughness: 0.3,
    });

    const wheelPositions: [number, number, number, number][] = [
      [0.74, 0.34, 1.32, 1],
      [-0.74, 0.34, 1.32, -1],
      [0.74, 0.34, -1.36, 1],
      [-0.74, 0.34, -1.36, -1],
    ];

    wheelPositions.forEach(([wx, wy, wz, side]) => {
      const wheelGroup = new THREE.Group();

      const tire = new THREE.Mesh(tireGeo, tireMat);
      tire.castShadow = !isSoftwareGl;
      wheelGroup.add(tire);

      const barrel = new THREE.Mesh(rimBarrelGeo, rimBarrelMat);
      wheelGroup.add(barrel);

      const hub = new THREE.Mesh(hubGeo, chromeMat);
      wheelGroup.add(hub);

      // 5 alloy spokes
      for (let i = 0; i < 5; i++) {
        const spoke = new THREE.Mesh(spokeGeo, chromeMat);
        spoke.position.x = side * 0.088;
        spoke.rotation.x = (i * Math.PI) / 5;
        wheelGroup.add(spoke);
      }

      const rotor = new THREE.Mesh(rotorGeo, rotorMat);
      rotor.position.x = side * 0.02;
      wheelGroup.add(rotor);

      const caliper = new THREE.Mesh(caliperGeo, caliperMat);
      caliper.position.set(side * 0.03, 0.06, -0.11);
      wheelGroup.add(caliper);

      wheelGroup.position.set(wx, wy, wz);
      carGroup.add(wheelGroup);
    });

    scene.add(carGroup);

    // =========================================================================
    // On-Demand Render Loop & Smooth Camera Transitions (Mobile-Optimized)
    // =========================================================================
    let animId = 0;
    let renderScheduled = false;
    let lastTime = performance.now();

    const clockTick = (now: number) => {
      animId = 0;
      renderScheduled = false;

      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      let needsNextFrame = false;

      // Smooth preset camera transition
      const tr = cameraTransitionRef.current;
      if (tr.active) {
        const lambda = 9;
        camera.position.x = THREE.MathUtils.damp(camera.position.x, tr.position.x, lambda, dt);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, tr.position.y, lambda, dt);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, tr.position.z, lambda, dt);

        controls.target.x = THREE.MathUtils.damp(controls.target.x, tr.target.x, lambda, dt);
        controls.target.y = THREE.MathUtils.damp(controls.target.y, tr.target.y, lambda, dt);
        controls.target.z = THREE.MathUtils.damp(controls.target.z, tr.target.z, lambda, dt);

        if (
          camera.position.distanceToSquared(tr.position) < 0.0004 &&
          controls.target.distanceToSquared(tr.target) < 0.0004
        ) {
          camera.position.copy(tr.position);
          controls.target.copy(tr.target);
          tr.active = false;
        } else {
          needsNextFrame = true;
        }
      }

      const controlsChanged = controls.update();
      if (controlsChanged) {
        needsNextFrame = true;
      }

      renderer.render(scene, camera);

      if (needsNextFrame) {
        scheduleRender();
      }
    };

    const scheduleRender = () => {
      if (renderScheduled) return;
      renderScheduled = true;
      lastTime = performance.now();
      animId = requestAnimationFrame(clockTick);
    };

    requestRenderRef.current = scheduleRender;

    const handleControlsStart = () => {
      // User grabbed viewport: cancel camera preset glide immediately
      cameraTransitionRef.current.active = false;
      scheduleRender();
    };
    const handleControlsChange = () => {
      scheduleRender();
    };

    controls.addEventListener('start', handleControlsStart);
    controls.addEventListener('change', handleControlsChange);

    // Initial render
    scheduleRender();

    // Tap-vs-Drag Pointer Raycaster (prevents orbit drags on mobile from toggling parts)
    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();
    let downX = 0;
    let downY = 0;
    let pointerActive = false;

    const handlePointerDown = (event: PointerEvent) => {
      if (event.pointerType === 'mouse' && event.button !== 0) return;
      downX = event.clientX;
      downY = event.clientY;
      pointerActive = true;
    };

    const handlePointerUp = (event: PointerEvent) => {
      if (!pointerActive) return;
      pointerActive = false;

      const dx = event.clientX - downX;
      const dy = event.clientY - downY;
      if (dx * dx + dy * dy > 64) {
        // User dragged (> 8px) to orbit; ignore selection
        return;
      }

      const rect = domEl.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      pointerNdc.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(pointerNdc, camera);
      const selectableMeshes = Array.from(meshesRef.current.values());
      const intersects = raycaster.intersectObjects(selectableMeshes, false);

      if (intersects.length > 0) {
        const hitMesh = intersects[0].object as THREE.Mesh;
        const partId = hitMesh.userData.partId as BodyPartId | undefined;
        if (partId) {
          setSelectedPartId((prev) => (prev === partId ? null : partId));
        }
      }
    };

    const handleContextLost = (event: Event) => {
      event.preventDefault();
      if (animId) {
        cancelAnimationFrame(animId);
        animId = 0;
        renderScheduled = false;
      }
    };

    const handleContextRestored = () => {
      scheduleRender();
    };

    domEl.addEventListener('pointerdown', handlePointerDown);
    domEl.addEventListener('pointerup', handlePointerUp);
    domEl.addEventListener('webglcontextlost', handleContextLost);
    domEl.addEventListener('webglcontextrestored', handleContextRestored);

    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth || 360;
      camera.aspect = newWidth / height;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, height);
      scheduleRender();
    };
    window.addEventListener('resize', handleResize);

    // Comprehensive Manual Disposal Cleanup on Unmount (Zero GPU Memory Leaks)
    return () => {
      if (animId) {
        cancelAnimationFrame(animId);
      }
      requestRenderRef.current = null;
      window.removeEventListener('resize', handleResize);
      controls.removeEventListener('start', handleControlsStart);
      controls.removeEventListener('change', handleControlsChange);
      domEl.removeEventListener('pointerdown', handlePointerDown);
      domEl.removeEventListener('pointerup', handlePointerUp);
      domEl.removeEventListener('webglcontextlost', handleContextLost);
      domEl.removeEventListener('webglcontextrestored', handleContextRestored);

      if (selectionOutlineRef.current) {
        selectionOutlineRef.current.parent?.remove(selectionOutlineRef.current);
        selectionOutlineRef.current.geometry.dispose();
        (selectionOutlineRef.current.material as THREE.Material).dispose();
        selectionOutlineRef.current = null;
      }

      disposeThreeScene({
        scene,
        renderer,
        controls,
        extraTextures: [floorTex],
      });

      meshesRef.current.clear();
      sceneRef.current = null;
      cameraRef.current = null;
      rendererRef.current = null;
      controlsRef.current = null;
    };
  }, []);

  // Smooth Preset Camera Angles
  const setCameraAngle = (view: 'front' | 'rear' | 'right' | 'left' | 'top' | 'reset') => {
    if (!cameraRef.current || !controlsRef.current) return;

    const targetPos = cameraTransitionRef.current.position;
    switch (view) {
      case 'front':
        targetPos.set(0, 1.35, 5.15);
        break;
      case 'rear':
        targetPos.set(0, 1.4, -5.2);
        break;
      case 'right':
        targetPos.set(5.2, 1.35, -0.05);
        break;
      case 'left':
        targetPos.set(-5.2, 1.35, -0.05);
        break;
      case 'top':
        targetPos.set(0, 6.2, 0.05);
        break;
      case 'reset':
      default:
        targetPos.copy(DEFAULT_CAMERA_POS);
        break;
    }

    cameraTransitionRef.current.target.copy(DEFAULT_TARGET);
    cameraTransitionRef.current.active = true;
    requestRenderRef.current?.();
  };

  // Toggle Part Condition
  const toggleCondition = (partId: BodyPartId, type: 'damaged' | 'painted') => {
    const current = bodyParts[partId] || { damaged: false, painted: false };
    const updated = {
      ...bodyParts,
      [partId]: {
        ...current,
        [type]: !current[type],
      },
    };
    setActivePreset('manual');
    onChange(updated);
  };

  const handleQuickPreset = (preset: 'clean' | 'manual' | 'sides_painted' | 'all_painted') => {
    setActivePreset(preset);
    onSelectPreset(preset);
  };

  const selectedPartMeta = selectedPartId ? BODY_PARTS_INFO[selectedPartId] : null;
  const selectedState = selectedPartId ? bodyParts[selectedPartId] : null;

  // Active damaged/painted chips
  const activeChips = Object.entries(bodyParts).filter(
    ([_, state]) => state.damaged || state.painted
  ) as [BodyPartId, BodyPartState][];

  return (
    <div className="space-y-4">
      {/* 3D Canvas / 2D Fallback Box */}
      <div className="relative rounded-2xl overflow-hidden bg-slate-950/80 border border-slate-800 shadow-inner">
        {webGlSupported ? (
          <div
            ref={mountRef}
            className="w-full h-[360px] cursor-grab active:cursor-grabbing touch-none select-none"
            style={{ touchAction: 'none' }}
          />
        ) : (
          /* SVG Fallback */
          <div className="w-full h-[360px] flex flex-col items-center justify-center p-4 bg-slate-900 text-slate-300">
            <Info className="w-8 h-8 text-sky-400 mb-2" />
            <p className="text-sm font-semibold">نمای دوبعدی دیاگرام خودرو</p>
            <p className="text-xs text-slate-400 mt-1 text-center">
              به دلیل محدودیت مرورگر، از دیاگرام ساده استفاده می‌شود.
            </p>
          </div>
        )}

        {/* Floating Controls HUD */}
        <div className="absolute top-3 right-3 left-3 flex items-center justify-between pointer-events-none">
          <div className="bg-slate-900/85 backdrop-blur-md border border-slate-700/60 rounded-xl px-3 py-1.5 text-xs text-slate-300 shadow-lg flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-sky-400" />
            <span>با یک انگشت بچرخانید، دو انگشت زوم</span>
          </div>

          <button
            type="button"
            onClick={() => setCameraAngle('reset')}
            className="pointer-events-auto bg-slate-900/85 hover:bg-slate-800 text-slate-300 border border-slate-700/60 rounded-xl px-2.5 py-1.5 text-xs font-medium flex items-center gap-1 transition shadow-lg active:scale-95"
            title="نمای اولیه"
          >
            <RotateCcw className="w-3.5 h-3.5 text-sky-400" />
            <span>پیش‌فرض</span>
          </button>
        </div>

        {/* Camera Views Bar */}
        <div className="absolute bottom-3 right-3 left-3 flex items-center justify-center gap-1.5 overflow-x-auto py-1">
          <button
            type="button"
            onClick={() => setCameraAngle('front')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            جلو
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('rear')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            عقب
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('right')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            راست
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('left')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            چپ
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('top')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            بالا
          </button>
        </div>
      </div>

      {/* Selected Part Mini-Panel */}
      {selectedPartMeta && (
        <div className="p-3.5 rounded-xl bg-slate-800/90 border border-sky-500/40 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-slate-700">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
              <span className="font-semibold text-slate-100 text-sm">{selectedPartMeta.name}</span>
            </div>
            <button
              type="button"
              onClick={() => setSelectedPartId(null)}
              className="text-slate-400 hover:text-slate-200 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => toggleCondition(selectedPartMeta.id, 'damaged')}
              className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold border transition ${
                selectedState?.damaged
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                  : 'bg-slate-900/60 text-slate-300 border-slate-700 hover:border-slate-600'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>ضربه خورده ({selectedPartMeta.damagePercent}٪)</span>
              {selectedState?.damaged && <Check className="w-3.5 h-3.5 text-rose-400 mr-auto" />}
            </button>

            {selectedPartMeta.supportsPaint ? (
              <button
                type="button"
                onClick={() => toggleCondition(selectedPartMeta.id, 'painted')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold border transition ${
                  selectedState?.painted
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                    : 'bg-slate-900/60 text-slate-300 border-slate-700 hover:border-slate-600'
                }`}
              >
                <Paintbrush className="w-3.5 h-3.5 text-amber-400" />
                <span>رنگ شده ({selectedPartMeta.paintPercent}٪)</span>
                {selectedState?.painted && <Check className="w-3.5 h-3.5 text-amber-400 mr-auto" />}
              </button>
            ) : (
              <div className="flex items-center justify-center text-xs text-slate-400 bg-slate-900/40 border border-slate-800 rounded-xl py-2 px-3">
                فاقد پوشش رنگ (شیشه)
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Presets Selection */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-slate-400 ml-1">انتخاب سریع:</span>
        <button
          type="button"
          onClick={() => handleQuickPreset('clean')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
            activePreset === 'clean'
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
              : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-700/60'
          }`}
        >
          بدون رنگ (سالم)
        </button>

        <button
          type="button"
          onClick={() => handleQuickPreset('sides_painted')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
            activePreset === 'sides_painted'
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-700/60'
          }`}
        >
          دور رنگ
        </button>

        <button
          type="button"
          onClick={() => handleQuickPreset('all_painted')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
            activePreset === 'all_painted'
              ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
              : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-700/60'
          }`}
        >
          تمام رنگ
        </button>

        <button
          type="button"
          onClick={() => handleQuickPreset('manual')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
            activePreset === 'manual'
              ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
              : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-700/60'
          }`}
        >
          انتخاب دستی
        </button>
      </div>

      {/* Selected Parts Chips Summary */}
      {activeChips.length > 0 && (
        <div className="pt-1">
          <p className="text-xs text-slate-400 mb-1.5">قطعات انتخاب‌شده:</p>
          <div className="flex flex-wrap gap-1.5">
            {activeChips.map(([partId, state]) => {
              const meta = BODY_PARTS_INFO[partId];
              return (
                <div
                  key={partId}
                  className="flex items-center gap-1.5 bg-slate-800/90 border border-slate-700 text-xs text-slate-200 px-2.5 py-1 rounded-lg"
                >
                  <span className="font-medium">{meta?.name}</span>
                  {state.damaged && (
                    <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1.5 py-0.5 rounded">ضربه</span>
                  )}
                  {state.painted && (
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded">رنگ</span>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      const updated = { ...bodyParts };
                      delete updated[partId];
                      onChange(updated);
                    }}
                    className="text-slate-400 hover:text-rose-400 ml-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
