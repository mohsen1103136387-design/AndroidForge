import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { ChassisPartId, ChassisSeverity } from '../types';
import { CHASSIS_PARTS_INFO, CHASSIS_SEVERITY_LABELS } from '../utils/carData';
import {
  createStudioFloorTexture,
  detectSoftwareWebGL,
  disposeThreeScene,
} from '../utils/threeCleanup';
import {
  RotateCcw,
  Check,
  AlertOctagon,
  ShieldCheck,
  Info,
  X,
  Smartphone,
} from 'lucide-react';

interface ThreeChassisProps {
  chassisParts: Record<ChassisPartId, ChassisSeverity>;
  onChange: (newChassisParts: Record<ChassisPartId, ChassisSeverity>) => void;
}

const DEFAULT_CAMERA_POS = new THREE.Vector3(4.35, 2.75, 4.45);
const DEFAULT_TARGET = new THREE.Vector3(0, 0.68, -0.05);

export const ThreeChassis: React.FC<ThreeChassisProps> = ({
  chassisParts,
  onChange,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedPartId, setSelectedPartId] = useState<ChassisPartId | null>(null);
  const [webGlSupported, setWebGlSupported] = useState<boolean>(true);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const meshesRef = useRef<Map<ChassisPartId, THREE.Mesh>>(new Map());
  const edgeLinesRef = useRef<Map<ChassisPartId, THREE.LineSegments>>(new Map());
  const requestRenderRef = useRef<(() => void) | null>(null);
  const cameraTransitionRef = useRef<{
    active: boolean;
    position: THREE.Vector3;
    target: THREE.Vector3;
  }>({
    active: false,
    position: DEFAULT_CAMERA_POS.clone(),
    target: DEFAULT_TARGET.clone(),
  });

  const chassisPartsRef = useRef(chassisParts);
  chassisPartsRef.current = chassisParts;

  // Severity color mapping
  const COLOR_NONE = 0x10b981;      // Emerald Green
  const COLOR_MINOR = 0xeab308;     // Yellow
  const COLOR_MODERATE = 0xf97316;  // Orange
  const COLOR_SEVERE = 0xef4444;    // Red

  const getPartColor = (partId: ChassisPartId): number => {
    const severity = chassisPartsRef.current[partId] || 'none';
    switch (severity) {
      case 'minor':
        return COLOR_MINOR;
      case 'moderate':
        return COLOR_MODERATE;
      case 'severe':
        return COLOR_SEVERE;
      case 'none':
      default:
        return COLOR_NONE;
    }
  };

  const updateMeshMaterials = () => {
    meshesRef.current.forEach((mesh, partId) => {
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (mat) {
        const color = getPartColor(partId);
        mat.color.setHex(color);
        if (selectedPartId === partId) {
          mat.emissive.setHex(0x38bdf8);
          mat.emissiveIntensity = 0.55;
        } else {
          mat.emissive.setHex(0x000000);
          mat.emissiveIntensity = 0;
        }
      }

      const edgeLine = edgeLinesRef.current.get(partId);
      if (edgeLine) {
        const edgeMat = edgeLine.material as THREE.LineBasicMaterial;
        if (selectedPartId === partId) {
          edgeMat.color.setHex(0xe0f2fe);
          edgeMat.opacity = 0.95;
        } else {
          edgeMat.color.setHex(0x38bdf8);
          edgeMat.opacity = 0.28;
        }
      }
    });

    requestRenderRef.current?.();
  };

  useEffect(() => {
    updateMeshMaterials();
  }, [chassisParts, selectedPartId]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const probe = detectSoftwareWebGL();
    if (!probe.supported) {
      setWebGlSupported(false);
      return;
    }

    const isSoftwareGl = probe.isSoftwareGl;
    const width = container.clientWidth || 360;
    const height = 360;

    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x050811);
    scene.fog = new THREE.FogExp2(0x050811, 0.045);

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 80);
    cameraRef.current = camera;
    camera.position.copy(DEFAULT_CAMERA_POS);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    const domEl = renderer.domElement;
    domEl.style.display = 'block';
    domEl.style.width = '100%';
    domEl.style.height = '100%';
    container.appendChild(domEl);

    // Studio Reflection Environment (RoomEnvironment via PMREM)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envRT = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envRT.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // Studio Lighting for Metallic Space-Frame Skeleton
    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x0f172a, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 2.0);
    keyLight.position.set(5, 8, 5);
    scene.add(keyLight);

    const cyanRim = new THREE.DirectionalLight(0x38bdf8, 1.5);
    cyanRim.position.set(-5, 5, -4);
    scene.add(cyanRim);

    // Diagnostic Inspection Bay Floor
    const maxAnisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    const floorTex = createStudioFloorTexture(maxAnisotropy, '#0ea5e9');
    const bayFloorGeo = new THREE.CircleGeometry(5.5, 64);
    const bayFloorMat = new THREE.MeshStandardMaterial({
      map: floorTex,
      roughness: 0.78,
      metalness: 0.25,
    });
    const bayFloor = new THREE.Mesh(bayFloorGeo, bayFloorMat);
    bayFloor.rotation.x = -Math.PI / 2;
    bayFloor.position.y = 0;
    scene.add(bayFloor);

    // OrbitControls
    const controls = new OrbitControls(camera, domEl);
    controlsRef.current = controls;
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.07;
    controls.enablePan = false;
    controls.maxPolarAngle = Math.PI / 2 - 0.04;
    controls.minPolarAngle = 0.14;
    controls.minDistance = 2.4;
    controls.maxDistance = 8.2;
    controls.target.copy(DEFAULT_TARGET);
    controls.update();

    // Side-profile extrusion helper (2D x -> world +Z, 2D y -> world +Y, depth -> world X)
    const createSideBeamGeometry = (
      drawShape: (shape: THREE.Shape) => void,
      width: number,
      bevelSize = 0.012
    ): THREE.BufferGeometry => {
      const shape = new THREE.Shape();
      drawShape(shape);
      const geo = new THREE.ExtrudeGeometry(shape, {
        depth: width,
        bevelEnabled: bevelSize > 0,
        bevelSegments: 2,
        steps: 1,
        bevelSize,
        bevelThickness: bevelSize,
        curveSegments: 16,
      });
      geo.translate(0, 0, -width / 2);
      geo.rotateY(-Math.PI / 2);
      geo.computeVertexNormals();
      return geo;
    };

    // Build Structural Space-Frame Chassis Skeleton
    const chassisGroup = new THREE.Group();
    meshesRef.current.clear();
    edgeLinesRef.current.clear();

    const addChassisMesh = (
      id: ChassisPartId,
      geometry: THREE.BufferGeometry,
      pos: [number, number, number] = [0, 0, 0],
      rot: [number, number, number] = [0, 0, 0]
    ) => {
      const mat = new THREE.MeshStandardMaterial({
        color: getPartColor(id),
        metalness: 0.62,
        roughness: 0.26,
      });
      const mesh = new THREE.Mesh(geometry, mat);
      mesh.position.set(...pos);
      mesh.rotation.set(...rot);
      mesh.userData = { partId: id };

      // Crisp structural edge highlights (clean CAD aesthetic instead of noisy triangle wireframes)
      const edgeGeo = new THREE.EdgesGeometry(geometry, 28);
      const edgeMat = new THREE.LineBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.28,
      });
      const edgeLines = new THREE.LineSegments(edgeGeo, edgeMat);
      mesh.add(edgeLines);
      edgeLinesRef.current.set(id, edgeLines);

      chassisGroup.add(mesh);
      meshesRef.current.set(id, mesh);
      return mesh;
    };

    // 1 & 2. Hydroformed Front Longitudinal Frame Rails (ریل/لنگه شاسی جلو)
    const frontRailGeo = createSideBeamGeometry(
      (s) => {
        s.moveTo(0.68, 0.30);
        s.lineTo(1.06, 0.30);
        s.quadraticCurveTo(1.36, 0.38, 1.94, 0.42);
        s.lineTo(1.94, 0.54);
        s.quadraticCurveTo(1.36, 0.50, 1.04, 0.43);
        s.lineTo(0.68, 0.43);
        s.closePath();
      },
      0.11,
      0.012
    );
    addChassisMesh('rail_front_r', frontRailGeo, [0.43, 0, 0]);
    addChassisMesh('rail_front_l', frontRailGeo, [-0.43, 0, 0]);

    // 3 & 4. Swept Rear Longitudinal Frame Rails (ریل شاسی عقب)
    const rearRailGeo = createSideBeamGeometry(
      (s) => {
        s.moveTo(-1.98, 0.42);
        s.quadraticCurveTo(-1.42, 0.44, -1.04, 0.33);
        s.lineTo(-0.74, 0.30);
        s.lineTo(-0.74, 0.43);
        s.lineTo(-1.02, 0.45);
        s.quadraticCurveTo(-1.42, 0.56, -1.98, 0.54);
        s.closePath();
      },
      0.11,
      0.012
    );
    addChassisMesh('rail_rear_r', rearRailGeo, [0.43, 0, 0]);
    addChassisMesh('rail_rear_l', rearRailGeo, [-0.43, 0, 0]);

    // 5. Front Radiator Core Support / Cross Tray (سینی جلو)
    const trayFrontGeo = new RoundedBoxGeometry(1.18, 0.16, 0.15, 2, 0.022);
    addChassisMesh('tray_front', trayFrontGeo, [0, 0.48, 1.98]);

    // 6. Rear Impact Support / Under-Trunk Tray (سینی عقب)
    const trayRearGeo = new RoundedBoxGeometry(1.18, 0.15, 0.15, 2, 0.022);
    addChassisMesh('tray_rear', trayRearGeo, [0, 0.48, -2.02]);

    // 7. Stamped Floor Pan with Central Transmission Tunnel (کفپوش و کف خودرو)
    const floorShape = new THREE.Shape();
    floorShape.moveTo(-0.62, 0.32);
    floorShape.lineTo(-0.14, 0.32);
    floorShape.lineTo(-0.08, 0.42);
    floorShape.lineTo(0.08, 0.42);
    floorShape.lineTo(0.14, 0.32);
    floorShape.lineTo(0.62, 0.32);
    floorShape.lineTo(0.62, 0.365);
    floorShape.lineTo(0.16, 0.365);
    floorShape.lineTo(0.10, 0.465);
    floorShape.lineTo(-0.10, 0.465);
    floorShape.lineTo(-0.16, 0.365);
    floorShape.lineTo(-0.62, 0.365);
    floorShape.closePath();
    const floorGeo = new THREE.ExtrudeGeometry(floorShape, {
      depth: 1.54,
      bevelEnabled: true,
      bevelSegments: 2,
      bevelSize: 0.01,
      bevelThickness: 0.01,
    });
    floorGeo.translate(0, 0, -0.77);
    floorGeo.computeVertexNormals();
    addChassisMesh('floor_pan', floorGeo, [0, 0, -0.04]);

    // 8 & 9. Reinforced Rocker Sill Beams (رکاب راست و چپ)
    const rockerGeo = new RoundedBoxGeometry(0.12, 0.15, 1.72, 2, 0.025);
    addChassisMesh('rocker_r', rockerGeo, [0.68, 0.35, -0.04]);
    addChassisMesh('rocker_l', rockerGeo, [-0.68, 0.35, -0.04]);

    // 10 & 11. Swept A-Pillars (ستون A راست و چپ)
    const pillarAGeo = createSideBeamGeometry(
      (s) => {
        s.moveTo(0.76, 0.40);
        s.lineTo(0.84, 0.40);
        s.lineTo(0.84, 0.90);
        s.lineTo(0.28, 1.41);
        s.lineTo(0.19, 1.38);
        s.lineTo(0.74, 0.88);
        s.closePath();
      },
      0.085,
      0.012
    );
    addChassisMesh('pillar_a_r', pillarAGeo, [0.60, 0, 0], [0, 0, 0.10]);
    addChassisMesh('pillar_a_l', pillarAGeo, [-0.60, 0, 0], [0, 0, -0.10]);

    // 12 & 13. Reinforced B-Pillars (ستون B راست و چپ)
    const pillarBGeo = new RoundedBoxGeometry(0.085, 1.02, 0.10, 2, 0.018);
    addChassisMesh('pillar_b_r', pillarBGeo, [0.61, 0.88, -0.06], [0, 0, 0.10]);
    addChassisMesh('pillar_b_l', pillarBGeo, [-0.61, 0.88, -0.06], [0, 0, -0.10]);

    // 14 & 15. Fastback C-Pillars (ستون C راست و چپ)
    const pillarCGeo = createSideBeamGeometry(
      (s) => {
        s.moveTo(-1.54, 0.48);
        s.lineTo(-1.42, 0.48);
        s.lineTo(-0.88, 1.37);
        s.lineTo(-0.98, 1.39);
        s.lineTo(-1.54, 0.88);
        s.closePath();
      },
      0.085,
      0.012
    );
    addChassisMesh('pillar_c_r', pillarCGeo, [0.60, 0, 0], [0, 0, 0.10]);
    addChassisMesh('pillar_c_l', pillarCGeo, [-0.60, 0, 0], [0, 0, -0.10]);

    // 16. Contoured Roof Bow Crossmember (تیر سقف)
    const roofBowShape = new THREE.Shape();
    roofBowShape.moveTo(-0.56, 1.37);
    roofBowShape.quadraticCurveTo(0, 1.44, 0.56, 1.37);
    roofBowShape.lineTo(0.56, 1.425);
    roofBowShape.quadraticCurveTo(0, 1.495, -0.56, 1.425);
    roofBowShape.closePath();
    const roofBeamGeo = new THREE.ExtrudeGeometry(roofBowShape, {
      depth: 0.11,
      bevelEnabled: true,
      bevelSegments: 2,
      bevelSize: 0.01,
      bevelThickness: 0.01,
    });
    roofBeamGeo.translate(0, 0, -0.055);
    roofBeamGeo.computeVertexNormals();
    addChassisMesh('roof_crossmember', roofBeamGeo, [0, 0, -0.06]);

    // =========================================================================
    // Non-Selectable Reference Context (Cantrails, Axles, Ghost Body Silhouette)
    // =========================================================================

    // Upper Roof Cantrails (Left & Right longitudinal upper frame)
    const frameMetalMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.85,
      roughness: 0.25,
    });
    const cantrailGeo = new RoundedBoxGeometry(0.065, 0.065, 1.24, 2, 0.015);
    const cantrailR = new THREE.Mesh(cantrailGeo, frameMetalMat);
    cantrailR.position.set(0.55, 1.40, -0.34);
    const cantrailL = new THREE.Mesh(cantrailGeo, frameMetalMat);
    cantrailL.position.set(-0.55, 1.40, -0.34);
    chassisGroup.add(cantrailR, cantrailL);

    // Front & Rear Cross-Axle Reference Tubes + Wheel Calibration Rings
    const axleGeo = new THREE.CylinderGeometry(0.025, 0.025, 1.48, 12);
    axleGeo.rotateZ(Math.PI / 2);
    const axleF = new THREE.Mesh(axleGeo, frameMetalMat);
    axleF.position.set(0, 0.34, 1.32);
    const axleR = new THREE.Mesh(axleGeo, frameMetalMat);
    axleR.position.set(0, 0.34, -1.36);
    chassisGroup.add(axleF, axleR);

    const wheelRingGeo = new THREE.TorusGeometry(0.32, 0.012, 8, 28);
    wheelRingGeo.rotateY(Math.PI / 2);
    const wheelRingMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.22,
    });
    const wheelCoords: [number, number, number][] = [
      [0.74, 0.34, 1.32],
      [-0.74, 0.34, 1.32],
      [0.74, 0.34, -1.36],
      [-0.74, 0.34, -1.36],
    ];
    wheelCoords.forEach(([wx, wy, wz]) => {
      const ring = new THREE.Mesh(wheelRingGeo, wheelRingMat);
      ring.position.set(wx, wy, wz);
      chassisGroup.add(ring);
    });

    // Subtle Translucent Ghost Body Silhouette for Spatial Context
    const ghostShellGeo = createSideBeamGeometry(
      (s) => {
        s.moveTo(-2.18, 0.28);
        s.lineTo(2.16, 0.24);
        s.quadraticCurveTo(2.22, 0.56, 2.02, 0.76);
        s.quadraticCurveTo(1.42, 0.90, 0.80, 0.95);
        s.lineTo(0.24, 1.43);
        s.quadraticCurveTo(-0.34, 1.49, -0.96, 1.41);
        s.lineTo(-1.54, 1.00);
        s.lineTo(-2.12, 0.92);
        s.closePath();
      },
      1.52,
      0.04
    );
    const ghostShellMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.055,
      depthWrite: false,
      roughness: 0.4,
    });
    const ghostShell = new THREE.Mesh(ghostShellGeo, ghostShellMat);
    const ghostEdgesGeo = new THREE.EdgesGeometry(ghostShellGeo, 35);
    const ghostEdgesMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.12,
    });
    const ghostEdges = new THREE.LineSegments(ghostEdgesGeo, ghostEdgesMat);
    ghostShell.add(ghostEdges);
    chassisGroup.add(ghostShell);

    scene.add(chassisGroup);

    // =========================================================================
    // On-Demand Render Loop & Smooth Camera Transitions
    // =========================================================================
    let animId = 0;
    let renderScheduled = false;
    let lastTime = performance.now();

    const clockTick = (now: number) => {
      animId = 0;
      renderScheduled = false;

      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      let needsNextFrame = false;

      const tr = cameraTransitionRef.current;
      if (tr.active) {
        const lambda = 9;
        camera.position.x = THREE.MathUtils.damp(camera.position.x, tr.position.x, lambda, dt);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, tr.position.y, lambda, dt);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, tr.position.z, lambda, dt);

        controls.target.x = THREE.MathUtils.damp(controls.target.x, tr.target.x, lambda, dt);
        controls.target.y = THREE.MathUtils.damp(controls.target.y, tr.target.y, lambda, dt);
        controls.target.z = THREE.MathUtils.damp(controls.target.z, tr.target.z, lambda, dt);

        if (
          camera.position.distanceToSquared(tr.position) < 0.0004 &&
          controls.target.distanceToSquared(tr.target) < 0.0004
        ) {
          camera.position.copy(tr.position);
          controls.target.copy(tr.target);
          tr.active = false;
        } else {
          needsNextFrame = true;
        }
      }

      const controlsChanged = controls.update();
      if (controlsChanged) {
        needsNextFrame = true;
      }

      renderer.render(scene, camera);

      if (needsNextFrame) {
        scheduleRender();
      }
    };

    const scheduleRender = () => {
      if (renderScheduled) return;
      renderScheduled = true;
      lastTime = performance.now();
      animId = requestAnimationFrame(clockTick);
    };

    requestRenderRef.current = scheduleRender;

    const handleControlsStart = () => {
      cameraTransitionRef.current.active = false;
      scheduleRender();
    };
    const handleControlsChange = () => {
      scheduleRender();
    };

    controls.addEventListener('start', handleControlsStart);
    controls.addEventListener('change', handleControlsChange);
    scheduleRender();

    // Tap-vs-Drag Pointer Raycaster
    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();
    let downX = 0;
    let downY = 0;
    let pointerActive = false;

    const handlePointerDown = (event: PointerEvent) => {
      if (event.pointerType === 'mouse' && event.button !== 0) return;
      downX = event.clientX;
      downY = event.clientY;
      pointerActive = true;
    };

    const handlePointerUp = (event: PointerEvent) => {
      if (!pointerActive) return;
      pointerActive = false;

      const dx = event.clientX - downX;
      const dy = event.clientY - downY;
      if (dx * dx + dy * dy > 64) {
        return;
      }

      const rect = domEl.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      pointerNdc.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(pointerNdc, camera);
      const selectableMeshes = Array.from(meshesRef.current.values());
      const intersects = raycaster.intersectObjects(selectableMeshes, false);

      if (intersects.length > 0) {
        const hitMesh = intersects[0].object as THREE.Mesh;
        const partId = hitMesh.userData.partId as ChassisPartId | undefined;
        if (partId) {
          setSelectedPartId((prev) => (prev === partId ? null : partId));
        }
      }
    };

    const handleContextLost = (event: Event) => {
      event.preventDefault();
      if (animId) {
        cancelAnimationFrame(animId);
        animId = 0;
        renderScheduled = false;
      }
    };

    const handleContextRestored = () => {
      scheduleRender();
    };

    domEl.addEventListener('pointerdown', handlePointerDown);
    domEl.addEventListener('pointerup', handlePointerUp);
    domEl.addEventListener('webglcontextlost', handleContextLost);
    domEl.addEventListener('webglcontextrestored', handleContextRestored);

    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth || 360;
      camera.aspect = newWidth / height;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, height);
      scheduleRender();
    };
    window.addEventListener('resize', handleResize);

    // Thorough Manual Disposal Cleanup on Unmount (Zero GPU Memory Leaks)
    return () => {
      if (animId) {
        cancelAnimationFrame(animId);
      }
      requestRenderRef.current = null;
      window.removeEventListener('resize', handleResize);
      controls.removeEventListener('start', handleControlsStart);
      controls.removeEventListener('change', handleControlsChange);
      domEl.removeEventListener('pointerdown', handlePointerDown);
      domEl.removeEventListener('pointerup', handlePointerUp);
      domEl.removeEventListener('webglcontextlost', handleContextLost);
      domEl.removeEventListener('webglcontextrestored', handleContextRestored);

      disposeThreeScene({
        scene,
        renderer,
        controls,
        extraTextures: [floorTex],
      });

      meshesRef.current.clear();
      edgeLinesRef.current.clear();
      sceneRef.current = null;
      cameraRef.current = null;
      rendererRef.current = null;
      controlsRef.current = null;
    };
  }, []);

  const setCameraAngle = (view: 'front' | 'rear' | 'right' | 'left' | 'top' | 'reset') => {
    if (!cameraRef.current || !controlsRef.current) return;

    const targetPos = cameraTransitionRef.current.position;
    switch (view) {
      case 'front':
        targetPos.set(0, 1.4, 5.15);
        break;
      case 'rear':
        targetPos.set(0, 1.4, -5.2);
        break;
      case 'right':
        targetPos.set(5.2, 1.4, -0.05);
        break;
      case 'left':
        targetPos.set(-5.2, 1.4, -0.05);
        break;
      case 'top':
        targetPos.set(0, 6.2, 0.05);
        break;
      case 'reset':
      default:
        targetPos.copy(DEFAULT_CAMERA_POS);
        break;
    }

    cameraTransitionRef.current.target.copy(DEFAULT_TARGET);
    cameraTransitionRef.current.active = true;
    requestRenderRef.current?.();
  };

  const handleSelectSeverity = (partId: ChassisPartId, severity: ChassisSeverity) => {
    const updated = {
      ...chassisParts,
      [partId]: severity,
    };
    onChange(updated);
  };

  const selectedPartMeta = selectedPartId ? CHASSIS_PARTS_INFO[selectedPartId] : null;
  const currentPartSeverity = selectedPartId ? chassisParts[selectedPartId] || 'none' : 'none';

  const damagedEntries = Object.entries(chassisParts).filter(
    ([_, sev]) => sev !== 'none'
  ) as [ChassisPartId, ChassisSeverity][];

  return (
    <div className="space-y-4">
      <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 shadow-inner">
        {webGlSupported ? (
          <div
            ref={mountRef}
            className="w-full h-[360px] cursor-grab active:cursor-grabbing touch-none select-none"
            style={{ touchAction: 'none' }}
          />
        ) : (
          <div className="w-full h-[360px] flex flex-col items-center justify-center p-4 bg-slate-900 text-slate-300">
            <Info className="w-8 h-8 text-sky-400 mb-2" />
            <p className="text-sm font-semibold">نمای دوبعدی شاسی و ستون‌ها</p>
            <p className="text-xs text-slate-400 mt-1 text-center">
              به دلیل محدودیت مرورگر، نمایش سه‌بعدی در دسترس نیست.
            </p>
          </div>
        )}

        {/* Top Floating Guide */}
        <div className="absolute top-3 right-3 left-3 flex items-center justify-between pointer-events-none">
          <div className="bg-slate-900/85 backdrop-blur-md border border-slate-700/60 rounded-xl px-3 py-1.5 text-xs text-slate-300 shadow-lg flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-sky-400" />
            <span>لمس قطعه جهت تعیین وضعیت شاسی</span>
          </div>

          <button
            type="button"
            onClick={() => setCameraAngle('reset')}
            className="pointer-events-auto bg-slate-900/85 hover:bg-slate-800 text-slate-300 border border-slate-700/60 rounded-xl px-2.5 py-1.5 text-xs font-medium flex items-center gap-1 transition shadow-lg active:scale-95"
            title="نمای اولیه"
          >
            <RotateCcw className="w-3.5 h-3.5 text-sky-400" />
            <span>پیش‌فرض</span>
          </button>
        </div>

        {/* Camera Views Bar */}
        <div className="absolute bottom-3 right-3 left-3 flex items-center justify-center gap-1.5 overflow-x-auto py-1">
          <button
            type="button"
            onClick={() => setCameraAngle('front')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            جلو
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('rear')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            عقب
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('right')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            راست
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('left')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            چپ
          </button>
          <button
            type="button"
            onClick={() => setCameraAngle('top')}
            className="bg-slate-900/80 hover:bg-slate-800 border border-slate-700/50 rounded-lg px-2.5 py-1 text-xs text-slate-300 transition"
          >
            بالا
          </button>
        </div>
      </div>

      {/* Selected Chassis Component Status Panel */}
      {selectedPartMeta && (
        <div className="p-3.5 rounded-xl bg-slate-800/95 border border-sky-500/40 shadow-lg animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-700">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400" />
              <span className="font-semibold text-slate-100 text-sm">{selectedPartMeta.name}</span>
            </div>
            <button
              type="button"
              onClick={() => setSelectedPartId(null)}
              className="text-slate-400 hover:text-slate-200 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-slate-400 mb-2">میزان آسیب یا وضعیت ترمیم را مشخص کنید:</p>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleSelectSeverity(selectedPartMeta.id, 'none')}
              className={`flex items-center justify-between py-2 px-3 rounded-xl text-xs font-semibold border transition ${
                currentPartSeverity === 'none'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                  : 'bg-slate-900/60 text-slate-300 border-slate-700 hover:border-slate-600'
              }`}
            >
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                سالم
              </span>
              {currentPartSeverity === 'none' && <Check className="w-3.5 h-3.5 text-emerald-400" />}
            </button>

            <button
              type="button"
              onClick={() => handleSelectSeverity(selectedPartMeta.id, 'minor')}
              className={`flex items-center justify-between py-2 px-3 rounded-xl text-xs font-semibold border transition ${
                currentPartSeverity === 'minor'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-slate-900/60 text-slate-300 border-slate-700 hover:border-slate-600'
              }`}
            >
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400" />
                ضربه جزئی (۸٪)
              </span>
              {currentPartSeverity === 'minor' && <Check className="w-3.5 h-3.5 text-amber-400" />}
            </button>

            <button
              type="button"
              onClick={() => handleSelectSeverity(selectedPartMeta.id, 'moderate')}
              className={`flex items-center justify-between py-2 px-3 rounded-xl text-xs font-semibold border transition ${
                currentPartSeverity === 'moderate'
                  ? 'bg-orange-500/20 text-orange-300 border-orange-500/50'
                  : 'bg-slate-900/60 text-slate-300 border-slate-700 hover:border-slate-600'
              }`}
            >
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-orange-400" />
                آسیب متوسط (۱۴٪)
              </span>
              {currentPartSeverity === 'moderate' && <Check className="w-3.5 h-3.5 text-orange-400" />}
            </button>

            <button
              type="button"
              onClick={() => handleSelectSeverity(selectedPartMeta.id, 'severe')}
              className={`flex items-center justify-between py-2 px-3 rounded-xl text-xs font-semibold border transition ${
                currentPartSeverity === 'severe'
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                  : 'bg-slate-900/60 text-slate-300 border-slate-700 hover:border-slate-600'
              }`}
            >
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                شکستگی/تعویض (۲۲٪)
              </span>
              {currentPartSeverity === 'severe' && <Check className="w-3.5 h-3.5 text-rose-400" />}
            </button>
          </div>
        </div>
      )}

      {/* Damaged Chassis Components List */}
      <div>
        {damagedEntries.length === 0 ? (
          <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>وضعیت شاسی: کلیه ستون‌ها، لنگه‌های شاسی و سینی‌ها کاملاً سالم هستند.</span>
          </div>
        ) : (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">اجزای آسیب‌دیده اسکلت و شاسی:</span>
              <button
                type="button"
                onClick={() => {
                  const reset: Record<ChassisPartId, ChassisSeverity> = {} as Record<
                    ChassisPartId,
                    ChassisSeverity
                  >;
                  Object.keys(CHASSIS_PARTS_INFO).forEach((k) => {
                    reset[k as ChassisPartId] = 'none';
                  });
                  onChange(reset);
                }}
                className="text-xs text-sky-400 hover:text-sky-300"
              >
                تنظیم همه به سالم
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {damagedEntries.map(([partId, sev]) => {
                const meta = CHASSIS_PARTS_INFO[partId];
                return (
                  <div
                    key={partId}
                    className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 text-xs text-slate-200 px-2.5 py-1 rounded-lg"
                  >
                    <AlertOctagon className="w-3 h-3 text-amber-400" />
                    <span>{meta?.name}</span>
                    <span className="text-[10px] text-amber-300 font-semibold">
                      ({CHASSIS_SEVERITY_LABELS[sev]})
                    </span>
                    <button
                      type="button"
                      onClick={() => handleSelectSeverity(partId, 'none')}
                      className="text-slate-400 hover:text-rose-400 ml-1"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
