import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  X,
  Car,
  TrendingUp,
  Layers,
  ShieldCheck,
} from 'lucide-react';
import { toPersianDigits } from '../utils/persian';
import { ONBOARDING_CONFIG } from '../utils/config';
import { OnboardingSlideId } from '../types';

interface OnboardingOverlayProps {
  isOpen: boolean;
  recommendedSlideIds?: OnboardingSlideId[];
  suggestionReason?: string;
  onSlideViewed?: (slideId: OnboardingSlideId) => void;
  onComplete: (destination?: 'home' | 'pricing' | 'account') => void;
}

interface SlideItem {
  id: OnboardingSlideId;
  stepLabel: string;
  title: string;
  subtitle: string;
  highlights: string[];
  accentBg: string;
  accentText: string;
  ctaLabel: string;
  ctaDestination: 'pricing' | 'account';
  renderIllustration: () => React.ReactNode;
}

const SLIDES: SlideItem[] = [
  {
    id: 'welcome',
    stepLabel: 'آشنایی با اتو اسکوپ',
    title: 'قیمت منصفانه خودرو را دقیق محاسبه کنید',
    subtitle:
      'اتو اسکوپ بر اساس قیمت روز بازار، کارکرد واقعی، سلامت بدنه و وضعیت شاسی، ارزش منطقی معامله را بدون حدس و گمان در اختیار شما می‌گذارد.',
    highlights: [
      'مناسب برای خریداران و فروشندگان خودروهای صفر و کارکرده',
      'تشخیص فوری عادلانه یا گران بودن قیمت پیشنهادی فروشنده',
      'قابل استفاده در موبایل و دسکتاپ با پشتیبانی از تم روز و شب',
    ],
    accentBg: 'bg-sky-500/15',
    accentText: 'text-sky-400',
    ctaLabel: 'شروع کارشناسی خودرو',
    ctaDestination: 'pricing',
    renderIllustration: () => (
      <div className="relative w-full h-44 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-center overflow-hidden px-6">
        <svg
          viewBox="0 0 320 140"
          className="w-full max-w-[280px] h-auto"
          aria-hidden="true"
        >
          {/* Subtle grid backdrop */}
          <defs>
            <linearGradient id="obCarBody" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#0ea5e9" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#6366f1" stopOpacity="0.9" />
            </linearGradient>
          </defs>
          <line x1="20" y1="112" x2="300" y2="112" stroke="currentColor" strokeOpacity="0.18" strokeWidth="1.5" />
          {/* Precision radar arcs */}
          <path d="M 70 96 A 95 95 0 0 1 250 96" fill="none" stroke="#38bdf8" strokeOpacity="0.22" strokeWidth="1.5" strokeDasharray="4 4" />
          <path d="M 96 96 A 68 68 0 0 1 224 96" fill="none" stroke="#38bdf8" strokeOpacity="0.35" strokeWidth="1.5" />
          {/* Clean Sedan Silhouette */}
          <path
            d="M 52 94 L 58 76 C 61 68 69 65 82 64 L 106 43 C 115 35 128 33 156 33 L 198 33 C 216 33 228 40 241 55 L 266 62 C 275 65 279 71 279 81 L 279 94 Z"
            fill="url(#obCarBody)"
            fillOpacity="0.18"
            stroke="url(#obCarBody)"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          {/* Window cabin */}
          <path
            d="M 110 61 L 122 44 C 127 40 135 39 156 39 L 194 39 C 206 39 216 44 226 57 L 228 61 Z"
            fill="#38bdf8"
            fillOpacity="0.16"
            stroke="#38bdf8"
            strokeWidth="1.5"
          />
          <line x1="168" y1="39" x2="168" y2="61" stroke="#38bdf8" strokeWidth="1.5" strokeOpacity="0.7" />
          {/* Wheels */}
          <circle cx="96" cy="96" r="16" fill="#0f172a" stroke="#38bdf8" strokeWidth="2.5" />
          <circle cx="96" cy="96" r="6" fill="#38bdf8" />
          <circle cx="234" cy="96" r="16" fill="#0f172a" stroke="#38bdf8" strokeWidth="2.5" />
          <circle cx="234" cy="96" r="6" fill="#38bdf8" />
          {/* Check nodes */}
          <circle cx="160" cy="24" r="4" fill="#10b981" />
          <circle cx="255" cy="52" r="3.5" fill="#38bdf8" />
          <circle cx="72" cy="58" r="3.5" fill="#6366f1" />
        </svg>
      </div>
    ),
  },
  {
    id: 'market-price',
    stepLabel: 'استعلام قیمت بازار',
    title: 'قیمت روز ایران‌جیب و میانگین دیوار برای توقف‌تولید',
    subtitle:
      'با انتخاب مدل و سال ساخت، قیمت پایه به‌صورت خودکار استعلام می‌شود تا مبنای کارشناسی شما همیشه به‌روز باشد.',
    highlights: [
      'خودروهای در حال تولید: دریافت نرخ زنده از جدول ایران‌جیب',
      'خودروهای توقف‌تولید: میانگین‌گیری خودکار آگهی‌های دیوار و سایت‌های معتبر',
      'نمایش نمودار روند ۳۰ روزه افت یا رشد قیمت در صفحه نتیجه',
    ],
    accentBg: 'bg-emerald-500/15',
    accentText: 'text-emerald-400',
    ctaLabel: 'استعلام قیمت و کارشناسی',
    ctaDestination: 'pricing',
    renderIllustration: () => (
      <div className="relative w-full h-44 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-center overflow-hidden px-5">
        <svg
          viewBox="0 0 320 140"
          className="w-full max-w-[290px] h-auto"
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="obChartArea" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
            </linearGradient>
          </defs>
          {/* Horizontal chart guide lines */}
          <line x1="28" y1="30" x2="292" y2="30" stroke="currentColor" strokeOpacity="0.12" strokeDasharray="3 3" />
          <line x1="28" y1="65" x2="292" y2="65" stroke="currentColor" strokeOpacity="0.12" strokeDasharray="3 3" />
          <line x1="28" y1="100" x2="292" y2="100" stroke="currentColor" strokeOpacity="0.18" />
          {/* Area + Trend Line */}
          <path
            d="M 32 92 C 68 88, 86 72, 118 76 C 150 80, 174 52, 208 55 C 238 58, 256 36, 288 32 L 288 100 L 32 100 Z"
            fill="url(#obChartArea)"
          />
          <path
            d="M 32 92 C 68 88, 86 72, 118 76 C 150 80, 174 52, 208 55 C 238 58, 256 36, 288 32"
            fill="none"
            stroke="#10b981"
            strokeWidth="3"
            strokeLinecap="round"
          />
          {/* Sample data points */}
          <circle cx="32" cy="92" r="4" fill="#10b981" />
          <circle cx="118" cy="76" r="4" fill="#10b981" />
          <circle cx="208" cy="55" r="4" fill="#10b981" />
          <circle cx="288" cy="32" r="5.5" fill="#34d399" stroke="#064e3b" strokeWidth="2" />
          {/* Reference bars */}
          <rect x="44" y="108" width="64" height="16" rx="4" fill="#0ea5e9" fillOpacity="0.2" stroke="#0ea5e9" strokeOpacity="0.5" />
          <text x="76" y="119" textAnchor="middle" fill="#38bdf8" fontSize="8.5" fontWeight="700">ایران‌جیب</text>
          <rect x="128" y="108" width="64" height="16" rx="4" fill="#10b981" fillOpacity="0.2" stroke="#10b981" strokeOpacity="0.5" />
          <text x="160" y="119" textAnchor="middle" fill="#10b981" fontSize="8.5" fontWeight="700">دیوار</text>
          <rect x="212" y="108" width="64" height="16" rx="4" fill="#f59e0b" fillOpacity="0.2" stroke="#f59e0b" strokeOpacity="0.5" />
          <text x="244" y="119" textAnchor="middle" fill="#f59e0b" fontSize="8.5" fontWeight="700">باما و کار</text>
        </svg>
      </div>
    ),
  },
  {
    id: '3d-inspection',
    stepLabel: 'کارشناسی سه‌بعدی',
    title: 'ثبت رنگ و ضربه روی مدل ۳ بعدی بدنه و شاسی',
    subtitle:
      'نیازی به حدس درصد افت ندارید؛ کافی است خودرو را بچرخانید و قطعه آسیب‌دیده را لمس کنید تا کسورات دقیقاً محاسبه شود.',
    highlights: [
      'انتخاب سریع «بدون رنگ»، «دور رنگ»، «تمام رنگ» یا لمس تک‌تک قطعات',
      'بررسی مجزای لنگه‌های شاسی، ستون‌ها و سینی جلو و عقب',
      'در نظر گرفتن کارکرد، تعویض موتور، وضعیت ایربگ و چپ‌شدگی',
    ],
    accentBg: 'bg-indigo-500/15',
    accentText: 'text-indigo-400',
    ctaLabel: 'ورود به کارشناسی سه‌بعدی',
    ctaDestination: 'pricing',
    renderIllustration: () => (
      <div className="relative w-full h-44 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-center overflow-hidden px-5">
        <svg
          viewBox="0 0 320 140"
          className="w-full max-w-[280px] h-auto"
          aria-hidden="true"
        >
          {/* Orbit ring representing 3D rotation */}
          <ellipse
            cx="160"
            cy="88"
            rx="118"
            ry="32"
            fill="none"
            stroke="#6366f1"
            strokeOpacity="0.35"
            strokeWidth="1.5"
            strokeDasharray="5 4"
          />
          {/* Top-down wireframe chassis/body */}
          <rect
            x="92"
            y="26"
            width="136"
            height="72"
            rx="22"
            fill="#6366f1"
            fillOpacity="0.12"
            stroke="#818cf8"
            strokeWidth="2"
          />
          {/* Hood & trunk lines */}
          <line x1="130" y1="26" x2="130" y2="98" stroke="#818cf8" strokeOpacity="0.45" strokeWidth="1.5" />
          <line x1="192" y1="26" x2="192" y2="98" stroke="#818cf8" strokeOpacity="0.45" strokeWidth="1.5" />
          {/* Roof glass */}
          <rect x="136" y="36" width="50" height="52" rx="8" fill="#0ea5e9" fillOpacity="0.22" stroke="#38bdf8" strokeWidth="1.5" />
          {/* Highlighted painted fender */}
          <path d="M 94 42 C 94 31 102 27 116 27 L 128 27 L 128 45 L 94 45 Z" fill="#f59e0b" fillOpacity="0.45" stroke="#f59e0b" strokeWidth="1.5" />
          {/* Highlighted damaged door */}
          <rect x="134" y="88" width="48" height="9" rx="3" fill="#f43f5e" fillOpacity="0.55" stroke="#f43f5e" strokeWidth="1.5" />
          {/* Touch tap rings */}
          <circle cx="111" cy="36" r="9" fill="none" stroke="#f59e0b" strokeOpacity="0.7" strokeWidth="1.5" />
          <circle cx="158" cy="92" r="9" fill="none" stroke="#f43f5e" strokeOpacity="0.7" strokeWidth="1.5" />
          {/* Legend chips in SVG */}
          <circle cx="96" cy="124" r="4" fill="#10b981" />
          <text x="105" y="127" fill="#10b981" fontSize="9" fontWeight="600">سالم</text>
          <circle cx="146" cy="124" r="4" fill="#f59e0b" />
          <text x="155" y="127" fill="#f59e0b" fontSize="9" fontWeight="600">رنگ‌شده</text>
          <circle cx="204" cy="124" r="4" fill="#f43f5e" />
          <text x="213" y="127" fill="#f43f5e" fontSize="9" fontWeight="600">ضربه‌خورده</text>
        </svg>
      </div>
    ),
  },
  {
    id: 'cloud-pdf',
    stepLabel: 'حساب ابری و گواهی رسمی',
    title: 'ذخیره همیشگی با حساب گوگل و چاپ گزارش PDF',
    subtitle:
      'می‌توانید بدون ثبت‌نام کارشناسی را شروع کنید یا با حساب گوگل وارد شوید تا تمام گزارش‌هایتان در فضای ابری محفوظ بماند.',
    highlights: [
      'همگام‌سازی خودکار سوابق بین موبایل و کامپیوتر با حساب گوگل',
      'دریافت تحلیل هوشمند ریسک‌های معامله و استراتژی چانه‌زنی',
      'خروجی رسمی A4 قابل چاپ و ذخیره PDF همراه با کد رهگیری',
    ],
    accentBg: 'bg-amber-500/15',
    accentText: 'text-amber-400',
    ctaLabel: 'ورود با گوگل و ذخیره ابری',
    ctaDestination: 'account',
    renderIllustration: () => (
      <div className="relative w-full h-44 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-center overflow-hidden px-5">
        <svg
          viewBox="0 0 320 140"
          className="w-full max-w-[280px] h-auto"
          aria-hidden="true"
        >
          {/* Certificate sheet */}
          <rect
            x="92"
            y="18"
            width="136"
            height="104"
            rx="12"
            fill="#0ea5e9"
            fillOpacity="0.1"
            stroke="#38bdf8"
            strokeOpacity="0.6"
            strokeWidth="2"
          />
          <line x1="110" y1="38" x2="184" y2="38" stroke="#38bdf8" strokeWidth="3" strokeLinecap="round" />
          <line x1="110" y1="54" x2="208" y2="54" stroke="currentColor" strokeOpacity="0.25" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="110" y1="68" x2="196" y2="68" stroke="currentColor" strokeOpacity="0.25" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="110" y1="82" x2="178" y2="82" stroke="currentColor" strokeOpacity="0.25" strokeWidth="2.5" strokeLinecap="round" />
          {/* Verified shield stamp */}
          <circle cx="196" cy="96" r="16" fill="#10b981" fillOpacity="0.22" stroke="#10b981" strokeWidth="2" />
          <path d="M 189 96 L 194 101 L 204 91" fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          {/* Cloud badge icon */}
          <path
            d="M 56 82 C 48 82 42 76 42 68 C 42 61 47 55 54 54 C 57 46 65 42 73 45 C 79 47 83 52 84 58 C 89 59 93 64 93 70 C 93 77 87 82 80 82 Z"
            fill="#6366f1"
            fillOpacity="0.2"
            stroke="#818cf8"
            strokeWidth="2"
          />
        </svg>
      </div>
    ),
  },
];

const SLIDE_ICONS = [Car, TrendingUp, Layers, ShieldCheck];

export const OnboardingOverlay: React.FC<OnboardingOverlayProps> = ({
  isOpen,
  recommendedSlideIds,
  suggestionReason,
  onSlideViewed,
  onComplete,
}) => {
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState(1);
  const [showAllSlides, setShowAllSlides] = useState(false);
  const [snapshotIds, setSnapshotIds] = useState<OnboardingSlideId[] | undefined>(recommendedSlideIds);
  const [snapshotReason, setSnapshotReason] = useState<string | undefined>(suggestionReason);
  const shouldReduceMotion = useReducedMotion();

  useEffect(() => {
    if (isOpen) {
      setStep(0);
      setShowAllSlides(false);
      setSnapshotIds(recommendedSlideIds);
      setSnapshotReason(suggestionReason);
    }
  }, [isOpen]);

  const hasFilteredRecommendations = Boolean(
    snapshotIds &&
      snapshotIds.length > 0 &&
      snapshotIds.length < SLIDES.length
  );

  const visibleSlides =
    hasFilteredRecommendations && !showAllSlides
      ? SLIDES.filter((s) => snapshotIds!.includes(s.id))
      : SLIDES;

  const safeStep = Math.min(step, Math.max(0, visibleSlides.length - 1));

  useEffect(() => {
    if (!isOpen) return;
    const activeSlide = visibleSlides[safeStep];
    if (activeSlide && onSlideViewed) {
      onSlideViewed(activeSlide.id);
    }
  }, [isOpen, safeStep, showAllSlides]);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onComplete('home');
      } else if (e.key === 'ArrowLeft') {
        // In RTL layout, ArrowLeft moves forward to next slide
        if (safeStep < visibleSlides.length - 1) {
          setDirection(1);
          setStep((prev) => prev + 1);
        }
      } else if (e.key === 'ArrowRight') {
        // In RTL layout, ArrowRight moves back to previous slide
        if (safeStep > 0) {
          setDirection(-1);
          setStep((prev) => prev - 1);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, safeStep, visibleSlides.length, onComplete]);

  if (!isOpen) return null;

  const currentSlide = visibleSlides[safeStep];
  const slideMasterIdx = SLIDES.findIndex((s) => s.id === currentSlide.id);
  const SlideIcon = SLIDE_ICONS[slideMasterIdx >= 0 ? slideMasterIdx : 0];
  const isFirst = safeStep === 0;
  const isLast = safeStep === visibleSlides.length - 1;

  const goNext = () => {
    if (isLast) {
      onComplete(currentSlide.ctaDestination);
    } else {
      setDirection(1);
      setStep((prev) => Math.min(visibleSlides.length - 1, prev + 1));
    }
  };

  const goPrev = () => {
    if (!isFirst) {
      setDirection(-1);
      setStep((prev) => Math.max(0, prev - 1));
    }
  };

  const goToStep = (target: number) => {
    setDirection(target >= safeStep ? 1 : -1);
    setStep(target);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-labelledby="onboarding-slide-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onComplete('home');
        }
      }}
    >
      <motion.div
        initial={shouldReduceMotion ? false : { opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Top Bar: Step counter + Skip button */}
        <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl ${currentSlide.accentBg} ${currentSlide.accentText} flex items-center justify-center shrink-0`}>
              <SlideIcon className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-200 block">
                {currentSlide.stepLabel}
              </span>
              <span className="text-[11px] text-slate-400">
                اسلاید {toPersianDigits(safeStep + 1)} از {toPersianDigits(visibleSlides.length)}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onComplete('home')}
            className="min-h-[44px] px-3 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 transition flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <span>رد کردن</span>
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Adaptive Recommendation Strip when subset is active */}
        {(hasFilteredRecommendations || snapshotReason) && (
          <div className="px-5 py-2.5 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between gap-2 text-[11px]">
            <span className="text-sky-300 font-medium leading-relaxed">
              {showAllSlides
                ? 'نمایش کامل تمام مراحل راهنمای اتو اسکوپ'
                : snapshotReason || 'انتخاب‌شده بر اساس بخش‌هایی که هنوز امتحان نکرده‌اید'}
            </span>
            {hasFilteredRecommendations && (
              <button
                type="button"
                onClick={() => {
                  setShowAllSlides((prev) => !prev);
                  setStep(0);
                }}
                className="shrink-0 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 transition whitespace-nowrap"
              >
                {showAllSlides
                  ? `پیشنهادی (${toPersianDigits(snapshotIds!.length)})`
                  : `همه (${toPersianDigits(SLIDES.length)})`}
              </button>
            )}
          </div>
        )}

        {/* Slide Body (supports horizontal touch swipe) */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={currentSlide.id}
              initial={
                shouldReduceMotion
                  ? false
                  : { opacity: 0, x: direction > 0 ? -24 : 24 }
              }
              animate={{ opacity: 1, x: 0 }}
              exit={
                shouldReduceMotion
                  ? undefined
                  : { opacity: 0, x: direction > 0 ? 24 : -24 }
              }
              transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
              drag={shouldReduceMotion ? false : 'x'}
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.2}
              onDragEnd={(_event, info) => {
                if (info.offset.x > ONBOARDING_CONFIG.SWIPE_THRESHOLD_PX && !isLast) {
                  goNext();
                } else if (info.offset.x < -ONBOARDING_CONFIG.SWIPE_THRESHOLD_PX && !isFirst) {
                  goPrev();
                }
              }}
              className="space-y-4 select-none"
            >
              {currentSlide.renderIllustration()}

              <div className="space-y-2 pt-1">
                <h2
                  id="onboarding-slide-title"
                  className="text-lg sm:text-xl font-black text-slate-100 leading-snug"
                >
                  {currentSlide.title}
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {currentSlide.subtitle}
                </p>
              </div>

              <ul className="space-y-2.5 pt-1">
                {currentSlide.highlights.map((item, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom Controls: Step Indicators + Navigation Buttons (Thumb Zone) */}
        <div className="px-5 py-4 border-t border-slate-800/80 bg-slate-950/40 space-y-3">
          {/* Interactive Step Dots */}
          <div className="flex items-center justify-center gap-1.5" role="tablist" aria-label="مراحل راهنما">
            {visibleSlides.map((s, idx) => {
              const active = idx === safeStep;
              return (
                <button
                  key={s.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  aria-label={`اسلاید ${toPersianDigits(idx + 1)}: ${s.stepLabel}`}
                  onClick={() => goToStep(idx)}
                  className="min-h-[36px] px-1.5 flex items-center justify-center cursor-pointer"
                >
                  <span
                    className={`h-2 rounded-full transition-all duration-200 ${
                      active
                        ? 'w-7 bg-sky-500'
                        : 'w-2 bg-slate-400/50 hover:bg-slate-400'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between gap-3">
            {!isFirst ? (
              <button
                type="button"
                onClick={goPrev}
                className="min-h-[44px] px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition active:scale-95 flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <ArrowRight className="w-4 h-4" />
                <span>قبلی</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onComplete('account')}
                className="min-h-[44px] px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition active:scale-95 whitespace-nowrap shrink-0"
              >
                ورود با گوگل
              </button>
            )}

            <button
              type="button"
              onClick={goNext}
              className="flex-1 min-h-[44px] px-5 rounded-xl bg-gradient-to-l from-sky-500 via-indigo-600 to-purple-600 hover:from-sky-400 hover:to-purple-500 text-white text-xs sm:text-sm font-extrabold shadow-lg shadow-sky-500/20 transition active:scale-98 flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <span>{isLast ? currentSlide.ctaLabel : 'اسلاید بعدی'}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
