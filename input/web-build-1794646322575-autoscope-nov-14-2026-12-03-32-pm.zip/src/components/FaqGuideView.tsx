import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, ShieldAlert, Sparkles, BookOpen, AlertTriangle, Car } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
  category: 'calculation' | 'inspection' | 'legal';
}

const FAQS: FaqItem[] = [
  {
    category: 'calculation',
    question: 'افت قیمت ناشی از آسیب شاسی و ستون‌ها چگونه محاسبه می‌شود؟',
    answer: 'شاسی و ستون‌ها حیاتی‌ترین بخش کلاف و اسکلت خودرو هستند. در الگوریتم اتو اسکوپ، ضریب بالاترین شدت آسیب انتخاب‌شده مبنا قرار می‌گیرد (ضربه جزئی ۸٪، آسیب متوسط ۱۴٪، شکستگی یا تعویض ۲۲٪) و به ازای هر جزء آسیب‌دیده اضافی، ۲٪ به افت شاسی اضافه می‌گردد (حداکثر سقف ۳۵٪). این روش مانع از انباشت غیرواقعی افت در صورت تصادفات چندناحیه‌ای می‌شود.',
  },
  {
    category: 'calculation',
    question: 'منظور از «دور رنگ» و «تمام رنگ» در بازار خودرو ایران چیست؟',
    answer: '«دور رنگ» به خودرویی گفته می‌شود که قطعات جانبی آن (درها، گلگیرها و سپرها) رنگ شده‌اند اما سقف و کاپوت و صندوق آن دست‌نخورده و بدون رنگ هستند. «تمام رنگ» زمانی اطلاق می‌شود که سقف یا کلاف اصلی اتاق نیز رنگ شده باشد؛ که نشانه‌ای از تصادف سنگین، آفتاب‌سوختگی شدید یا واژگونی است و افت قیمت به مراتب بالاتری دارد.',
  },
  {
    category: 'inspection',
    question: 'چگونه می‌توان کارکرد واقعی خودرو را در بازار تشخیص داد؟',
    answer: 'میزان سایش غربیلک فرمان، سردنده، روکش صندلی راننده و لاستیک پدال‌ها اولین نشانه‌های چشمی هستند. همچنین در خودروهای مدرن، دیاگ تخصصی می‌تواند کارکرد را از حافظه ECU یا TCU (گیربکس) بخواند. سوابق تعویض روغن در نمایندگی و برچسب‌های کیلومتر تعویض تسمه تایم نیز معیارهای مطمئنی هستند.',
  },
  {
    category: 'inspection',
    question: 'ضریب برند (Brand Factor) چه تاثیری در قیمت‌گذاری دارد؟',
    answer: 'خودروهای بسیار خوش‌فروش مانند پراید، تیبا، کوییک و ساینا به دلیل نقدشوندگی بالا، افت استهلاک متفاوتی نسبت به خودروهای چینی مونتاژی یا کم‌یاب دارند. در فرمول اتو اسکوپ، برندهای بازار به دقت دسته‌بندی شده‌اند تا افت سالانه و کارکرد اضافی متناسب با نقدشوندگی بازار ایران سنجیده شود.',
  },
  {
    category: 'legal',
    question: 'در معاملات خرید خودرو از سایت‌های دیوار و باما چه نکاتی را رعایت کنیم؟',
    answer: '۱. هرگز بیعانه پرداخت نکنید مگر پس از رویت حضوری و تطبیق مدارک. ۲. اصالت برگ سبز، کارت خودرو، بیمه‌نامه و تسویه خلافی و مالیات نقل و انتقال را استعلام کنید. ۳. حضور در مراکز تعویض پلاک را در مبایعه‌نامه شرط قرار دهید. ۴. خودرو را حتماً پیش از پرداخت کامل وجه توسط کارشناس مجهز به ضخامت‌سنج رنگ دیجیتال بررسی نمایید.',
  },
  {
    category: 'calculation',
    question: 'قیمت روز خودرو در اتو اسکوپ چگونه به‌روزرسانی می‌شود؟',
    answer: 'سیستم با استفاده از هوش مصنوعی Gemini و ابزار Google Search Grounding، آگهی‌ها و گزارش‌های پایگاه‌های معتبر خودرویی نظیر باما، دیوار، شیپور، کارنامه و پدال را جستجو کرده و بازه قیمت و میانگین منطقی روز را استخراج می‌کند. سپس این داده برای ۶ ساعت در دستگاه شما کش می‌شود.',
  },
];

export const FaqGuideView: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleIndex = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-sky-400" />
          <h1 className="text-lg md:text-xl font-bold text-slate-100">راهنما و سوالات متداول کارشناسی خودرو</h1>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          نکات ضروری درباره روش‌های محاسبه افت قیمت، فرمول‌ها، شاسی، رنگ و ترفندهای معامله امن در بازار خودرو ایران
        </p>
      </div>

      {/* Accordion FAQ */}
      <div className="space-y-3">
        {FAQS.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden transition"
            >
              <button
                type="button"
                onClick={() => toggleIndex(idx)}
                className="w-full p-4 md:p-5 text-right flex items-center justify-between gap-3 text-slate-100 hover:text-sky-300 transition"
              >
                <div className="flex items-center gap-2.5">
                  <HelpCircle className="w-4 h-4 text-sky-400 shrink-0" />
                  <span className="text-xs md:text-sm font-bold">{faq.question}</span>
                </div>
                {isOpen ? (
                  <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>

              {isOpen && (
                <div className="px-5 pb-5 text-xs text-slate-300 leading-relaxed border-t border-slate-800/80 pt-3">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Safe Buying Tips Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-950/30 to-slate-900 border border-amber-500/30 text-amber-200 text-xs leading-relaxed space-y-2">
        <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span>توصیه ایمنی کارشناسان اتو اسکوپ:</span>
        </div>
        <p>
          هیچ‌گاه به ادعاهای شفاهی فروشنده مانند «ماشین دست‌نخورده کارمندی بوده» بدون رویت حضوری و کارشناسی رنگ و شاسی اعتماد نکنید. حتی در صورت مثبت بودن نتیجه ارزیابی، پیش از واریز هرگونه وجه بیعانه، خودرو را با کارشناس در محل بررسی فرمایید.
        </p>
      </div>
    </div>
  );
};
