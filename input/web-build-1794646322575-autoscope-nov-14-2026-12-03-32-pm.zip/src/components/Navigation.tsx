import React, { useState } from 'react';
import { User } from 'firebase/auth';
import { ActivePage } from '../types';
import {
  Home,
  Calculator,
  History,
  BookOpen,
  Printer,
  Info,
  X,
  Sun,
  Moon,
  ChevronLeft,
  UserCircle2,
  Cloud,
} from 'lucide-react';

interface NavigationProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  isDrawerOpen: boolean;
  onCloseDrawer: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  historyCount: number;
  user: User | null;
  onOpenOnboarding: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activePage,
  onNavigate,
  isDrawerOpen,
  onCloseDrawer,
  theme,
  onToggleTheme,
  historyCount,
  user,
  onOpenOnboarding,
}) => {
  const [avatarError, setAvatarError] = useState(false);

  const navItems = [
    { id: 'home' as ActivePage, label: 'خانه', icon: Home },
    { id: 'pricing' as ActivePage, label: 'قیمت‌گذاری', icon: Calculator },
    { id: 'history' as ActivePage, label: 'تاریخچه', icon: History, count: historyCount },
    { id: 'faq' as ActivePage, label: 'راهنما', icon: BookOpen },
    { id: 'account' as ActivePage, label: user ? 'حساب من' : 'ورود', icon: UserCircle2 },
  ];

  const drawerItems = [
    { id: 'home' as ActivePage, label: 'صفحه اصلی', icon: Home, desc: 'معرفی و شروع سریع' },
    { id: 'pricing' as ActivePage, label: 'فرم کارشناسی خودرو', icon: Calculator, desc: 'ورود مشخصات، بدنه و شاسی سه‌بعدی' },
    { id: 'history' as ActivePage, label: 'تاریخچه ارزیابی‌ها', icon: History, desc: 'مشاهده گزارش‌ها و خروجی اکسل' },
    { id: 'account' as ActivePage, label: user ? 'حساب کاربری و همگام‌سازی' : 'ورود با حساب گوگل', icon: UserCircle2, desc: user ? (user.email || 'مدیریت حساب ابری') : 'ذخیره دائمی فعالیت‌ها در فضای ابری' },
    { id: 'print' as ActivePage, label: 'چاپ و ذخیره PDF', icon: Printer, desc: 'نسخه رسمی قابل چاپ کارشناسی' },
    { id: 'faq' as ActivePage, label: 'راهنما و سوالات متداول', icon: BookOpen, desc: 'نکات فنی، شاسی و خرید امن' },
    { id: 'about' as ActivePage, label: 'درباره ما و سلب مسئولیت', icon: Info, desc: 'روش‌شناسی و تعهدات قانونی' },
  ];

  return (
    <>
      {/* ── Bottom Sticky Navigation Bar (Mobile First) ── */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-2 print:hidden">
        <div className="max-w-lg mx-auto grid grid-cols-5 gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id || (item.id === 'pricing' && activePage === 'result');
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl transition active:scale-95 relative ${
                  isActive
                    ? 'text-sky-400 font-bold bg-sky-500/10'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5 mb-0.5" />
                  {item.count !== undefined && item.count > 0 && (
                    <span className="absolute -top-1 -right-2 bg-sky-500 text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                      {item.count > 9 ? '+۹' : item.count}
                    </span>
                  )}
                  {item.id === 'account' && user && (
                    <span className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-slate-900" />
                  )}
                </div>
                <span className="text-[11px] leading-tight">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* ── Drawer Menu Overlay ── */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            onClick={onCloseDrawer}
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity"
          />

          {/* Drawer Panel */}
          <div className="relative z-10 w-full max-w-xs bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
            {/* Drawer Header */}
            <div className="p-5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white font-black text-sm">
                  AS
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-100">منوی اتو اسکوپ</h3>
                  <span className="text-[10px] text-slate-400">نسخه ۱.۰ هوشمند</span>
                </div>
              </div>

              <button
                type="button"
                onClick={onCloseDrawer}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl bg-slate-800/80"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* User Account Summary Card inside Drawer */}
            <div className="px-3 pt-3">
              <button
                type="button"
                onClick={() => {
                  onNavigate('account');
                  onCloseDrawer();
                }}
                className="w-full p-3 rounded-2xl bg-slate-950/70 hover:bg-slate-800/70 border border-slate-800 flex items-center justify-between gap-2.5 text-right transition"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  {user && user.photoURL && !avatarError ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || 'کاربر'}
                      onError={() => setAvatarError(true)}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-xl object-cover border border-sky-500/40 shrink-0"
                    />
                  ) : (
                    <div className="w-9 h-9 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center shrink-0">
                      <UserCircle2 className="w-5 h-5" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <span className="text-xs font-bold text-slate-100 block truncate">
                      {user ? user.displayName || 'کاربر اتو اسکوپ' : 'ورود به حساب کاربری'}
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1 truncate">
                      {user ? (
                        <>
                          <Cloud className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span className="truncate">همگام‌سازی ابری فعال</span>
                        </>
                      ) : (
                        'ورود با گوگل برای حفظ سوابق'
                      )}
                    </span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-slate-500 shrink-0" />
              </button>
            </div>

            {/* Drawer Items List */}
            <div className="p-3 overflow-y-auto flex-1 space-y-1">
              {drawerItems.map((item) => {
                const Icon = item.icon;
                const isActive = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onNavigate(item.id);
                      onCloseDrawer();
                    }}
                    className={`w-full p-3 rounded-2xl flex items-center justify-between text-right transition ${
                      isActive
                        ? 'bg-sky-500/15 text-sky-300 font-bold border border-sky-500/30'
                        : 'text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                        isActive ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300'
                      }`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-semibold block">{item.label}</span>
                        <span className="text-[10px] text-slate-400 font-normal block">{item.desc}</span>
                      </div>
                    </div>
                    <ChevronLeft className="w-4 h-4 text-slate-500" />
                  </button>
                );
              })}
            </div>

            {/* Drawer Footer with Onboarding Replay & Theme Toggle */}
            <div className="p-4 border-t border-slate-800 space-y-2.5">
              <button
                type="button"
                onClick={() => {
                  onCloseDrawer();
                  onOpenOnboarding();
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 text-sky-300 text-xs font-semibold flex items-center justify-between transition"
              >
                <span className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-sky-400" />
                  <span>مرور راهنمای خوش‌آمدگویی</span>
                </span>
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs">
                <span className="text-slate-300">تم ظاهری برنامه:</span>
                <button
                  type="button"
                  onClick={onToggleTheme}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition font-medium"
                >
                  {theme === 'dark' ? (
                    <>
                      <Sun className="w-3.5 h-3.5 text-amber-400" />
                      <span>تیره</span>
                    </>
                  ) : (
                    <>
                      <Moon className="w-3.5 h-3.5 text-sky-400" />
                      <span>روشن</span>
                    </>
                  )}
                </button>
              </div>

              <div className="text-[10px] text-slate-500 text-center">
                AutoScope • کارشناسی تخصصی خودرو در بازار ایران
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
