package ir.toska.app

import android.content.Context
import android.webkit.CookieManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/**
 * هر ~۱۵ دقیقه (فقط وقتی کاربر وارد حساب شده) وضعیت سفارش‌ها و پاسخ پرسش‌ها را از سرور می‌خواند
 * و در صورت تغییر اعلان محلی نشان می‌دهد. نیازی به Firebase ندارد؛ اگر بعداً پوش واقعی (FCM) خواستید،
 * سمت سرور باید ارسال پوش اضافه شود.
 */
class PollWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    private val statusFa = mapOf(
        "pending" to "در انتظار تأیید", "confirmed" to "تأیید شد", "preparing" to "در حال آماده‌سازی",
        "shipped" to "ارسال شد", "delivered" to "تحویل داده شد", "cancelled" to "لغو شد",
    )

    private fun get(path: String, cookie: String): JSONArray? = try {
        val c = URL(BuildConfig.SITE_URL + path).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 10_000
        c.setRequestProperty("Cookie", cookie)
        c.setRequestProperty("Accept", "application/json")
        if (c.responseCode == 200) JSONArray(c.inputStream.bufferedReader().readText()) else null
    } catch (e: Exception) { null }

    override fun doWork(): Result {
        val cookie = try { CookieManager.getInstance().getCookie(BuildConfig.SITE_URL) } catch (e: Exception) { null }
        val prefs = ctx.getSharedPreferences("poll", Context.MODE_PRIVATE)
        if (cookie == null || !cookie.contains("toska_customer=")) { prefs.edit().clear().apply(); return Result.success() }

        val orders = get("/api/account/orders", cookie) ?: return Result.retry()
        val questions = get("/api/account/questions", cookie) ?: return Result.retry()
        val first = !prefs.getBoolean("init", false)
        val ed = prefs.edit()

        for (i in 0 until orders.length()) {
            val o = orders.getJSONObject(i)
            val code = o.getString("code"); val st = o.getString("status")
            val old = prefs.getString("o:$code", null)
            if (!first && old != st) {
                Notifier.notify(ctx, code.hashCode(), ctx.getString(R.string.notif_order_title, code),
                    ctx.getString(R.string.notif_order_text, statusFa[st] ?: st), "/account")
            }
            ed.putString("o:$code", st)
        }
        for (i in 0 until questions.length()) {
            val q = questions.getJSONObject(i)
            val code = q.getString("code"); val answered = !q.optString("reply", "").isNullOrEmpty()
            val was = prefs.getBoolean("q:$code", false)
            if (!first && answered && !was) {
                Notifier.notify(ctx, code.hashCode() + 1, ctx.getString(R.string.notif_answer_title),
                    ctx.getString(R.string.notif_answer_text, code), "/account?tab=questions")
            }
            ed.putBoolean("q:$code", answered)
        }
        ed.putBoolean("init", true).apply()
        return Result.success()
    }
}
