package ir.toska.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    companion object { const val EXTRA_PATH = "path" }

    private lateinit var web: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var offline: View
    private lateinit var nav: BottomNavigationView
    private var failed = false
    private var syncingNav = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val siteUri: Uri = Uri.parse(BuildConfig.SITE_URL)
    private val allowedHosts: Set<String> =
        (listOfNotNull(siteUri.host) + BuildConfig.EXTRA_HOSTS.split(",").map { it.trim() }.filter { it.isNotEmpty() }).toSet()

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web); refresh = findViewById(R.id.refresh)
        progress = findViewById(R.id.progress); offline = findViewById(R.id.offline); nav = findViewById(R.id.bottom_nav)
        findViewById<Button>(R.id.retry).setOnClickListener { offline.visibility = View.GONE; failed = false; web.reload() }

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
            userAgentString = "$userAgentString ToskaApp/${BuildConfig.VERSION_NAME}"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        web.addJavascriptInterface(Bridge(), "ToskaNative")
        web.webViewClient = client
        web.webChromeClient = chrome

        refresh.setColorSchemeResources(R.color.gold)
        refresh.setOnRefreshListener { web.reload() }
        refresh.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }

        nav.setOnItemSelectedListener { item ->
            if (!syncingNav) web.loadUrl(BuildConfig.SITE_URL + pathFor(item.itemId))
            true
        }
        nav.setOnItemReselectedListener { item -> web.loadUrl(BuildConfig.SITE_URL + pathFor(item.itemId)) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() } }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(startUrl(intent))
        setupNotifications()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); web.loadUrl(startUrl(intent)) }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); web.saveState(outState) }
    override fun onPause() { CookieManager.getInstance().flush(); super.onPause() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    private fun pathFor(id: Int) = when (id) {
        R.id.nav_shop -> "/shop"
        R.id.nav_cart -> "/cart"
        R.id.nav_track -> "/track"
        R.id.nav_account -> "/account"
        else -> "/"
    }

    /** From a notification (extra) or a deep link; only paths on our own site are ever loaded. */
    private fun startUrl(i: Intent?): String {
        i?.getStringExtra(EXTRA_PATH)?.let { if (it.startsWith("/") && !it.startsWith("//")) return BuildConfig.SITE_URL + it }
        val d = i?.data
        if (d != null && d.host == siteUri.host) return d.toString()
        return BuildConfig.SITE_URL + "/shop"
    }

    private fun setupNotifications() {
        Notifier.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val req = PeriodicWorkRequestBuilder<PollWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("toska-poll", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    private fun openExternal(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: ActivityNotFoundException) { /* no app to handle it */ }
    }

    private val client = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url
            val http = u.scheme == "http" || u.scheme == "https"
            if (http && u.host in allowedHosts) return false
            openExternal(u)            // tel:, mailto:, whatsapp:, تلگرام، اینستاگرام، مرورگر…
            return true
        }
        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) { failed = false; progress.visibility = View.VISIBLE }
        override fun onPageFinished(view: WebView, url: String) {
            progress.visibility = View.GONE; refresh.isRefreshing = false
            if (!failed) offline.visibility = View.GONE
            syncNav(Uri.parse(url).path ?: "/")
        }
        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) { failed = true; offline.visibility = View.VISIBLE; refresh.isRefreshing = false }
        }
    }

    private fun syncNav(path: String) {
        val id = when {
            path.startsWith("/shop") -> R.id.nav_shop
            path.startsWith("/cart") || path.startsWith("/checkout") -> R.id.nav_cart
            path.startsWith("/track") || path.startsWith("/order") || path.startsWith("/pay") -> R.id.nav_track
            path.startsWith("/account") -> R.id.nav_account
            else -> R.id.nav_site
        }
        syncingNav = true; nav.selectedItemId = id; syncingNav = false
    }

    private val chrome = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) { progress.progress = newProgress }
        override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
            fileCallback?.onReceiveValue(null); fileCallback = cb
            return try { chooser.launch(params.createIntent()); true } catch (e: Exception) { fileCallback = null; cb.onReceiveValue(null); false }
        }
    }

    /** window.ToskaNative.share(title, text, url) / isApp() — usable from the web pages. */
    inner class Bridge {
        @JavascriptInterface fun isApp() = true
        @JavascriptInterface fun share(title: String, text: String, url: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, title).putExtra(Intent.EXTRA_TEXT, "$text\n$url")
                startActivity(Intent.createChooser(send, getString(R.string.share_via)))
            }
        }
    }
}
