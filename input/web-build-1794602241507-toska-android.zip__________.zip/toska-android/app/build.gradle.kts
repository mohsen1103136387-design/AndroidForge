import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val siteUrl = ((project.findProperty("TOSKA_SITE_URL") as String?) ?: "http://10.0.2.2:3000").trimEnd('/')
val extraHosts = (project.findProperty("TOSKA_EXTRA_HOSTS") as String?) ?: ""

android {
    namespace = "ir.toska.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.toska.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "SITE_URL", "\"$siteUrl\"")
        buildConfigField("String", "EXTRA_HOSTS", "\"$extraHosts\"")
        manifestPlaceholders["siteHost"] = URI(siteUrl).host ?: "localhost"
        manifestPlaceholders["siteScheme"] = URI(siteUrl).scheme ?: "https"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
