# متدهای پل جاوااسکریپت نباید حذف یا تغییر نام بدهند
-keepclassmembers class ir.autoscope.app.WebAppBridge {
    @android.webkit.JavascriptInterface <methods>;
}
