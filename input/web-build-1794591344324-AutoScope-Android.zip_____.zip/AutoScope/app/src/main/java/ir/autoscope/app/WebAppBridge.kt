package ir.autoscope.app

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * پل بین جاوااسکریپت و اندروید. فقط برای صفحات داخلی برنامه در دسترس است
 * (ناوبری به دامنه‌های بیرونی در MainActivity مسدود و با Intent باز می‌شود).
 * همهٔ متدها روی نخ جاوااسکریپت صدا زده می‌شوند، پس کارهای UI را به نخ اصلی می‌فرستیم.
 */
class WebAppBridge(private val activity: MainActivity) {

    @JavascriptInterface
    fun pageReady() = activity.onPageReady()

    @JavascriptInterface
    fun shareText(text: String) = activity.runOnUiThread { activity.shareText(text) }

    @JavascriptInterface
    fun saveCsv(fileName: String, content: String) = activity.runOnUiThread { activity.saveCsv(fileName, content) }

    @JavascriptInterface
    fun setLightTheme(light: Boolean) = activity.runOnUiThread { activity.applyTheme(light) }

    @JavascriptInterface
    fun printHtml(html: String, jobName: String) = activity.runOnUiThread { activity.printHtml(html, jobName) }
}

/** چاپ/ذخیرهٔ PDF با WebView پنهان تا ظاهر گزارش مستقل از صفحهٔ اصلی باشد. */
internal class ReportPrinter(private val activity: MainActivity) {
    private var holder: WebView? = null

    fun print(html: String, jobName: String) {
        holder?.destroy()
        val wv = WebView(activity)
        holder = wv
        wv.settings.javaScriptEnabled = false
        wv.settings.allowFileAccess = false
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest) =
                activity.assetLoader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView, url: String?) {
                val pm = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val attrs = PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
                pm.print(jobName, view.createPrintDocumentAdapter(jobName), attrs)
            }
        }
        wv.loadDataWithBaseURL(MainActivity.BASE_URL, html, "text/html", "UTF-8", null)
    }

    fun release() { holder?.destroy(); holder = null }
}
