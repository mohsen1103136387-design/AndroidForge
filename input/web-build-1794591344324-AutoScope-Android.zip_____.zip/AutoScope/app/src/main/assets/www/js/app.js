/* AutoScope v1.4 — منطق برنامه (سازگار با WebView قدیمی: بدون ?. و ??) */
(function () {
'use strict';

/* ===== ابزارهای پایه ===== */
var FA = '۰۱۲۳۴۵۶۷۸۹', AR = '٠١٢٣٤٥٦٧٨٩';
var $ = function (id) { return document.getElementById(id); };
var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
var Android = window.AutoScopeAndroid || null; // پل کاتلین (اگر داخل اپ اندروید باشیم)

function toEn(v) {
  return String(v).replace(/[۰-۹]/g, function (d) { return FA.indexOf(d); })
                  .replace(/[٠-٩]/g, function (d) { return AR.indexOf(d); });
}
function toFa(v) { return String(v).replace(/[0-9]/g, function (d) { return FA[d]; }); }
function fmt(n) { return toFa(Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '٬')); }
function fmtPct(p) { // یک رقم اعشار فقط در صورت نیاز
  var r = Math.round(p * 10) / 10;
  return toFa(String(r).replace('.', '٫'));
}
/* فقط ارقام (جداکنندهٔ هزارگان و هر نویسهٔ دیگر حذف می‌شود) */
function digitsOnly(v) { return toEn(v).replace(/[^0-9]/g, ''); }
function parseIntSafe(v) { var d = digitsOnly(v); return d ? parseInt(d, 10) : NaN; }
function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
/* یکسان‌سازی متن برای جستجو و تشخیص برند */
function norm(s) {
  return toFa(String(s || '')).replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/ۀ/g, 'ه')
    .replace(/[‌‍ـً-ٟ\s]+/g, '').toLowerCase();
}

/* ===== تقویم شمسی (بدون وابستگی به ICU) ===== */
function div(a, b) { return ~~(a / b); }
function g2j(gy, gm, gd) {
  var gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  var gy2 = gm > 2 ? gy + 1 : gy;
  var days = 355666 + 365 * gy + div(gy2 + 3, 4) - div(gy2 + 99, 100) + div(gy2 + 399, 400) + gd + gdm[gm - 1];
  var jy = -1595 + 33 * div(days, 12053); days %= 12053;
  jy += 4 * div(days, 1461); days %= 1461;
  if (days > 365) { jy += div(days - 1, 365); days = (days - 1) % 365; }
  var jm = days < 186 ? 1 + div(days, 31) : 7 + div(days - 186, 30);
  var jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}
function jalaliOf(date) { return g2j(date.getFullYear(), date.getMonth() + 1, date.getDate()); }
function pad2(n) { return (n < 10 ? '0' : '') + n; }
function jalaliStr(date, persian) {
  var j = jalaliOf(date), s = j[0] + '/' + pad2(j[1]) + '/' + pad2(j[2]);
  return persian ? toFa(s) : s;
}

var CURRENT_YEAR = jalaliOf(new Date())[0];   // خودکار — دیگر ثابت نیست
var MIN_YEAR = 1350;
var MAX_YEAR = CURRENT_YEAR + 1;               // مدل‌های سال بعد هم وارد بازار می‌شوند
var MAX_KM = 2000000;

/* ===== اعلان‌ها ===== */
function makeToast(id, ms) {
  var box = $(id), timer = null;
  return function (msg) {
    box.querySelector('span').textContent = msg;
    box.classList.add('show');
    clearTimeout(timer);
    timer = setTimeout(function () { box.classList.remove('show'); }, ms || 2600);
  };
}
var notify = makeToast('alertBox');
var succeed = makeToast('successBox');

/* ===== دیالوگ تأیید داخلی (جایگزین confirm/prompt که در WebView ناپایدارند) ===== */
function askConfirm(msg, okText) {
  return new Promise(function (resolve) {
    var wrap = document.createElement('div');
    wrap.className = 'modal open';
    wrap.setAttribute('role', 'alertdialog');
    wrap.innerHTML = '<div class="sheet"><div class="handle"></div><p class="lead"></p>' +
      '<div class="hist-actions"><button type="button" class="hist-action-btn" data-r="0">انصراف</button>' +
      '<button type="button" class="hist-action-btn danger" data-r="1"></button></div></div>';
    wrap.querySelector('p').textContent = msg;
    wrap.querySelector('[data-r="1"]').textContent = okText || 'تأیید';
    function done(v) { document.body.removeChild(wrap); resolve(v); }
    wrap.addEventListener('click', function (e) {
      var r = e.target.getAttribute && e.target.getAttribute('data-r');
      if (r !== null && r !== undefined) done(r === '1');
      else if (e.target === wrap) done(false);
    });
    document.body.appendChild(wrap);
    wrap.__close = function () { done(false); };
  });
}

/* ===== ناوبری ===== */
var PAGES = { home: 'pageHome', pricing: 'pagePricing', history: 'pageHistory', pdf: 'pagePdf', guide: 'pageGuide', about: 'pageAbout' };
var pageStack = ['home'];

function showPage(name) {
  $$('.page').forEach(function (p) { p.classList.remove('active'); });
  var el = $(PAGES[name]);
  if (el) el.classList.add('active');
  $('navHome').classList.toggle('active', name === 'home');
  window.scrollTo(0, 0);
  if (name === 'history') renderHistory();
  if (name === 'pdf') preparePdf();
}
function goTo(name, reset) {
  if (name === 'home' || reset) pageStack = [name];
  else if (pageStack[pageStack.length - 1] !== name) pageStack.push(name);
  showPage(name);
}
function goBack() {
  if (pageStack.length > 1) { pageStack.pop(); showPage(pageStack[pageStack.length - 1]); return true; }
  return false;
}
/* دکمهٔ بازگشت سخت‌افزاری اندروید: true یعنی توسط وب مصرف شد */
window.__autoscopeBack = function () {
  var dlg = document.querySelector('.modal.open[role="alertdialog"]');
  if (dlg && dlg.__close) { dlg.__close(); return true; }
  if ($('drawerPanel').classList.contains('open')) { closeDrawer(); return true; }
  if (document.querySelector('.modal.open')) { closeModals(); return true; }
  return goBack();
};

/* ===== منوی کشویی ===== */
function openDrawer() {
  $('drawerOverlay').classList.add('open');
  $('drawerPanel').classList.add('open');
  var cur = pageStack[pageStack.length - 1];
  $$('.dr-item[data-page]').forEach(function (it) { it.classList.toggle('active', it.getAttribute('data-page') === cur); });
}
function closeDrawer() {
  $('drawerOverlay').classList.remove('open');
  $('drawerPanel').classList.remove('open');
}

/* ===== تم ===== */
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  var lbl = $('themeLabel'); if (lbl) lbl.textContent = t === 'light' ? 'حالت تیره' : 'حالت روشن';
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'light' ? '#f1f5f9' : '#0f172a');
  if (Android && Android.setLightTheme) { try { Android.setLightTheme(t === 'light'); } catch (e) {} }
}
function toggleTheme() {
  var next = (document.documentElement.getAttribute('data-theme') || 'dark') === 'dark' ? 'light' : 'dark';
  try { localStorage.setItem('autoscope_theme', next); } catch (e) {}
  applyTheme(next);
}
applyTheme(document.documentElement.getAttribute('data-theme') || 'dark');

/* ===== انتخاب سال ===== */
var yearVal = '';
function buildYearList() {
  var html = '';
  for (var y = MAX_YEAR; y >= MIN_YEAR; y--) {
    html += '<button type="button" class="yr-item' + (String(y) === yearVal ? ' selected' : '') + '" data-y="' + y + '">' + toFa(y) + '</button>';
  }
  var box = $('yearList');
  box.innerHTML = html;
  var sel = box.querySelector('.selected');
  if (sel) setTimeout(function () { sel.scrollIntoView({ block: 'center' }); }, 120);
}
function setYear(y) {
  yearVal = y ? String(y) : '';
  $('yearText').textContent = y ? toFa(y) + ' (سال تولید)' : 'انتخاب سال تولید';
  $('yearBtn').classList.toggle('placeholder', !y);
}
function selectYear(y) { setYear(y); closeModals(); }
function applyManualYear() {
  var v = parseIntSafe($('yrManual').value);
  if (isNaN(v) || v < MIN_YEAR || v > MAX_YEAR) { notify('سال باید بین ' + toFa(MIN_YEAR) + ' و ' + toFa(MAX_YEAR) + ' باشد'); return; }
  selectYear(v);
}
function openYear() {
  closeModals();
  $('yearModal').classList.add('open');
  $('yrManual').value = '';
  buildYearList();
}
$('yearList').addEventListener('click', function (e) {
  var b = e.target.closest ? e.target.closest('.yr-item') : null;
  if (b) selectYear(b.getAttribute('data-y'));
});
$('yrManual').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); applyManualYear(); } });
$('yrRange').textContent = toFa(MIN_YEAR) + ' تا ' + toFa(MAX_YEAR);
$$('.yr-now').forEach(function (el) { el.textContent = toFa(CURRENT_YEAR); });

/* ===== ورودی‌های عددی: نمایش با جداکنندهٔ هزارگان ===== */
function bindNumeric(id) {
  var el = $(id);
  el.addEventListener('input', function () {
    var d = digitsOnly(el.value);
    el.value = d ? fmt(parseInt(d, 10)) : '';
  });
}
bindNumeric('km'); bindNumeric('newPrice'); bindNumeric('askPrice');
$('yrManual').addEventListener('input', function () { this.value = toFa(digitsOnly(this.value)).slice(0, 4); });

/* ===== دیاگرام بدنه ===== */
var ZONES = [
  { name: 'سپر جلو', type: 'normal', x: 70, y: 10, w: 80, h: 30, rx: 6 },
  { name: 'کاپوت', type: 'normal', x: 70, y: 44, w: 80, h: 66, rx: 4 },
  { name: 'شیشه جلو', type: 'structural', x: 70, y: 114, w: 80, h: 28, rx: 4 },
  { name: 'سقف', type: 'structural', x: 70, y: 146, w: 80, h: 72, rx: 4 },
  { name: 'شیشه عقب', type: 'structural', x: 70, y: 222, w: 80, h: 28, rx: 4 },
  { name: 'صندوق عقب', type: 'normal', x: 70, y: 254, w: 80, h: 82, rx: 4 },
  { name: 'سپر عقب', type: 'normal', x: 70, y: 340, w: 80, h: 30, rx: 6 },
  { name: 'گلگیر جلو چپ', type: 'normal', x: 30, y: 44, w: 36, h: 66, rx: 6 },
  { name: 'درب جلو چپ', type: 'normal', x: 30, y: 114, w: 36, h: 76, rx: 4 },
  { name: 'درب عقب چپ', type: 'normal', x: 30, y: 194, w: 36, h: 86, rx: 4 },
  { name: 'گلگیر عقب چپ', type: 'normal', x: 30, y: 284, w: 36, h: 86, rx: 6 },
  { name: 'گلگیر جلو راست', type: 'normal', x: 154, y: 44, w: 36, h: 66, rx: 6 },
  { name: 'درب جلو راست', type: 'normal', x: 154, y: 114, w: 36, h: 76, rx: 4 },
  { name: 'درب عقب راست', type: 'normal', x: 154, y: 194, w: 36, h: 86, rx: 4 },
  { name: 'گلگیر عقب راست', type: 'normal', x: 154, y: 284, w: 36, h: 86, rx: 6 }
];
var NS = 'http://www.w3.org/2000/svg';
function addText(svg, x, y, str, size) {
  var t = document.createElementNS(NS, 'text');
  t.setAttribute('x', x); t.setAttribute('y', y); t.setAttribute('text-anchor', 'middle');
  t.setAttribute('fill', '#64748b'); t.setAttribute('font-size', size || 10);
  t.setAttribute('pointer-events', 'none'); t.textContent = str; svg.appendChild(t);
}
function buildSVG(svg, mode) {
  ZONES.forEach(function (z) {
    var r = document.createElementNS(NS, 'rect');
    r.setAttribute('x', z.x); r.setAttribute('y', z.y); r.setAttribute('width', z.w); r.setAttribute('height', z.h); r.setAttribute('rx', z.rx);
    r.setAttribute('data-name', z.name); r.setAttribute('data-type', z.type);
    r.setAttribute('class', 'zone' + (mode === 'paint' && z.name.indexOf('شیشه') > -1 ? ' disabled' : ''));
    svg.appendChild(r);
  });
  addText(svg, 110, 7, 'جلو', 9); addText(svg, 110, 398, 'عقب', 9);
  addText(svg, 12, 205, 'چپ', 10); addText(svg, 208, 205, 'راست', 10);
  addText(svg, 110, 187, 'روی بدنه کلیک کنید', 11);
}
var svgHit = $('svgHit'), svgPaint = $('svgPaint');
buildSVG(svgHit, 'hit'); buildSVG(svgPaint, 'paint');
var selectedHits = [], selectedPaints = [];
var hitChips = $('hitChips'), paintChips = $('paintChips');
var HIT_EMPTY = 'هنوز ناحیه‌ای انتخاب نشده', PAINT_EMPTY = 'بدنه بدون رنگ‌شدگی';

function renderChips(el, names, emptyText, extra) {
  if (!names.length) { el.innerHTML = '<span class="chip empty">' + emptyText + '</span>'; return; }
  el.innerHTML = names.map(function (n) { return '<span class="chip' + (extra ? ' ' + extra : '') + '">' + esc(n) + '</span>'; }).join('');
}
function refreshChips() {
  renderChips(hitChips, selectedHits.map(function (h) { return h.name; }), HIT_EMPTY, '');
  renderChips(paintChips, selectedPaints.map(function (p) { return p.name; }), PAINT_EMPTY, 'paint');
}
function syncSvg() {
  $$('.zone', svgHit).forEach(function (z) {
    var n = z.getAttribute('data-name');
    z.classList.toggle('hit', selectedHits.some(function (h) { return h.name === n; }));
  });
  $$('.zone', svgPaint).forEach(function (z) {
    var n = z.getAttribute('data-name');
    z.classList.toggle('painted', selectedPaints.some(function (p) { return p.name === n; }));
  });
}
function setRadio(name, val) {
  var r = document.querySelector('input[name="' + name + '"][value="' + val + '"]');
  if (r) r.checked = true;
}
svgHit.addEventListener('click', function (e) {
  var z = e.target;
  if (!z.classList || !z.classList.contains('zone')) return;
  var name = z.getAttribute('data-name'), type = z.getAttribute('data-type');
  if (selectedHits.some(function (h) { return h.name === name; })) selectedHits = selectedHits.filter(function (h) { return h.name !== name; });
  else selectedHits.push({ name: name, type: type });
  syncSvg(); refreshChips();
});
svgPaint.addEventListener('click', function (e) {
  var z = e.target;
  if (!z.classList || !z.classList.contains('zone') || z.classList.contains('disabled')) return;
  var name = z.getAttribute('data-name');
  if (selectedPaints.some(function (p) { return p.name === name; })) selectedPaints = selectedPaints.filter(function (p) { return p.name !== name; });
  else selectedPaints.push({ name: name });
  setRadio('paint', 'manual');
  syncSvg(); refreshChips();
});
function setPaintMode(mode) {
  selectedPaints = [];
  if (mode === 'auto-around' || mode === 'auto-full') {
    ZONES.forEach(function (z) {
      if (z.name.indexOf('شیشه') > -1) return;
      if (mode === 'auto-around' && z.name === 'سقف') return;
      selectedPaints.push({ name: z.name });
    });
  }
  syncSvg(); refreshChips();
}
$$('input[name="paint"]').forEach(function (i) {
  i.addEventListener('change', function () { if (this.value !== 'manual') setPaintMode(this.value); });
});
$$('input[name="hasAirbag"]').forEach(function (i) {
  i.addEventListener('change', function () { $('airbagBox').classList.toggle('open', this.value === 'yes'); });
});
$$('input[name="chassis"]').forEach(function (i) {
  i.addEventListener('change', function () { $('chassisBox').classList.toggle('open', this.value === 'no'); });
});

/* ===== ضرایب ===== */
function paintPct(name) {
  if (name.indexOf('سقف') > -1) return 3;
  if (name.indexOf('کاپوت') > -1 || name.indexOf('صندوق') > -1) return 2;
  if (name.indexOf('درب') > -1) return 1.2;
  if (name.indexOf('گلگیر') > -1) return 1;
  if (name.indexOf('سپر') > -1) return 0.5;
  return 1;
}
function hitPct(h) {
  if (h.type === 'structural') return 0.08;
  if (h.name.indexOf('گلگیر') > -1) return 0.03;
  if (h.name.indexOf('درب') > -1) return 0.025;
  if (h.name.indexOf('سپر') > -1) return 0.015;
  if (h.name.indexOf('صندوق') > -1) return 0.04;
  return 0.02;
}
var RE_STD = /پژو|سمند|دنا|رانا|تارا|هایما/;
var RE_LOW = /پراید|تیبا|ساینا|کوییک|کوئیک|شاهین|اطلس|سهند/;
var RE_IMP = /تندر|ساندرو|جک|امویام|چری|برلیانس|دانگ|فیدلیتی|دیگنیتی|لاماری|ریسپکت|آریزو|بسترن|فونیکس/;
function getBrandFactor(model) { // norm فاصله و نیم‌فاصله را حذف می‌کند
  var m = norm(model);
  if (RE_STD.test(m)) return 1.0;
  if (RE_LOW.test(m)) return 1.15;
  if (RE_IMP.test(m)) return 0.9;
  return 1.0;
}
var TAG_PCT = { sunburn: 2, city: 3, imported: 1.5, taxi: 5, '': 0 };
var TAG_NAMES = { sunburn: 'آفتاب‌سوخته', city: 'کارکرده شهری', imported: 'وارداتی دست دوم', taxi: 'استفادهٔ تاکسی/اسنپ', '': '' };
var MAX_TOTAL_DEDUCTION = 0.9; // قیمت منطقی هرگز کمتر از ۱۰٪ قیمت پایه نمی‌شود

/* ===== محاسبه ===== */
function calculatePrice(d) {
  var base = d.newPrice, list = [];
  function add(factor, pct, amount) { list.push({ factor: factor, percentage: pct, amount: amount }); }
  var bf = getBrandFactor(d.model);
  var age = CURRENT_YEAR - d.year;

  if (age > 0) {
    var rate = Math.min(0.05 * bf, 0.07);
    var amt = Math.min(base * rate * age, base * 0.55);
    add('سن خودرو (' + toFa(age) + ' سال)', amt / base * 100, amt);
  }
  var stdKm = Math.max(0, age) * 20000;
  var extra = Math.max(0, d.km - stdKm);
  if (extra > 0) {
    var kmAmt = base * (extra / 100000) * 0.03 * Math.max(0.7, bf);
    add('کارکرد اضافی (' + fmt(extra) + ' کیلومتر)', kmAmt / base * 100, kmAmt);
  }
  if (d.hits.length) {
    var hd = 0; d.hits.forEach(function (h) { hd += base * hitPct(h); });
    add('ضربه‌خوردگی (' + toFa(d.hits.length) + ' ناحیه)', hd / base * 100, hd);
  }
  if (d.paintZones.length) {
    var pp = 0; d.paintZones.forEach(function (p) { pp += paintPct(p.name); });
    add('رنگ‌شدگی بدنه (' + toFa(d.paintZones.length) + ' ناحیه)', pp, base * pp / 100);
  }
  if (d.engine === 'yes') add('تعویض موتور', 12, base * 0.12);
  if (d.flip === 'yes') add('چپ‌کردگی خودرو', 25, base * 0.25);
  if (d.hasAirbag === 'no') add('نداشتن ایربگ', 5, base * 0.05);
  else if (d.airbagOpen === 'yes') add('باز شدن ایربگ', 8, base * 0.08);
  if (d.chassis === 'no') {
    var sev = d.chassisSev;
    var ct = sev <= 0.08 ? 'آسیب جزئی' : (sev <= 0.14 ? 'آسیب متوسط' : 'شکستگی/تعویض');
    var regs = d.chassisRegions && d.chassisRegions.length ? ' — ' + d.chassisRegions.join('، ') : '';
    add('آسیب شاسی (' + ct + ')' + regs, sev * 100, base * sev);
  }
  if (d.tag && TAG_PCT[d.tag] > 0) add('برچسب: ' + TAG_NAMES[d.tag], TAG_PCT[d.tag], base * TAG_PCT[d.tag] / 100);

  var total = list.reduce(function (s, x) { return s + x.amount; }, 0);
  var cap = base * MAX_TOTAL_DEDUCTION;
  if (total > cap) { // کاهش متناسب تا جدول با قیمت نهایی هم‌خوان بماند
    var k = cap / total;
    list.forEach(function (x) { x.amount *= k; x.percentage *= k; });
    total = cap;
  }
  return { fairPrice: base - total, deductions: list, totalDeduction: total, capped: total >= cap - 0.5 };
}
function getVerdict(fair, ask) {
  if (!ask || fair <= 0) return { cls: 'ok', title: '✅ قیمت منطقی محاسبه شد', text: 'قیمت منطقی این خودرو با توجه به وضعیت فعلی محاسبه شده است. هنگام خرید این قیمت را با قیمت فروشنده مقایسه کنید.' };
  var dp = (ask - fair) / fair * 100, a = fmt(ask), f = fmt(fair);
  if (dp <= -5) return { cls: 'great', title: '🎉 معامله عالی!', text: 'قیمت فروشنده (' + a + ' تومان) حدود ' + toFa(Math.abs(Math.round(dp))) + '٪ کمتر از قیمت منطقی است. این یک فرصت خرید بسیار خوب است! (حتماً دلیل ارزانی را بررسی کنید.)' };
  if (dp <= 5) return { cls: 'ok', title: '✅ قیمت منصفانه', text: 'قیمت فروشنده (' + a + ' تومان) در محدودهٔ منطقی است و با قیمت کارشناسی‌شده (' + f + ' تومان) تفاوت قابل‌توجهی ندارد.' };
  if (dp <= 15) return { cls: 'caution', title: '⚠️ قیمت بالا', text: 'قیمت فروشنده (' + a + ' تومان) حدود ' + toFa(Math.round(dp)) + '٪ بالاتر از قیمت منطقی (' + f + ' تومان) است. سعی کنید تخفیف بگیرید.' };
  return { cls: 'bad', title: '❌ قیمت خیلی بالا', text: 'قیمت فروشنده (' + a + ' تومان) حدود ' + toFa(Math.round(dp)) + '٪ بالاتر از قیمت منطقی (' + f + ' تومان) است. این معامله توصیه نمی‌شود مگر اینکه فروشنده تخفیف قابل‌توجهی بدهد.' };
}

/* ===== فرم ===== */
var form = $('carForm'), btnCalc = $('btnCalc'), toast = $('toast'), results = $('results');
var computing = false, lastResult = null, lastData = null, feedbackFor = null;

function checked(name) { var r = document.querySelector('input[name="' + name + '"]:checked'); return r ? r.value : ''; }
function collectFormData() {
  return {
    model: $('model').value.trim().replace(/\s+/g, ' '),
    year: parseInt(yearVal, 10),
    km: parseIntSafe($('km').value),
    newPrice: parseIntSafe($('newPrice').value),
    askPrice: parseIntSafe($('askPrice').value) || 0,
    hits: selectedHits.slice(), paintZones: selectedPaints.slice(),
    engine: checked('engine'), flip: checked('flip'),
    hasAirbag: checked('hasAirbag'), airbagOpen: checked('airbagOpen'),
    chassis: checked('chassis'), chassisSev: parseFloat(checked('chassisSev')),
    chassisRegions: $$('input[name="chassisRegion"]:checked').map(function (c) { return c.value; }),
    tag: checked('tag')
  };
}
function validateForm(d) {
  if (!d.model) { notify('لطفاً نام و مدل خودرو را وارد کنید'); return false; }
  if (isNaN(d.year) || d.year < MIN_YEAR || d.year > MAX_YEAR) { notify('لطفاً سال تولید را انتخاب کنید'); return false; }
  if (isNaN(d.km) || d.km < 0 || d.km > MAX_KM) { notify('لطفاً کیلومتر کارکرد معتبر وارد کنید'); return false; }
  if (isNaN(d.newPrice) || d.newPrice <= 0) { notify('لطفاً قیمت نو معتبر وارد کنید'); return false; }
  return true;
}
function animateValue(id, target) {
  var el = $(id), t0 = null, dur = 900;
  function step(ts) {
    if (t0 === null) t0 = ts;
    var p = Math.min((ts - t0) / dur, 1);
    el.textContent = fmt(p >= 1 ? target : Math.floor(p * target)) + ' تومان';
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
function drawChart(newPrice, fair, ask) {
  var vals = [{ lbl: 'نو', val: newPrice, cls: 'new' }, { lbl: 'منطقی', val: fair, cls: 'fair' }];
  if (ask > 0) vals.push({ lbl: 'اعلامی', val: ask, cls: 'ask' });
  var mx = Math.max.apply(null, vals.map(function (v) { return v.val; })) || 1;
  $('chartBars').innerHTML = vals.map(function (v) {
    var h = Math.max(4, v.val / mx * 100);
    return '<div class="bar-col"><div class="bar-val">' + fmt(v.val) + '</div><div class="bar ' + v.cls + '" style="height:' + h.toFixed(1) + '%"></div><div class="bar-lbl">' + v.lbl + '</div></div>';
  }).join('');
}
function showResults(data, result, skipSave) {
  lastData = data; lastResult = result;
  $('resModel').textContent = data.model;
  animateValue('resNew', data.newPrice);
  animateValue('resFair', result.fairPrice);
  var tb = $('resBreakdown');
  if (!result.deductions.length) tb.innerHTML = '<tr><td colspan="3" class="td-empty">این خودرو هیچ افت قیمتی ندارد!</td></tr>';
  else tb.innerHTML = result.deductions.map(function (x) {
    return '<tr><td>' + esc(x.factor) + '</td><td class="pct">-' + fmtPct(x.percentage) + '٪</td><td class="num">' + fmt(x.amount) + '</td></tr>';
  }).join('') + (result.capped ? '<tr><td colspan="3" class="td-empty">مجموع افت‌ها به سقف ۹۰٪ محدود شد.</td></tr>' : '');
  var v = getVerdict(result.fairPrice, data.askPrice);
  $('resVerdict').className = 'verdict ' + v.cls;
  $('verdictTitle').textContent = v.title;
  $('verdictText').textContent = v.text;
  drawChart(data.newPrice, result.fairPrice, data.askPrice);
  $('fbThanks').classList.remove('show');
  $$('.fb-btn').forEach(function (b) { b.classList.remove('active'); });
  results.classList.add('show');
  if (!skipSave) { lastData.id = saveToHistory(data, result); }
  setTimeout(function () { results.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 80);
}
form.addEventListener('submit', function (e) {
  e.preventDefault();
  if (computing) return;
  var data = collectFormData();
  if (!validateForm(data)) return;
  computing = true; btnCalc.disabled = true; toast.classList.add('show');
  setTimeout(function () {
    var result = calculatePrice(data);
    toast.classList.remove('show'); btnCalc.disabled = false; computing = false;
    showResults(data, result);
  }, 600);
});
function resetForm() {
  form.reset(); setYear('');
  $('carSelectText').textContent = 'انتخاب از لیست یا تایپ دستی';
  $('carSelectBtn').classList.add('placeholder');
  selectedHits = []; selectedPaints = []; syncSvg(); refreshChips();
  $('airbagBox').classList.remove('open'); $('chassisBox').classList.remove('open');
  results.classList.remove('show');
  lastResult = null; lastData = null;
  window.scrollTo(0, 0);
}
$('btnReset').addEventListener('click', resetForm);

/* ===== تاریخچه ===== */
function loadHistory() { try { var a = JSON.parse(localStorage.getItem('autoscope_history') || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
function saveHistory(arr) { try { localStorage.setItem('autoscope_history', JSON.stringify(arr.slice(0, 50))); } catch (e) {} }
function saveToHistory(d, r) {
  var arr = loadHistory(), id = Date.now();
  arr.unshift({ id: id, date: new Date().toISOString(), model: d.model, year: d.year, km: d.km, newPrice: d.newPrice, askPrice: d.askPrice,
    hits: d.hits, paintZones: d.paintZones, engine: d.engine, flip: d.flip, hasAirbag: d.hasAirbag, airbagOpen: d.airbagOpen,
    chassis: d.chassis, chassisSev: d.chassisSev, chassisRegions: d.chassisRegions, tag: d.tag, fairPrice: r.fairPrice, deductions: r.deductions });
  saveHistory(arr); updateHistCount();
  return id;
}
function updateHistCount() {
  var c = loadHistory().length, el = $('histCount');
  if (c > 0) { el.textContent = toFa(c); el.style.display = 'inline-block'; } else el.style.display = 'none';
}
function renderHistory() {
  var fq = norm($('histSearch').value || '');
  var all = loadHistory();
  var arr = all.filter(function (it) { return !fq || norm(it.model).indexOf(fq) > -1; });
  var list = $('histList');
  if (!arr.length) {
    list.innerHTML = '<div class="hist-empty">' + (all.length ? 'خودرویی با این نام یافت نشد.' : 'هنوز محاسبه‌ای ثبت نشده است.<br>اولین خودروی خود را قیمت‌گذاری کنید!') + '</div>';
    return;
  }
  list.innerHTML = arr.map(function (it) {
    return '<div class="hist-item" data-id="' + it.id + '"><div class="hist-info"><div class="hist-model">' + esc(it.model) + '</div><div class="hist-meta">' +
      jalaliStr(new Date(it.date), true) + ' • سال ' + toFa(it.year) + ' • ' + fmt(it.km) + ' کیلومتر</div></div><div class="hist-price">' + fmt(it.fairPrice) +
      '</div><button type="button" class="hist-del" data-del="' + it.id + '" aria-label="حذف">✕</button></div>';
  }).join('');
}
$('histList').addEventListener('click', function (e) {
  var del = e.target.closest ? e.target.closest('[data-del]') : null;
  if (del) { e.stopPropagation(); delHist(parseInt(del.getAttribute('data-del'), 10)); return; }
  var item = e.target.closest ? e.target.closest('.hist-item') : null;
  if (item) viewHist(parseInt(item.getAttribute('data-id'), 10));
});
$('histSearch').addEventListener('input', renderHistory);

function viewHist(id) {
  var it = loadHistory().filter(function (x) { return x.id === id; })[0];
  if (!it) return;
  $('model').value = it.model;
  setYear(it.year);
  $('carSelectText').textContent = it.model; $('carSelectBtn').classList.remove('placeholder');
  $('km').value = fmt(it.km); $('newPrice').value = fmt(it.newPrice);
  $('askPrice').value = it.askPrice ? fmt(it.askPrice) : '';
  selectedHits = (it.hits || []).slice(); selectedPaints = (it.paintZones || []).slice();
  syncSvg(); refreshChips();
  setRadio('paint', selectedPaints.length ? 'manual' : '0');
  setRadio('engine', it.engine); setRadio('flip', it.flip); setRadio('hasAirbag', it.hasAirbag); setRadio('airbagOpen', it.airbagOpen);
  setRadio('chassis', it.chassis); setRadio('chassisSev', String(it.chassisSev)); setRadio('tag', it.tag || '');
  $$('input[name="chassisRegion"]').forEach(function (c) { c.checked = (it.chassisRegions || []).indexOf(c.value) > -1; });
  $('airbagBox').classList.toggle('open', it.hasAirbag === 'yes');
  $('chassisBox').classList.toggle('open', it.chassis === 'no');
  goTo('pricing', true);
  /* نتیجهٔ ذخیره‌شده را مستقیم نشان بده تا با فرم هم‌خوان باشد */
  var data = collectFormData(); data.id = id;
  showResults(data, { fairPrice: it.fairPrice, deductions: it.deductions || [], totalDeduction: it.newPrice - it.fairPrice, capped: false }, true);
  succeed('رکورد بارگذاری شد — می‌توانید ویرایش و دوباره محاسبه کنید');
}
function delHist(id) {
  askConfirm('این رکورد حذف شود؟', 'حذف').then(function (ok) {
    if (!ok) return;
    saveHistory(loadHistory().filter(function (x) { return x.id !== id; }));
    renderHistory(); updateHistCount(); succeed('رکورد حذف شد');
  });
}
function clearAllHistory() {
  if (!loadHistory().length) { notify('تاریخچه‌ای وجود ندارد'); return; }
  askConfirm('همهٔ تاریخچه پاک شود؟ این عمل قابل بازگشت نیست.', 'پاک کردن همه').then(function (ok) {
    if (!ok) return;
    saveHistory([]); renderHistory(); updateHistCount(); succeed('تاریخچه پاک شد');
  });
}
function csvCell(c) {
  var s = String(c === undefined || c === null ? '' : c);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // جلوگیری از تزریق فرمول در اکسل
  return '"' + s.replace(/"/g, '""') + '"';
}
function exportCSV() {
  var arr = loadHistory();
  if (!arr.length) { notify('تاریخچه‌ای وجود ندارد'); return; }
  var rows = [['مدل', 'سال', 'کارکرد', 'قیمت نو', 'قیمت اعلامی', 'قیمت منطقی', 'تاریخ (شمسی)']];
  arr.forEach(function (it) { rows.push([it.model, it.year, it.km, it.newPrice, it.askPrice || '', Math.round(it.fairPrice), jalaliStr(new Date(it.date), false)]); });
  var csv = '﻿' + rows.map(function (r) { return r.map(csvCell).join(','); }).join('\r\n');
  var name = 'autoscope-history.csv';
  if (Android && Android.saveCsv) { Android.saveCsv(name, csv); return; }
  var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
  succeed('فایل CSV دانلود شد');
}
/* پاسخ پل اندروید */
window.__autoscopeToast = function (msg, ok) { (ok ? succeed : notify)(msg); };

/* ===== گزارش چاپ / PDF ===== */
function preparePdf() {
  var pv = $('pdfPreview'), btn = $('btnPrint');
  if (lastData && lastResult) {
    pv.innerHTML = '<div class="pdf-prev"><strong>' + esc(lastData.model) + '</strong><br><small>سال ' + toFa(lastData.year) + ' • قیمت منطقی: ' + fmt(lastResult.fairPrice) + ' تومان</small></div>';
    btn.disabled = false;
  } else {
    pv.innerHTML = '<div class="pdf-none">هنوز نتیجه‌ای برای چاپ موجود نیست. ابتدا یک خودرو را قیمت‌گذاری کنید.</div>';
    btn.disabled = true;
  }
}
function fontUrl() { try { return new URL('fonts/Vazirmatn.woff2', document.baseURI).href; } catch (e) { return 'fonts/Vazirmatn.woff2'; } }
function buildReportHtml() {
  var d = lastData, r = lastResult;
  var rows = r.deductions.map(function (x) {
    return '<tr><td>' + esc(x.factor) + '</td><td class="c">-' + fmtPct(x.percentage) + '٪</td><td class="l">' + fmt(x.amount) + '</td></tr>';
  }).join('') || '<tr><td colspan="3" class="c">بدون افت قیمت</td></tr>';
  var v = getVerdict(r.fairPrice, d.askPrice);
  return '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title>گزارش کارشناسی AutoScope</title><style>' +
    "@font-face{font-family:'Vazirmatn';src:url('" + fontUrl() + "') format('woff2');font-weight:100 900}" +
    "body{font-family:'Vazirmatn',Tahoma,sans-serif;color:#111;margin:0;padding:24px;line-height:1.9;font-size:14px}" +
    'h1{font-size:20px;margin:0 0 4px}.sub{color:#666;font-size:12px;margin-bottom:16px}' +
    'p{margin:2px 0}table{width:100%;border-collapse:collapse;margin-top:14px}th,td{padding:8px;border-bottom:1px solid #ddd;text-align:right}' +
    '.c{text-align:center}.l{text-align:left;direction:ltr}.big{font-size:17px;font-weight:700;margin-top:12px}' +
    '.v{margin-top:16px;padding:12px;border:1px solid #999;border-radius:8px}.foot{margin-top:18px;font-size:11px;color:#666}' +
    '</style></head><body><h1>گزارش کارشناسی AutoScope</h1><div class="sub">تاریخ گزارش: ' + jalaliStr(new Date(), true) + '</div>' +
    '<p><b>خودرو:</b> ' + esc(d.model) + '</p><p><b>سال تولید:</b> ' + toFa(d.year) + '</p><p><b>کارکرد:</b> ' + fmt(d.km) + ' کیلومتر</p>' +
    '<p><b>قیمت نو/بازار:</b> ' + fmt(d.newPrice) + ' تومان</p>' + (d.askPrice ? '<p><b>قیمت اعلامی فروشنده:</b> ' + fmt(d.askPrice) + ' تومان</p>' : '') +
    '<div class="big">قیمت منطقی محاسبه‌شده: ' + fmt(r.fairPrice) + ' تومان</div>' +
    '<table><thead><tr><th>عامل</th><th class="c">درصد افت</th><th class="l">مبلغ کسر شده (تومان)</th></tr></thead><tbody>' + rows + '</tbody></table>' +
    '<div class="v"><b>' + esc(v.title) + '</b><br>' + esc(v.text) + '</div>' +
    '<div class="foot">این قیمت تخمینی است و مبنای معامله قرار نمی‌گیرد؛ خودرو را حضوری کارشناسی کنید.</div></body></html>';
}
function doPrint() {
  if (!lastData || !lastResult) { notify('ابتدا یک خودرو را قیمت‌گذاری کنید'); return; }
  var html = buildReportHtml();
  if (Android && Android.printHtml) { Android.printHtml(html, 'AutoScope - ' + lastData.model); return; }
  var fr = document.createElement('iframe');
  fr.style.cssText = 'position:fixed;width:0;height:0;border:0;visibility:hidden';
  document.body.appendChild(fr);
  fr.srcdoc = html;
  fr.onload = function () {
    try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (e) { notify('چاپ در این مرورگر پشتیبانی نمی‌شود'); }
    setTimeout(function () { if (fr.parentNode) fr.parentNode.removeChild(fr); }, 60000);
  };
}

/* ===== اشتراک‌گذاری ===== */
function shareResult() {
  if (!lastData || !lastResult) { notify('ابتدا یک خودرو را قیمت‌گذاری کنید'); return; }
  var d = lastData, txt = '🚗 کارشناسی خودرو با AutoScope\n\nمدل: ' + d.model + '\nسال: ' + toFa(d.year) + '\nکارکرد: ' + fmt(d.km) + ' کیلومتر\nقیمت نو: ' + fmt(d.newPrice) +
    ' تومان\nقیمت منطقی: ' + fmt(lastResult.fairPrice) + ' تومان' + (d.askPrice ? '\nقیمت فروشنده: ' + fmt(d.askPrice) + ' تومان' : '');
  if (Android && Android.shareText) { Android.shareText(txt); return; }
  if (navigator.share) { navigator.share({ title: 'کارشناسی ' + d.model, text: txt }).catch(function () {}); return; }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(txt).then(function () { succeed('متن نتیجه کپی شد'); }, function () { notify('کپی انجام نشد'); });
  } else notify('اشتراک‌گذاری در این مرورگر پشتیبانی نمی‌شود');
}

/* ===== بازخورد (فقط محلی) ===== */
function giveFeedback(pos, btn) {
  if (!lastData || !lastResult) return;
  $$('.fb-btn').forEach(function (b) { b.classList.remove('active'); });
  btn.classList.add('active');
  var fb = []; try { fb = JSON.parse(localStorage.getItem('autoscope_feedback') || '[]'); } catch (e) {}
  var key = lastData.id || null;
  fb = fb.filter(function (x) { return !key || x.id !== key; }); // یک بازخورد برای هر نتیجه
  fb.push({ id: key, date: new Date().toISOString(), model: lastData.model, year: lastData.year, fairPrice: lastResult.fairPrice, positive: pos });
  try { localStorage.setItem('autoscope_feedback', JSON.stringify(fb.slice(-200))); } catch (e) {}
  $('fbThanks').classList.add('show');
}

/* ===== لیست خودروها ===== */
var CARS = [
  { g: 'ایران خودرو', items: ['پژو ۲۰۶ تیپ ۲', 'پژو ۲۰۶ تیپ ۵', 'پژو ۲۰۶ صندوق‌دار V8', 'پژو ۲۰۷ دنده‌ای', 'پژو ۲۰۷ اتوماتیک', 'پژو ۲۰۷ سقف شیشه‌ای', 'پژو پارس TU5', 'پژو پارس XU7', 'پژو پارس ELX', 'پژو پارس LX', 'پژو ۴۰۵ SLX', 'پژو ۴۰۵ GLX', 'سمند LX', 'سمند EF7', 'سمند سریر', 'سمند سورن', 'سمند سورن پلاس', 'دنا معمولی', 'دنا پلاس', 'دنا پلاس توربو', 'دنا پلاس اتوماتیک', 'رانا معمولی', 'رانا پلاس', 'تارا دنده‌ای', 'تارا اتوماتیک', 'هایما S5', 'هایما S7', 'هایما ۸S'] },
  { g: 'سایپا', items: ['پراید ۱۱۱', 'پراید ۱۳۱', 'پراید ۱۳۲', 'پراید ۱۵۱ (وانت)', 'تیبا صندوق‌دار', 'تیبا ۲ هاچ‌بک', 'ساینا معمولی', 'ساینا S', 'ساینا EX', 'کوییک معمولی', 'کوییک R', 'کوییک S', 'کوییک GX', 'کوییک پلاس اتوماتیک', 'شاهین G', 'شاهین اتوماتیک', 'اطلس', 'سهند'] },
  { g: 'مونتاژی و وارداتی پرفروش', items: ['تندر ۹۰ E2', 'تندر ۹۰ پلاس', 'ساندرو معمولی', 'ساندرو استپ‌وی', 'جک J4', 'جک J5', 'جک S3', 'جک S4', 'جک S5', 'ام‌وی‌ام X22', 'ام‌وی‌ام X33', 'ام‌وی‌ام X55', 'چری تیگو ۵', 'چری تیگو ۷', 'چری تیگو ۸ پرو', 'برلیانس H320', 'برلیانس H330', 'دانگ‌فنگ H30 کراس', 'فیدلیتی پرایم', 'دیگنیتی پرایم', 'دیگنیتی پرستیژ', 'لاماری ایما', 'ریسپکت', 'آریزو ۵', 'آریزو ۶', 'بسترن B30', 'بسترن B70', 'فونیکس FX'] }
];
function renderCarList(q) {
  var nq = norm(q), html = '';
  CARS.forEach(function (gr) {
    var items = gr.items.filter(function (n) { return !nq || norm(n).indexOf(nq) > -1; });
    if (!items.length) return;
    html += '<div class="cgroup">' + esc(gr.g) + '</div>';
    items.forEach(function (n) { html += '<button type="button" class="citem">' + esc(n) + '</button>'; });
  });
  $('carList').innerHTML = html || '<div class="nolist">خودرویی پیدا نشد — می‌توانید دستی تایپ کنید</div>';
}
function openCar() {
  closeModals(); $('carModal').classList.add('open');
  $('carSearch').value = ''; renderCarList('');
  setTimeout(function () { $('carSearch').focus(); }, 300);
}
$('carList').addEventListener('click', function (e) {
  var b = e.target.closest ? e.target.closest('.citem') : null;
  if (!b) return;
  $('model').value = b.textContent;
  $('carSelectText').textContent = b.textContent;
  $('carSelectBtn').classList.remove('placeholder');
  closeModals();
});
$('carSearch').addEventListener('input', function () { renderCarList(this.value); });
function closeModals() { $$('.modal').forEach(function (m) { if (!m.hasAttribute('role') || m.getAttribute('role') === 'dialog') m.classList.remove('open'); }); }
$$('.modal').forEach(function (m) { m.addEventListener('click', function (e) { if (e.target === m) closeModals(); }); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') window.__autoscopeBack(); });

/* ===== اتصال دکمه‌ها (به‌جای onclick داخل HTML) ===== */
var ACTIONS = {
  goTo: function (a) { goTo(a); },
  drawerGo: function (a) { closeDrawer(); goTo(a, true); },
  goBack: function () { goBack(); },
  openDrawer: openDrawer, closeDrawer: closeDrawer,
  toggleTheme: function () { toggleTheme(); closeDrawer(); },
  openCar: openCar, openYear: openYear, manualYear: applyManualYear,
  share: shareResult, savePdf: function () { goTo('pdf'); }, print: doPrint,
  exportCsv: exportCSV, clearHist: clearAllHistory,
  feedback: function (a, el) { giveFeedback(a === '1', el); },
  faq: function (a, el) { var it = el.parentNode, open = !it.classList.contains('open'); it.classList.toggle('open', open); el.setAttribute('aria-expanded', open ? 'true' : 'false'); }
};
document.addEventListener('click', function (e) {
  var el = e.target.closest ? e.target.closest('[data-act]') : null;
  if (!el) return;
  var fn = ACTIONS[el.getAttribute('data-act')];
  if (fn) fn(el.getAttribute('data-arg'), el);
});
/* لینک‌های بیرونی: در اندروید توسط کاتلین با Intent باز می‌شوند */

/* ===== شروع ===== */
updateHistCount();
refreshChips();
function hideSplash() {
  var s = $('appSplash'); if (!s) return;
  s.classList.add('hide');
  setTimeout(function () { if (s.parentNode) s.parentNode.removeChild(s); }, 450);
}
if (Android) { var s0 = $('appSplash'); if (s0 && s0.parentNode) s0.parentNode.removeChild(s0); }
else window.addEventListener('load', function () { setTimeout(hideSplash, 500); });
if (Android && Android.pageReady) { try { Android.pageReady(); } catch (e) {} }

/* برای تست‌های خودکار */
window.__autoscope = { calculatePrice: calculatePrice, getBrandFactor: getBrandFactor, jalaliOf: jalaliOf, CURRENT_YEAR: CURRENT_YEAR, parseIntSafe: parseIntSafe, norm: norm };
})();
