# AutoScope v1.4 — پروژهٔ اندروید (Kotlin + WebView)

## اجرا
1. پوشهٔ `AutoScope` را در Android Studio (نسخهٔ Ladybug یا جدیدتر) باز کنید و Sync را بزنید.
2. **فونت:** فایل `Vazirmatn[wght].woff2` (از github.com/rastikerdar/vazirmatn → fonts/webfonts) را با نام
   `Vazirmatn.woff2` در `app/src/main/assets/www/fonts/` بگذارید. بدون آن، برنامه با فونت سیستم کار می‌کند.
3. Run روی گوشی/شبیه‌ساز. برای انتشار: Build ▸ Generate Signed Bundle / APK.

## ساختار
- `app/src/main/assets/www/` — کل وب‌اپ (index.html, css/app.css, js/app.js, icon.svg) کاملاً آفلاین
- `MainActivity.kt` — WebView امن، اسپلش، دکمهٔ بازگشت، Insets، باز کردن لینک‌های بیرونی
- `WebAppBridge.kt` — اشتراک‌گذاری، ذخیرهٔ CSV، چاپ/PDF، رنگ نوار وضعیت

## نکته
- نسخهٔ AGP/Kotlin/Gradle را در صورت پیشنهاد Android Studio به‌روز کنید (Upgrade Assistant).
- `applicationId` مطابق لینک مایکت شما `ir.autoscope.app` است.

## گرفتن APK
- **Android Studio:** Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s) ← خروجی در `app/build/outputs/apk/debug/app-debug.apk`
- **بدون نصب Android Studio:** پروژه را در یک مخزن GitHub بگذارید؛ در تب Actions گردش‌کار «Build APK» را اجرا و APK را از Artifacts دانلود کنید.
- برای انتشار در مایکت باید APK/AAB با کلید امضای خودتان (Generate Signed Bundle / APK) ساخته شود.
