# AutoScope Firestore Security Specification

## 1. Data Invariants
1. **Strict Ownership & PII Isolation (`/users/{userId}`):**
   - A `UserProfile` document contains PII (`email`, `displayName`, `photoURL`) and may only be read (`get`), created, updated, or deleted by the authenticated owner whose `request.auth.uid == userId` and `request.auth.token.email_verified == true`.
   - Blanket user listing (`allow list` on `/users`) is strictly forbidden.
   - A user cannot spoof another user's `uid` or modify immutable fields (`uid`, `createdAt`).
2. **Master Gate & Subcollection Integrity (`/users/{userId}/appraisals/{appraisalId}`):**
   - An `Appraisal` document cannot be created unless the parent `/users/{userId}` document already exists (`exists(...)`), preventing orphaned appraisal records.
   - Every `Appraisal` must have `ownerId == request.auth.uid` and `id == appraisalId`, both matching `^[a-zA-Z0-9_\-]+$` with length `<= 128`.
   - `allow list` on appraisals never delegates filtering to the client: it enforces `isOwner(userId) && resource.data.ownerId == request.auth.uid` without calling `get()` or `exists()`.
   - All server timestamps (`createdAt`, `updatedAt`, `lastLoginAt`) must equal `request.time`.
   - All strings, maps, and arrays have strict `.size()` bounds; shadow/ghost fields are rejected via `hasOnly()`.

---

## 2. The "Dirty Dozen" Adversarial Payloads

1. **Cross-User Profile Read (PII Leak):** User B (`uid: "user_b"`) attempts `get(/users/user_a)` -> **MUST FAIL (`PERMISSION_DENIED`)**.
2. **User Directory Scraping:** User A attempts `list(/users)` -> **MUST FAIL (`PERMISSION_DENIED`)**.
3. **Unverified Email Write:** Authenticated user with `email_verified: false` attempts `create(/users/user_a)` -> **MUST FAIL (`PERMISSION_DENIED`)**.
4. **Shadow / Ghost Field Injection on Profile:** User A attempts `create(/users/user_a)` with `{ ..., isAdmin: true, role: "superadmin" }` -> **MUST FAIL (`PERMISSION_DENIED`)**.
5. **Identity Spoofing on Profile:** User B (`uid: "user_b"`) attempts `create(/users/user_b)` with `{ uid: "user_a", ... }` -> **MUST FAIL (`PERMISSION_DENIED`)**.
6. **Client-Forged Timestamp on Profile:** User A attempts `create(/users/user_a)` with `createdAt: Timestamp(2020-01-01)` instead of `serverTimestamp()` -> **MUST FAIL (`PERMISSION_DENIED`)**.
7. **Immutable Field Mutation (`createdAt` / `uid`):** User A attempts `update(/users/user_a)` changing `createdAt` or `uid` -> **MUST FAIL (`PERMISSION_DENIED`)**.
8. **Orphaned Appraisal Create (Missing Parent Profile):** User A attempts `create(/users/user_a/appraisals/rec_1)` before `/users/user_a` exists -> **MUST FAIL (`PERMISSION_DENIED`)**.
9. **ID Poisoning (Oversized / Invalid Characters):** User A attempts `create(/users/user_a/appraisals/rec$bad..id)` or 500-char ID -> **MUST FAIL (`PERMISSION_DENIED`)**.
10. **OwnerId Spoofing on Appraisal:** User A attempts `create(/users/user_a/appraisals/rec_1)` with `ownerId: "user_b"` -> **MUST FAIL (`PERMISSION_DENIED`)**.
11. **Value & Resource Exhaustion Poisoning:** User A attempts `create(/users/user_a/appraisals/rec_1)` with `carModel` > 150 chars, `labels` > 10 items, `labels[0]` as number `123`, or `mileage: 99999999` -> **MUST FAIL (`PERMISSION_DENIED`)**.
12. **Unscoped List Query (Client Delegation Bypass):** User B attempts `list(/users/user_a/appraisals)` or `list` without matching `ownerId` -> **MUST FAIL (`PERMISSION_DENIED`)**.

---

## 3. Rules Verification Plan (Emulator Test Runner Reference)
All 12 payloads above must yield `PERMISSION_DENIED` when evaluated against `firestore.rules` with `@firebase/rules-unit-testing`:

```ts
// Reference specification for @firebase/rules-unit-testing assertions:
// 1. assertFails(getDoc(doc(userB, 'users/user_a')))
// 2. assertFails(getDocs(collection(userA, 'users')))
// 3. assertFails(setDoc(doc(unverifiedUserA, 'users/user_a'), validProfile))
// 4. assertFails(setDoc(doc(userA, 'users/user_a'), { ...validProfile, isAdmin: true }))
// 5. assertFails(setDoc(doc(userB, 'users/user_b'), { ...validProfile, uid: 'user_a' }))
// 6. assertFails(setDoc(doc(userA, 'users/user_a'), { ...validProfile, createdAt: new Date(0) }))
// 7. assertFails(updateDoc(doc(userA, 'users/user_a'), { createdAt: new Date(0) }))
// 8. assertFails(setDoc(doc(userA_noProfile, 'users/user_a/appraisals/rec_1'), validAppraisal))
// 9. assertFails(setDoc(doc(userA, 'users/user_a/appraisals/bad$id!'), validAppraisal))
// 10. assertFails(setDoc(doc(userA, 'users/user_a/appraisals/rec_1'), { ...validAppraisal, ownerId: 'user_b' }))
// 11. assertFails(setDoc(doc(userA, 'users/user_a/appraisals/rec_1'), { ...validAppraisal, mileage: 99999999 }))
// 12. assertFails(getDocs(collection(userB, 'users/user_a/appraisals')))
```
