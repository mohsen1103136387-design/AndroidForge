import { DayPriceInfo } from '../types';
import { STORAGE_CONFIG } from './config';
import { toEnglishDigits } from './persian';
import { getCachedDayPrice, setCachedDayPrice } from './storage';

const DB_NAME = 'AutoScopePriceCacheDB';
const DB_VERSION = 2;
const STORE_NAME = 'day_prices';
const SNAPSHOT_STORE_NAME = 'price_snapshots';

interface PriceCacheRecord {
  cacheKey: string;
  modelName: string;
  year: number;
  data: DayPriceInfo;
  cachedAt: number;
}

export interface PriceSnapshotEntry {
  id: string;
  modelKey: string;
  modelName: string;
  year: number;
  dateIso: string; // YYYY-MM-DD (Gregorian calendar day)
  price: number;
  min?: number;
  max?: number;
  source: string;
  recordedAt: number;
}

/**
 * Normalize model name + year into a consistent cache key regardless of Persian/Arabic digits or ZWNJ
 */
export function buildPriceCacheKey(modelName: string, year: number): string {
  const normalized = toEnglishDigits(modelName)
    .toLowerCase()
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\s\u200c()\[\]\/\-_.،,]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return `${normalized}__${year}`;
}

export function getTodayDateIso(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function openPriceCacheDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }

  return new Promise((resolve) => {
    try {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'cacheKey' });
          store.createIndex('cachedAt', 'cachedAt', { unique: false });
        }
        if (!db.objectStoreNames.contains(SNAPSHOT_STORE_NAME)) {
          const snapStore = db.createObjectStore(SNAPSHOT_STORE_NAME, { keyPath: 'id' });
          snapStore.createIndex('modelKey', 'modelKey', { unique: false });
          snapStore.createIndex('recordedAt', 'recordedAt', { unique: false });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
      request.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function getLocalFallbackSnapshots(modelKey: string): PriceSnapshotEntry[] {
  try {
    const raw = localStorage.getItem(`${STORAGE_CONFIG.KEYS.PRICE_SNAPSHOTS_PREFIX}${modelKey}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as PriceSnapshotEntry[]) : [];
  } catch {
    return [];
  }
}

function saveLocalFallbackSnapshot(entry: PriceSnapshotEntry): void {
  try {
    const existing = getLocalFallbackSnapshots(entry.modelKey).filter((s) => s.id !== entry.id);
    const next = [...existing, entry]
      .sort((a, b) => a.dateIso.localeCompare(b.dateIso))
      .slice(-STORAGE_CONFIG.MAX_SNAPSHOTS_PER_MODEL);
    localStorage.setItem(
      `${STORAGE_CONFIG.KEYS.PRICE_SNAPSHOTS_PREFIX}${entry.modelKey}`,
      JSON.stringify(next)
    );
  } catch {
    // ignore storage quota error
  }
}

/**
 * Record a verified real price observation for (modelName, year, dateIso) into IndexedDB.
 */
export async function recordPriceSnapshotAsync(
  modelName: string,
  year: number,
  price: number,
  options?: {
    min?: number;
    max?: number;
    source?: string;
    dateIso?: string;
  }
): Promise<void> {
  if (!modelName.trim() || !Number.isFinite(price) || price <= 0) return;

  const modelKey = buildPriceCacheKey(modelName, year);
  const dateIso = options?.dateIso || getTodayDateIso();
  const entry: PriceSnapshotEntry = {
    id: `${modelKey}__${dateIso}`,
    modelKey,
    modelName: modelName.trim(),
    year,
    dateIso,
    price: Math.round(price),
    min: options?.min && options.min > 0 ? Math.round(options.min) : undefined,
    max: options?.max && options.max > 0 ? Math.round(options.max) : undefined,
    source: options?.source || 'استعلام بازار',
    recordedAt: Date.now(),
  };

  saveLocalFallbackSnapshot(entry);

  const db = await openPriceCacheDb();
  if (!db) return;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(SNAPSHOT_STORE_NAME, 'readwrite');
      const store = tx.objectStore(SNAPSHOT_STORE_NAME);
      store.put(entry);
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        resolve();
      };
    } catch {
      try {
        db.close();
      } catch {
        // ignore
      }
      resolve();
    }
  });
}

/**
 * Read real historical price snapshots stored in IndexedDB for (modelName, year), sorted chronologically.
 */
export async function getPriceSnapshotsAsync(
  modelName: string,
  year: number
): Promise<PriceSnapshotEntry[]> {
  if (!modelName.trim()) return [];
  const modelKey = buildPriceCacheKey(modelName, year);
  const fallbackList = getLocalFallbackSnapshots(modelKey);

  const db = await openPriceCacheDb();
  if (!db) return fallbackList;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(SNAPSHOT_STORE_NAME, 'readonly');
      const store = tx.objectStore(SNAPSHOT_STORE_NAME);
      const idx = store.index('modelKey');
      const req = idx.getAll(modelKey);

      req.onsuccess = () => {
        const dbItems = Array.isArray(req.result) ? (req.result as PriceSnapshotEntry[]) : [];
        db.close();
        const mergedMap = new Map<string, PriceSnapshotEntry>();
        for (const item of fallbackList) {
          mergedMap.set(item.dateIso, item);
        }
        for (const item of dbItems) {
          mergedMap.set(item.dateIso, item);
        }
        const sorted = Array.from(mergedMap.values())
          .sort((a, b) => a.dateIso.localeCompare(b.dateIso))
          .slice(-STORAGE_CONFIG.MAX_SNAPSHOTS_PER_MODEL);
        resolve(sorted);
      };

      req.onerror = () => {
        db.close();
        resolve(fallbackList);
      };
    } catch {
      try {
        db.close();
      } catch {
        // ignore
      }
      resolve(fallbackList);
    }
  });
}

/**
 * Check IndexedDB first for a valid price entry (< 6 hours old) before querying backend/Gemini/Search.
 * Falls back cleanly to localStorage if IndexedDB is blocked or unavailable.
 */
export async function getCachedDayPriceAsync(
  modelName: string,
  year: number
): Promise<DayPriceInfo | null> {
  const cacheKey = buildPriceCacheKey(modelName, year);
  const ttlMs = STORAGE_CONFIG.PRICE_CACHE_TTL_MS;
  const db = await openPriceCacheDb();

  if (!db) {
    const legacy = getCachedDayPrice(modelName, year);
    return legacy ? { ...legacy, fromLocalCache: true } : null;
  }

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const getReq = store.get(cacheKey);

      getReq.onsuccess = () => {
        const record = getReq.result as PriceCacheRecord | undefined;
        if (!record || !record.cachedAt) {
          db.close();
          resolve(null);
          return;
        }

        const ageMs = Date.now() - record.cachedAt;
        if (ageMs >= ttlMs) {
          try {
            store.delete(cacheKey);
          } catch {
            // ignore cleanup error
          }
          db.close();
          resolve(null);
          return;
        }

        db.close();
        resolve({
          ...record.data,
          cachedAt: record.cachedAt,
          fromLocalCache: true,
        });
      };

      getReq.onerror = () => {
        db.close();
        const legacy = getCachedDayPrice(modelName, year);
        resolve(legacy ? { ...legacy, fromLocalCache: true } : null);
      };
    } catch {
      try {
        db.close();
      } catch {
        // ignore
      }
      const legacy = getCachedDayPrice(modelName, year);
      resolve(legacy ? { ...legacy, fromLocalCache: true } : null);
    }
  });
}

/**
 * Persist fetched market price into IndexedDB (with 6-hour TTL metadata),
 * record daily snapshot history, and mirror to localStorage fallback.
 */
export async function setCachedDayPriceAsync(
  modelName: string,
  year: number,
  info: DayPriceInfo
): Promise<void> {
  const now = Date.now();
  const payload: DayPriceInfo = {
    ...info,
    cachedAt: now,
    fromLocalCache: false,
  };

  setCachedDayPrice(modelName, year, payload);

  // Persist real observation into the snapshot timeline store
  const primarySource =
    info.sources && info.sources.length > 0 ? info.sources[0] : 'استعلام قیمت بازار';
  await recordPriceSnapshotAsync(modelName, year, info.avg, {
    min: info.min,
    max: info.max,
    source: primarySource,
  });

  const db = await openPriceCacheDb();
  if (!db) return;

  const cacheKey = buildPriceCacheKey(modelName, year);
  const record: PriceCacheRecord = {
    cacheKey,
    modelName,
    year,
    data: payload,
    cachedAt: now,
  };

  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.put(record);
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        resolve();
      };
    } catch {
      try {
        db.close();
      } catch {
        // ignore
      }
      resolve();
    }
  });
}
