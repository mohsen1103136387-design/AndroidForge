import { AppraisalRecord } from '../types';
import { gregorianToJalali, toPersianDigits } from './persian';
import { PriceSnapshotEntry, buildPriceCacheKey, getTodayDateIso } from './priceCacheDb';

export type TrendSourceMode = 'grounded_history' | 'recorded_snapshots' | 'single_point';

export interface PricePoint {
  dateIso: string; // YYYY-MM-DD
  dayIndex: number; // chronological days ago (0 = today)
  dateLabel: string; // e.g. "۱۲ مهر" or "امروز"
  fullDate: string; // e.g. "۱۲ مهر ۱۴۰۵"
  price: number;
  sourceLabel: string;
  isVerifiedWeb?: boolean;
}

export interface ServerTrendPoint {
  dateIso: string;
  price: number;
  sourceLabel?: string;
}

export interface TrendAnalysis {
  points: PricePoint[];
  mode: TrendSourceMode;
  hasHistoricalSeries: boolean;
  startPrice: number;
  currentPrice: number;
  minPrice: number;
  maxPrice: number;
  changeAmount: number;
  changePercent: number;
  isGrowth: boolean;
  sources: string[];
  disclaimer: string;
}

const PERSIAN_MONTHS = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];

export function formatIsoToJalaliLabels(dateIso: string): {
  dateLabel: string;
  fullDate: string;
  daysAgo: number;
} {
  const parts = dateIso.split('-').map(Number);
  const todayIso = getTodayDateIso();
  const [gy, gm, gd] =
    parts.length === 3 && parts.every((n) => Number.isFinite(n))
      ? parts
      : todayIso.split('-').map(Number);

  const [jy, jm, jd] = gregorianToJalali(gy, gm, gd);
  const monthName = PERSIAN_MONTHS[Math.max(0, Math.min(11, jm - 1))];
  const shortLabel = `${toPersianDigits(jd)} ${monthName}`;
  const fullDate = `${shortLabel} ${toPersianDigits(jy)}`;

  const todayMs = Date.parse(`${todayIso}T00:00:00Z`);
  const pointMs = Date.parse(`${dateIso}T00:00:00Z`);
  const daysAgo = Number.isFinite(pointMs)
    ? Math.max(0, Math.round((todayMs - pointMs) / (24 * 60 * 60 * 1000)))
    : 0;

  return {
    dateLabel: dateIso === todayIso ? 'امروز' : shortLabel,
    fullDate,
    daysAgo,
  };
}

/**
 * Assemble an honest, verifiable price trend strictly from real observations:
 * 1) Web-grounded market history points returned by backend (/api/car-price-trend)
 * 2) Local IndexedDB daily market snapshots collected across real queries
 * 3) Saved user appraisals matching the same model & year
 * 4) Today's active appraised basePrice
 * Never generates synthetic sine-wave or random fluctuations.
 */
export function buildRealTrendAnalysis(params: {
  basePrice: number;
  carModel: string;
  year?: number;
  recordedSnapshots?: PriceSnapshotEntry[];
  appraisalRecords?: AppraisalRecord[];
  serverPoints?: ServerTrendPoint[];
  serverSources?: string[];
}): TrendAnalysis {
  const {
    basePrice,
    carModel,
    year,
    recordedSnapshots = [],
    appraisalRecords = [],
    serverPoints = [],
    serverSources = [],
  } = params;

  const todayIso = getTodayDateIso();
  const normalizedTargetPrefix = year
    ? buildPriceCacheKey(carModel, year)
    : buildPriceCacheKey(carModel, 0).split('__')[0];

  const byDate = new Map<
    string,
    {
      price: number;
      sourceLabel: string;
      isVerifiedWeb: boolean;
      priority: number;
    }
  >();

  const cutoffMs = Date.now() - 35 * 24 * 60 * 60 * 1000;
  const collectedSources = new Set<string>(serverSources);

  // Priority 1: Saved appraisals from user's history for same car model (and year if specified)
  for (const rec of appraisalRecords) {
    if (!rec.savedAt || !rec.basePrice || rec.basePrice <= 0) continue;
    const recKey = year
      ? buildPriceCacheKey(rec.carModel, rec.year)
      : buildPriceCacheKey(rec.carModel, 0).split('__')[0];
    if (recKey !== normalizedTargetPrefix) continue;

    const recDate = rec.savedAt.slice(0, 10);
    const ms = Date.parse(rec.savedAt);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(recDate) || (Number.isFinite(ms) && ms < cutoffMs)) continue;

    byDate.set(recDate, {
      price: Math.round(rec.basePrice),
      sourceLabel: 'سابقه کارشناسی ثبت‌شده کاربر',
      isVerifiedWeb: Boolean(rec.dayPriceInfo?.sources?.length),
      priority: 1,
    });
  }

  // Priority 2: Real IndexedDB recorded market snapshots
  for (const snap of recordedSnapshots) {
    if (!snap.dateIso || !snap.price || snap.price <= 0) continue;
    const ms = Date.parse(`${snap.dateIso}T00:00:00Z`);
    if (Number.isFinite(ms) && ms < cutoffMs) continue;

    const existing = byDate.get(snap.dateIso);
    if (!existing || existing.priority <= 2) {
      byDate.set(snap.dateIso, {
        price: Math.round(snap.price),
        sourceLabel: snap.source || 'ثبت استعلام روز بازار در دستگاه',
        isVerifiedWeb: true,
        priority: 2,
      });
      if (snap.source) collectedSources.add(snap.source);
    }
  }

  // Priority 3: Server-verified / Search-grounded historical checkpoints
  for (const sp of serverPoints) {
    if (!sp.dateIso || !sp.price || sp.price <= 0) continue;
    const ms = Date.parse(`${sp.dateIso}T00:00:00Z`);
    if (Number.isFinite(ms) && ms < cutoffMs) continue;

    const existing = byDate.get(sp.dateIso);
    if (!existing || existing.priority <= 3) {
      const label = sp.sourceLabel || 'گزارش مستند بازار خودرو';
      byDate.set(sp.dateIso, {
        price: Math.round(sp.price),
        sourceLabel: label,
        isVerifiedWeb: true,
        priority: 3,
      });
      collectedSources.add(label);
    }
  }

  // Priority 4: Anchor today with active evaluated basePrice
  if (basePrice > 0) {
    const existingToday = byDate.get(todayIso);
    byDate.set(todayIso, {
      price: Math.round(basePrice),
      sourceLabel: existingToday?.sourceLabel || 'قیمت مبنای کارشناسی امروز',
      isVerifiedWeb: existingToday?.isVerifiedWeb ?? false,
      priority: 4,
    });
  }

  const sortedEntries = Array.from(byDate.entries()).sort(([d1], [d2]) => d1.localeCompare(d2));

  const points: PricePoint[] = sortedEntries.map(([dateIso, val]) => {
    const { dateLabel, fullDate, daysAgo } = formatIsoToJalaliLabels(dateIso);
    return {
      dateIso,
      dayIndex: daysAgo,
      dateLabel,
      fullDate,
      price: val.price,
      sourceLabel: val.sourceLabel,
      isVerifiedWeb: val.isVerifiedWeb,
    };
  });

  const prices = points.map((p) => p.price);
  const startPrice = prices[0] ?? basePrice;
  const currentPrice = prices[prices.length - 1] ?? basePrice;
  const minPrice = prices.length ? Math.min(...prices) : basePrice;
  const maxPrice = prices.length ? Math.max(...prices) : basePrice;
  const changeAmount = currentPrice - startPrice;
  const changePercent = startPrice > 0 ? Number(((changeAmount / startPrice) * 100).toFixed(1)) : 0;
  const isGrowth = changeAmount >= 0;

  const hasWebHistory = serverPoints.length >= 1 && points.length >= 2;
  const hasHistoricalSeries = points.length >= 2;
  const mode: TrendSourceMode = hasWebHistory
    ? 'grounded_history'
    : hasHistoricalSeries
    ? 'recorded_snapshots'
    : 'single_point';

  let disclaimer = '';
  if (mode === 'grounded_history') {
    disclaimer =
      'نمودار بر اساس داده‌های واقعی ثبت‌شده و گزارش‌های تاریخ‌دار بازار خودرو ترسیم شده است (بدون داده‌سازی تصادفی).';
  } else if (mode === 'recorded_snapshots') {
    disclaimer =
      'نمودار بر اساس نقاط واقعی استعلام‌شده و سوابق کارشناسی ذخیره‌شده شما در روزهای مختلف ترسیم شده است.';
  } else {
    disclaimer =
      'در حال حاضر فقط قیمت مبنای امروز ثبت شده است؛ اتو اسکوپ از ساخت منحنی تصادفی و جعلی خودداری می‌کند و با ثبت استعلام در روزهای مختلف، نمودار واقعی شکل می‌گیرد.';
  }

  return {
    points,
    mode,
    hasHistoricalSeries,
    startPrice,
    currentPrice,
    minPrice,
    maxPrice,
    changeAmount,
    changePercent,
    isGrowth,
    sources: Array.from(collectedSources).filter(Boolean),
    disclaimer,
  };
}
