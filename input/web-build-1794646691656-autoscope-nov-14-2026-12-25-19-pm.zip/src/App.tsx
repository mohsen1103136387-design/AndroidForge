/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './firebase';
import {
  ActivePage,
  AppraisalRecord,
  OnboardingSlideId,
  UsageOnboardingState,
} from './types';
import {
  loadHistory,
  saveToHistory,
  deleteHistoryItem,
  clearAllHistory,
  getSavedTheme,
  saveTheme,
  hasSeenOnboarding,
  markOnboardingSeen,
  loadUsageOnboardingState,
  recordVisitedPage,
  recordViewedOnboardingSlide,
  dismissSmartOnboardingSuggestion,
} from './utils/storage';
import {
  upsertUserProfile,
  updateUserTheme,
  saveAppraisalToCloud,
  syncLocalHistoryToCloud,
  subscribeUserAppraisals,
  deleteAppraisalFromCloud,
  clearUserAppraisalsFromCloud,
} from './utils/firestoreService';
import { getFormattedCurrentShamsiDate, generateTrackingCode, toPersianDigits } from './utils/persian';
import { APP_DEFAULTS, APP_TIMINGS, ONBOARDING_CONFIG, STORAGE_CONFIG } from './utils/config';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { HomeView } from './components/HomeView';
import { PricingForm } from './components/PricingForm';
import { ResultView } from './components/ResultView';
import { HistoryView } from './components/HistoryView';
import { PrintReportView } from './components/PrintReportView';
import { FaqGuideView } from './components/FaqGuideView';
import { AboutView } from './components/AboutView';
import { AccountView } from './components/AccountView';
import { OnboardingOverlay } from './components/OnboardingOverlay';
import { CheckCircle2, AlertCircle, Info, X, Sparkles, ArrowLeft } from 'lucide-react';

interface SmartOnboardingPlan {
  recommendedSlideIds: OnboardingSlideId[];
  suggestionReason: string;
  isPartialUsage: boolean;
}

function buildSmartOnboardingPlan(
  usage: UsageOnboardingState,
  records: AppraisalRecord[],
  isLoggedIn: boolean
): SmartOnboardingPlan {
  const seen = new Set(usage.seenSlideIds);
  const visited = new Set(usage.visitedPages);

  const hasVisitedPricing = visited.has('pricing') || records.length > 0;
  const hasUsedMarketPrice = records.some((r) => Boolean(r.dayPriceInfo));
  const hasUsed3DInspection = records.some(
    (r) =>
      Object.values(r.bodyParts).some((p) => p.damaged || p.painted) ||
      Object.values(r.chassisParts).some((sev) => sev !== 'none')
  );
  const hasUsedPrint = visited.has('print');
  const hasVisitedNonHomeSection = Array.from(visited).some((p) => p !== 'home');

  const isBrandNewUser =
    usage.seenSlideIds.length === 0 && !hasVisitedNonHomeSection && records.length === 0 && !isLoggedIn;

  if (isBrandNewUser) {
    return {
      recommendedSlideIds: [...ONBOARDING_CONFIG.ALL_SLIDE_IDS],
      suggestionReason: 'آشنایی سریع با امکانات اتو اسکوپ در ۴ مرحله',
      isPartialUsage: false,
    };
  }

  const recommended: OnboardingSlideId[] = [];

  // Only show the overview slide if user hasn't seen it AND hasn't explored core sections or appraisals
  if (!seen.has('welcome') && !hasVisitedNonHomeSection && records.length === 0) {
    recommended.push('welcome');
  }

  // Suggest live market price slide if unseen and user hasn't fetched day prices yet
  if (!seen.has('market-price') && !hasUsedMarketPrice) {
    recommended.push('market-price');
  }

  // Suggest 3D inspection slide if unseen and user hasn't marked body/chassis parts yet
  if (!seen.has('3d-inspection') && !hasUsed3DInspection) {
    recommended.push('3d-inspection');
  }

  // Suggest cloud sync & PDF slide if unseen and user hasn't used both Google login & Print
  if (!seen.has('cloud-pdf') && (!isLoggedIn || !hasUsedPrint)) {
    recommended.push('cloud-pdf');
  }

  let suggestionReason = 'بر اساس بخش‌هایی از برنامه که هنوز تجربه نکرده‌اید';
  if (records.length > 0 && recommended.includes('cloud-pdf') && !isLoggedIn) {
    suggestionReason =
      'شما قبلاً کارشناسی انجام داده‌اید؛ این راهنما برای ذخیره ابری و چاپ گواهی PDF پیشنهاد شده است';
  } else if (hasVisitedPricing && !hasUsed3DInspection && recommended.includes('3d-inspection')) {
    suggestionReason =
      'برای استفاده دقیق‌تر از مدل سه‌بعدی رنگ و شاسی در کارشناسی، این اسلایدها پیشنهاد می‌شود';
  } else if (!hasVisitedPricing && hasVisitedNonHomeSection) {
    suggestionReason =
      'شما تاکنون فقط بخش‌های عمومی را دیده‌اید؛ اسلایدهای زیر برای شروع کارشناسی و استعلام قیمت است';
  } else if (usage.seenSlideIds.length > 0 && recommended.length > 0) {
    suggestionReason = 'ادامه اسلایدهای راهنما که هنوز مشاهده نکرده‌اید';
  } else if (recommended.length === 0) {
    suggestionReason = 'شما پیش‌تر با تمام بخش‌های برنامه آشنا شده‌اید';
  }

  return {
    recommendedSlideIds: recommended,
    suggestionReason,
    isPartialUsage: recommended.length > 0 && recommended.length < ONBOARDING_CONFIG.ALL_SLIDE_IDS.length,
  };
}

export default function App() {
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<'dark' | 'light'>(APP_DEFAULTS.THEME);
  const [records, setRecords] = useState<AppraisalRecord[]>([]);
  const [activeRecord, setActiveRecord] = useState<AppraisalRecord | null>(null);
  const [presetCarModel, setPresetCarModel] = useState<string | undefined>(undefined);
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const [usageState, setUsageState] = useState<UsageOnboardingState>(() => loadUsageOnboardingState());
  const [smartSuggestDismissedInSession, setSmartSuggestDismissedInSession] = useState<boolean>(false);

  // Firebase Auth & Sync State
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const themeRef = useRef<'dark' | 'light'>(APP_DEFAULTS.THEME);

  const smartPlan = buildSmartOnboardingPlan(usageState, records, Boolean(user));

  // Toast notification state
  const [toast, setToast] = useState<{
    id: number;
    message: string;
    type: 'success' | 'error' | 'info';
  } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now();
    setToast({ id, message, type });
  };

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => {
      setToast(null);
    }, APP_TIMINGS.TOAST_DURATION_MS);
    return () => clearTimeout(timer);
  }, [toast]);

  const applyTheme = (nextTheme: 'dark' | 'light') => {
    setTheme(nextTheme);
    themeRef.current = nextTheme;
    saveTheme(nextTheme);
    if (nextTheme === 'light') {
      document.documentElement.classList.add('theme-light');
    } else {
      document.documentElement.classList.remove('theme-light');
    }
  };

  // Initial theme, local history, and splash setup
  useEffect(() => {
    const saved = getSavedTheme();
    applyTheme(saved);

    const loadedHistory = loadHistory();
    setRecords(loadedHistory);
    if (loadedHistory.length > 0) {
      setActiveRecord(loadedHistory[0]);
    }

    const loadedUsage = loadUsageOnboardingState();
    setUsageState(loadedUsage);

    const initialPlan = buildSmartOnboardingPlan(loadedUsage, loadedHistory, false);

    const splashTimer = setTimeout(() => {
      setShowSplash(false);
      // Auto-open onboarding for brand-new users OR users who never dismissed/finished it and still have unseen sections
      if (!hasSeenOnboarding() && initialPlan.recommendedSlideIds.length > 0) {
        setShowOnboarding(true);
      }
    }, APP_TIMINGS.SPLASH_DURATION_MS);

    return () => clearTimeout(splashTimer);
  }, []);

  // Track every visited section to refine smart onboarding recommendations
  useEffect(() => {
    const nextUsage = recordVisitedPage(activePage);
    setUsageState(nextUsage);
  }, [activePage]);

  // Firebase Auth listener & Firestore subscription
  useEffect(() => {
    let unsubscribeAppraisals: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (unsubscribeAppraisals) {
        unsubscribeAppraisals();
        unsubscribeAppraisals = null;
      }

      setUser(firebaseUser);
      setAuthReady(true);

      if (firebaseUser) {
        setIsSyncing(true);
        try {
          const profileRes = await upsertUserProfile(firebaseUser, themeRef.current);
          if (profileRes.theme && profileRes.theme !== themeRef.current) {
            applyTheme(profileRes.theme);
          }

          // Migrate any guest appraisals stored locally before login
          const guestRecords = loadHistory();
          if (guestRecords.length > 0) {
            const migratedCount = await syncLocalHistoryToCloud(firebaseUser.uid, guestRecords);
            clearAllHistory();
            if (migratedCount > 0) {
              showToast(
                `${migratedCount} کارشناسی قبلی شما با موفقیت به حساب گوگل منتقل شد.`,
                'success'
              );
            }
          }

          unsubscribeAppraisals = subscribeUserAppraisals(
            firebaseUser.uid,
            (cloudRecords) => {
              setRecords(cloudRecords);
              setActiveRecord((prev) => {
                if (prev && cloudRecords.some((r) => r.id === prev.id)) {
                  return prev;
                }
                return cloudRecords.length > 0 ? cloudRecords[0] : null;
              });
              setIsSyncing(false);
            },
            () => {
              setIsSyncing(false);
              showToast('خطا در همگام‌سازی سوابق ابری.', 'error');
            }
          );
        } catch (err) {
          console.error('Auth sync error:', err);
          setIsSyncing(false);
          showToast('خطا در بارگذاری اطلاعات حساب کاربری.', 'error');
        }
      } else {
        setIsSyncing(false);
        const localHistory = loadHistory();
        setRecords(localHistory);
        setActiveRecord(localHistory.length > 0 ? localHistory[0] : null);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeAppraisals) unsubscribeAppraisals();
    };
  }, []);

  // Theme toggle
  const handleToggleTheme = async () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    applyTheme(nextTheme);
    if (user) {
      try {
        await updateUserTheme(user.uid, nextTheme);
      } catch (err) {
        console.error('Failed to sync theme:', err);
      }
    }
  };

  // Start pricing with optional preset
  const handleStartPricing = (presetModel?: string) => {
    if (presetModel) {
      setPresetCarModel(presetModel);
    }
    setActivePage('pricing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // When calculation completes
  const handleAppraisalCalculated = async (data: any) => {
    const newRecord: AppraisalRecord = {
      id: `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      carModel: data.carModel,
      year: data.year,
      mileage: data.mileage,
      basePrice: data.basePrice,
      sellerPrice: data.sellerPrice,
      bodyParts: data.bodyParts,
      chassisParts: data.chassisParts,
      technical: data.technical,
      labels: data.labels,
      result: data.calculationResult,
      dayPriceInfo: data.dayPriceInfo,
      savedAt: new Date().toISOString(),
      shamsiDate: getFormattedCurrentShamsiDate(),
      trackingCode: generateTrackingCode(),
    };

    if (user) {
      setRecords((prev) =>
        [newRecord, ...prev.filter((r) => r.id !== newRecord.id)].slice(
          0,
          STORAGE_CONFIG.MAX_HISTORY_ITEMS
        )
      );
      setActiveRecord(newRecord);
      setActivePage('result');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      try {
        await saveAppraisalToCloud(user.uid, newRecord);
        showToast('کارشناسی محاسبه و در حساب کاربری شما ذخیره شد.', 'success');
      } catch (err) {
        console.error('Cloud save error:', err);
        saveToHistory(newRecord);
        showToast('کارشناسی محاسبه شد (ذخیره موقت در دستگاه به دلیل خطای شبکه).', 'info');
      }
    } else {
      const updated = saveToHistory(newRecord);
      setRecords(updated);
      setActiveRecord(newRecord);
      setActivePage('result');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      showToast('کارشناسی هوشمند خودرو با موفقیت محاسبه و ذخیره گردید.', 'success');
    }
  };

  // Delete single record
  const handleDeleteRecord = async (id: string) => {
    if (user) {
      try {
        await deleteAppraisalFromCloud(user.uid, id);
        showToast('مورد با موفقیت از حساب شما حذف شد.', 'info');
      } catch (err) {
        console.error('Cloud delete error:', err);
        showToast('خطا در حذف گزارش از فضای ابری.', 'error');
      }
    } else {
      const updated = deleteHistoryItem(id);
      setRecords(updated);
      showToast('مورد با موفقیت از تاریخچه حذف شد.', 'info');
    }
  };

  // Clear all records
  const handleClearAllRecords = async () => {
    if (user) {
      try {
        await clearUserAppraisalsFromCloud(
          user.uid,
          records.map((r) => r.id)
        );
        showToast('کلیه موارد تاریخچه از حساب کاربری شما حذف شدند.', 'info');
      } catch (err) {
        console.error('Cloud clear error:', err);
        showToast('خطا در پاکسازی سوابق ابری.', 'error');
      }
    } else {
      clearAllHistory();
      setRecords([]);
      showToast('کلیه موارد تاریخچه حذف شدند.', 'info');
    }
  };

  // Manual sync button handler in AccountView
  const handleManualSync = async () => {
    if (!user) return;
    setIsSyncing(true);
    try {
      await upsertUserProfile(user, themeRef.current);
      const guestRecords = loadHistory();
      if (guestRecords.length > 0) {
        await syncLocalHistoryToCloud(user.uid, guestRecords);
        clearAllHistory();
      }
      showToast('اطلاعات حساب کاربری با موفقیت همگام‌سازی شد.', 'success');
    } catch (err) {
      console.error('Manual sync error:', err);
      showToast('خطا در همگام‌سازی اطلاعات.', 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  // Select record from history
  const handleSelectRecord = (record: AppraisalRecord) => {
    setActiveRecord(record);
    setActivePage('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigatePage = (page: ActivePage) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (showSplash) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-slate-100 select-none">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-sky-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-3xl shadow-2xl shadow-sky-500/30 animate-bounce">
          AS
        </div>
        <h1 className="text-xl font-black mt-4 tracking-tight">
          اتو اسکوپ <span className="text-sky-400">| AutoScope</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">کارشناسی هوشمند قیمت خودرو بازار ایران</p>
        <div className="w-24 h-1 bg-slate-800 rounded-full mt-6 overflow-hidden">
          <div className="w-full h-full bg-gradient-to-l from-sky-400 to-indigo-500 animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100 selection:bg-sky-500 selection:text-white">
      {/* Top Header */}
      <Header
        activePage={activePage}
        onNavigate={handleNavigatePage}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        onOpenDrawer={() => setIsDrawerOpen(true)}
        user={user}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 pt-6 pb-20">
        {/* Contextual Smart Onboarding Suggestion for users who only used/saw partial sections */}
        {!showOnboarding &&
          !smartSuggestDismissedInSession &&
          activePage !== 'print' &&
          hasSeenOnboarding() &&
          smartPlan.isPartialUsage &&
          smartPlan.recommendedSlideIds.length > 0 &&
          (!usageState.dismissedSmartSuggestAt ||
            Date.now() - usageState.dismissedSmartSuggestAt > APP_TIMINGS.SMART_ONBOARDING_COOLDOWN_MS) && (
            <div className="mb-5 bg-slate-900/90 border border-sky-500/30 rounded-2xl p-3.5 sm:p-4 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in duration-300">
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-sky-500/15 text-sky-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="space-y-0.5">
                  <p className="text-xs font-bold text-slate-100">
                    پیشنهاد راهنمای هوشمند ({toPersianDigits(smartPlan.recommendedSlideIds.length)} اسلاید مرتبط)
                  </p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {smartPlan.suggestionReason}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowOnboarding(true)}
                  className="py-2 px-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold transition active:scale-95 flex items-center gap-1.5 whitespace-nowrap"
                >
                  <span>مشاهده راهنما</span>
                  <ArrowLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSmartSuggestDismissedInSession(true);
                    setUsageState(dismissSmartOnboardingSuggestion());
                  }}
                  aria-label="بستن پیشنهاد راهنما"
                  className="p-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

        {activePage === 'home' && (
          <HomeView
            onStartPricing={handleStartPricing}
            onGoToHistory={() => handleNavigatePage('history')}
            onGoToFaq={() => handleNavigatePage('faq')}
            lastRecord={records.length > 0 ? records[0] : null}
            onSelectRecord={handleSelectRecord}
          />
        )}

        {activePage === 'pricing' && (
          <PricingForm
            onCalculate={handleAppraisalCalculated}
            showToast={showToast}
            initialValues={presetCarModel ? { carModel: presetCarModel } : undefined}
          />
        )}

        {activePage === 'result' && (
          activeRecord ? (
            <ResultView
              record={activeRecord}
              records={records}
              onNewEvaluation={() => {
                setPresetCarModel(undefined);
                handleNavigatePage('pricing');
              }}
              onGoToPrint={() => handleNavigatePage('print')}
              showToast={showToast}
            />
          ) : (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 text-center max-w-md mx-auto my-8 space-y-4">
              <p className="text-sm font-bold text-slate-200">هنوز گزارشی برای نمایش انتخاب نشده است</p>
              <p className="text-xs text-slate-400">ابتدا یک کارشناسی جدید انجام دهید یا از تاریخچه انتخاب کنید.</p>
              <button
                type="button"
                onClick={() => handleNavigatePage('pricing')}
                className="py-2.5 px-5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold transition"
              >
                شروع کارشناسی جدید
              </button>
            </div>
          )
        )}

        {activePage === 'history' && (
          <HistoryView
            records={records}
            onSelectRecord={handleSelectRecord}
            onRefreshRecords={(updated) => setRecords(updated)}
            onDeleteRecord={handleDeleteRecord}
            onClearAll={handleClearAllRecords}
            isAuthenticated={Boolean(user)}
            onGoToAccount={() => handleNavigatePage('account')}
            onGoToPricing={() => handleNavigatePage('pricing')}
            showToast={showToast}
          />
        )}

        {activePage === 'account' && (
          <AccountView
            user={user}
            authReady={authReady}
            recordsCount={records.length}
            localGuestCount={user ? 0 : records.length}
            isSyncing={isSyncing}
            theme={theme}
            onToggleTheme={handleToggleTheme}
            onGoToHistory={() => handleNavigatePage('history')}
            onGoToPricing={() => handleNavigatePage('pricing')}
            onManualSync={handleManualSync}
            showToast={showToast}
          />
        )}

        {activePage === 'print' && (
          activeRecord ? (
            <PrintReportView
              record={activeRecord}
              onBack={() => handleNavigatePage('result')}
            />
          ) : (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 text-center max-w-md mx-auto my-8 space-y-4">
              <p className="text-sm font-bold text-slate-200">گزارشی برای چاپ موجود نیست</p>
              <p className="text-xs text-slate-400">برای تهیه نسخه چاپی یا PDF، ابتدا یک کارشناسی خودرو انجام دهید.</p>
              <button
                type="button"
                onClick={() => handleNavigatePage('pricing')}
                className="py-2.5 px-5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold transition"
              >
                شروع کارشناسی خودرو
              </button>
            </div>
          )
        )}

        {activePage === 'faq' && <FaqGuideView />}

        {activePage === 'about' && <AboutView />}
      </main>

      {/* Bottom Sticky Navigation */}
      <Navigation
        activePage={activePage}
        onNavigate={handleNavigatePage}
        isDrawerOpen={isDrawerOpen}
        onCloseDrawer={() => setIsDrawerOpen(false)}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        historyCount={records.length}
        user={user}
        onOpenOnboarding={() => setShowOnboarding(true)}
      />

      {/* First-Visit & Smart Usage-Based Onboarding Tour */}
      <OnboardingOverlay
        isOpen={showOnboarding}
        recommendedSlideIds={
          smartPlan.recommendedSlideIds.length > 0
            ? smartPlan.recommendedSlideIds
            : undefined
        }
        suggestionReason={smartPlan.suggestionReason}
        onSlideViewed={(slideId) => {
          const updated = recordViewedOnboardingSlide(slideId);
          setUsageState(updated);
        }}
        onComplete={(destination) => {
          markOnboardingSeen();
          setShowOnboarding(false);
          if (destination && destination !== activePage) {
            handleNavigatePage(destination);
          }
        }}
      />

      {/* Toast Notification Container */}
      {toast && (
        <div className="fixed top-20 right-4 left-4 sm:right-6 sm:left-auto sm:max-w-md z-50 animate-in fade-in slide-in-from-top-4 duration-300">
          <div
            className={`p-3.5 rounded-2xl shadow-2xl border backdrop-blur-md flex items-center justify-between gap-3 text-xs font-semibold ${
              toast.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200'
                : toast.type === 'error'
                ? 'bg-rose-950/90 border-rose-500/40 text-rose-200'
                : 'bg-slate-900/90 border-sky-500/40 text-slate-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
              {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
              {toast.type === 'info' && <Info className="w-4 h-4 text-sky-400 shrink-0" />}
              <span>{toast.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="p-1 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
