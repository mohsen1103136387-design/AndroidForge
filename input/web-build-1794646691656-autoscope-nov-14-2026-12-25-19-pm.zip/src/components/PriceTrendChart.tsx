import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { AppraisalRecord, DayPriceInfo } from '../types';
import {
  buildRealTrendAnalysis,
  PricePoint,
  ServerTrendPoint,
} from '../utils/priceTrend';
import {
  getPriceSnapshotsAsync,
  recordPriceSnapshotAsync,
  PriceSnapshotEntry,
} from '../utils/priceCacheDb';
import {
  toPersianDigits,
  formatPersianNumber,
  formatToman,
} from '../utils/persian';
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  Database,
  Globe,
  Info,
} from 'lucide-react';

interface PriceTrendChartProps {
  basePrice: number;
  carModel: string;
  year?: number;
  dayPriceInfo?: DayPriceInfo | null;
  records?: AppraisalRecord[];
}

export const PriceTrendChart: React.FC<PriceTrendChartProps> = ({
  basePrice,
  carModel,
  year,
  dayPriceInfo,
  records = [],
}) => {
  const [rangeDays, setRangeDays] = useState<30 | 15 | 7>(30);
  const [recordedSnapshots, setRecordedSnapshots] = useState<PriceSnapshotEntry[]>([]);
  const [serverPoints, setServerPoints] = useState<ServerTrendPoint[]>([]);
  const [serverSources, setServerSources] = useState<string[]>([]);
  const [isLoadingTrend, setIsLoadingTrend] = useState<boolean>(false);

  const [isLightTheme, setIsLightTheme] = useState<boolean>(() =>
    typeof document !== 'undefined' ? document.documentElement.classList.contains('theme-light') : false
  );

  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    const syncTheme = () => setIsLightTheme(root.classList.contains('theme-light'));
    syncTheme();
    const observer = new MutationObserver(syncTheme);
    observer.observe(root, { attributes: true, attributeFilter: ['class'] });
    return () => observer.disconnect();
  }, []);

  const targetYear = year || dayPriceInfo?.effectiveYear || 1400;

  const loadRealTrendData = useCallback(
    async (forceRefresh = false, signal?: AbortSignal) => {
      if (!carModel.trim() || basePrice <= 0) return;

      // Ensure today's evaluated basePrice is recorded in IndexedDB snapshot history
      await recordPriceSnapshotAsync(carModel, targetYear, basePrice, {
        min: dayPriceInfo?.min,
        max: dayPriceInfo?.max,
        source: dayPriceInfo?.sources?.[0] || 'مبنای کارشناسی ثبت‌شده',
      });

      const localSnaps = await getPriceSnapshotsAsync(carModel, targetYear);
      if (signal?.aborted) return;
      setRecordedSnapshots(localSnaps);

      setIsLoadingTrend(true);
      try {
        const res = await fetch('/api/car-price-trend', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal,
          body: JSON.stringify({
            modelName: carModel,
            year: targetYear,
            basePrice,
            forceRefresh,
          }),
        });
        if (!res.ok) return;
        const data = await res.json();
        if (signal?.aborted) return;

        if (data?.success && Array.isArray(data.points)) {
          setServerPoints(data.points);
          setServerSources(Array.isArray(data.sources) ? data.sources : []);
        }
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          // Non-fatal: local snapshots + today's point still render accurately
        }
      } finally {
        if (!signal?.aborted) {
          setIsLoadingTrend(false);
        }
      }
    },
    [carModel, targetYear, basePrice, dayPriceInfo]
  );

  useEffect(() => {
    const controller = new AbortController();
    loadRealTrendData(false, controller.signal);
    return () => controller.abort();
  }, [loadRealTrendData]);

  const trendAnalysis = useMemo(() => {
    return buildRealTrendAnalysis({
      basePrice,
      carModel,
      year: targetYear,
      recordedSnapshots,
      appraisalRecords: records,
      serverPoints,
      serverSources,
    });
  }, [basePrice, carModel, targetYear, recordedSnapshots, records, serverPoints, serverSources]);

  // Filter real points by calendar day window (or keep full series if fewer than 2 points in narrower range)
  const chartData = useMemo(() => {
    const filtered = trendAnalysis.points.filter((p) => p.dayIndex <= rangeDays);
    if (filtered.length >= 2) return filtered;
    return trendAnalysis.points;
  }, [trendAnalysis.points, rangeDays]);

  const rangeStats = useMemo(() => {
    const prices = chartData.map((d) => d.price);
    const start = prices[0] ?? basePrice;
    const end = prices[prices.length - 1] ?? basePrice;
    const min = prices.length ? Math.min(...prices) : basePrice;
    const max = prices.length ? Math.max(...prices) : basePrice;
    const diff = end - start;
    const percent = start > 0 ? Number(((diff / start) * 100).toFixed(1)) : 0;
    const isUp = diff >= 0;
    return { start, end, min, max, diff, percent, isUp };
  }, [chartData, basePrice]);

  const formatYAxisTick = (val: number) => {
    if (val >= 1000000000) {
      const billions = (val / 1000000000).toFixed(2).replace(/\.00$/, '');
      return `${toPersianDigits(billions)} م.ت`;
    }
    const millions = Math.round(val / 1000000);
    return `${toPersianDigits(millions)} م`;
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data: PricePoint = payload[0].payload;
      const diffFromStart = data.price - rangeStats.start;
      const diffPercent =
        rangeStats.start > 0 ? ((diffFromStart / rangeStats.start) * 100).toFixed(1) : '0';

      return (
        <div className="bg-slate-900/95 border border-slate-700/80 p-3 rounded-2xl shadow-2xl backdrop-blur-md text-right text-xs space-y-1.5 min-w-[205px]">
          <div className="flex items-center justify-between text-slate-400 pb-1 border-b border-slate-800 text-[11px]">
            <span className="flex items-center gap-1 font-medium">
              <Calendar className="w-3 h-3 text-sky-400" />
              <span>{data.fullDate}</span>
            </span>
            {data.dayIndex === 0 && (
              <span className="bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded text-[10px] font-bold">
                امروز
              </span>
            )}
          </div>

          <div>
            <span className="text-[10px] text-slate-400 block">قیمت ثبت‌شده بازار:</span>
            <span className="font-extrabold text-sm text-sky-300 font-mono">
              {formatPersianNumber(data.price)}{' '}
              <span className="text-[10px] text-slate-400 font-normal">تومان</span>
            </span>
          </div>

          <div className="text-[10px] text-slate-400 pt-0.5">
            منبع: <span className="text-slate-200">{data.sourceLabel}</span>
          </div>

          {chartData.length > 1 && data.dateIso !== chartData[0].dateIso && (
            <div className="text-[10px] pt-1 border-t border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">تغییر نسبت به اولین نقطه:</span>
              <span
                className={`font-semibold flex items-center gap-0.5 ${
                  diffFromStart >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {diffFromStart >= 0 ? '+' : ''}
                {toPersianDigits(diffPercent)}٪
              </span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  const todayPoint = trendAnalysis.points[trendAnalysis.points.length - 1];

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm space-y-4">
      {/* Chart Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <Activity className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm md:text-base font-bold text-slate-100">
              روند واقعی قیمت ۳۰ روز اخیر در بازار
            </h3>
            {trendAnalysis.mode === 'grounded_history' && (
              <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                <Globe className="w-3 h-3" />
                <span>مستند از وب و سوابق ({toPersianDigits(trendAnalysis.points.length)} نقطه)</span>
              </span>
            )}
            {trendAnalysis.mode === 'recorded_snapshots' && (
              <span className="inline-flex items-center gap-1 text-[10px] bg-sky-500/15 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded-full font-semibold">
                <Database className="w-3 h-3" />
                <span>سوابق ثبت‌شده دستگاه ({toPersianDigits(trendAnalysis.points.length)} روز)</span>
              </span>
            )}
            {trendAnalysis.mode === 'single_point' && (
              <span className="inline-flex items-center gap-1 text-[10px] bg-amber-500/15 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-semibold">
                <Info className="w-3 h-3" />
                <span>نقطه مبنای امروز (بدون داده‌سازی)</span>
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            پایش واقعی تغییرات ارزش {carModel} {year ? `مدل ${toPersianDigits(year)}` : ''}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {trendAnalysis.hasHistoricalSeries && (
            <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
              {[
                { days: 30, label: '۳۰ روز' },
                { days: 15, label: '۱۵ روز' },
                { days: 7, label: '۷ روز' },
              ].map((tab) => (
                <button
                  key={tab.days}
                  type="button"
                  onClick={() => setRangeDays(tab.days as 30 | 15 | 7)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                    rangeDays === tab.days
                      ? 'bg-sky-500 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={() => loadRealTrendData(true)}
            disabled={isLoadingTrend}
            title="استعلام مجدد سابقه واقعی قیمت در بازار"
            className="p-2 rounded-xl bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-sky-300 disabled:opacity-50 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingTrend ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {isLoadingTrend && !trendAnalysis.hasHistoricalSeries ? (
        <div className="py-10 text-center space-y-2 bg-slate-950/50 rounded-2xl border border-slate-800/80">
          <div className="inline-block w-6 h-6 border-2 border-sky-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-slate-300 font-medium">
            در حال بررسی سوابق ثبت‌شده و استعلام داده‌های تاریخی واقعی بازار...
          </p>
        </div>
      ) : trendAnalysis.hasHistoricalSeries ? (
        <>
          {/* Range Key Performance Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 block mb-0.5">
                  تغییر واقعی بازه ({toPersianDigits(chartData.length)} نقطه)
                </span>
                <div
                  className={`font-black text-xs md:text-sm flex items-center gap-1 ${
                    rangeStats.isUp ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {rangeStats.isUp ? (
                    <ArrowUpRight className="w-4 h-4 shrink-0" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 shrink-0" />
                  )}
                  <span>
                    {rangeStats.isUp ? '+' : ''}
                    {toPersianDigits(rangeStats.percent)}٪{' '}
                    {rangeStats.diff === 0 ? '(ثابت)' : rangeStats.isUp ? '(رشد)' : '(افت)'}
                  </span>
                </div>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">
                {formatPersianNumber(Math.abs(rangeStats.diff))} ت
              </span>
            </div>

            <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400">بالاترین قیمت ثبت‌شده</span>
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400/80" />
              </div>
              <span className="font-bold text-xs md:text-sm text-slate-200 mt-0.5 block font-mono">
                {formatPersianNumber(rangeStats.max)} تومان
              </span>
            </div>

            <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80 col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400">پایین‌ترین قیمت ثبت‌شده</span>
                <TrendingDown className="w-3.5 h-3.5 text-rose-400/80" />
              </div>
              <span className="font-bold text-xs md:text-sm text-slate-200 mt-0.5 block font-mono">
                {formatPersianNumber(rangeStats.min)} تومان
              </span>
            </div>
          </div>

          {/* Recharts Area Chart using Real Checkpoints */}
          <div className="w-full h-[240px] md:h-[270px] pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="priceTrendGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop
                      offset="5%"
                      stopColor={rangeStats.isUp ? '#0ea5e9' : '#f43f5e'}
                      stopOpacity={0.45}
                    />
                    <stop
                      offset="95%"
                      stopColor={rangeStats.isUp ? '#0ea5e9' : '#f43f5e'}
                      stopOpacity={0.0}
                    />
                  </linearGradient>
                </defs>

                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke={isLightTheme ? '#e2e8f0' : '#1e293b'}
                  vertical={false}
                />

                <XAxis
                  dataKey="dateLabel"
                  tickLine={false}
                  axisLine={{ stroke: isLightTheme ? '#cbd5e1' : '#334155' }}
                  tick={{ fill: isLightTheme ? '#475569' : '#94a3b8', fontSize: 10, fontFamily: 'Vazirmatn' }}
                  interval="preserveStartEnd"
                  minTickGap={22}
                />

                <YAxis
                  domain={['dataMin - 20000000', 'dataMax + 20000000']}
                  tickFormatter={formatYAxisTick}
                  tickLine={false}
                  axisLine={{ stroke: isLightTheme ? '#cbd5e1' : '#334155' }}
                  tick={{ fill: isLightTheme ? '#475569' : '#94a3b8', fontSize: 10, fontFamily: 'Vazirmatn' }}
                  width={65}
                />

                <Tooltip content={<CustomTooltip />} />

                <Area
                  type="monotone"
                  dataKey="price"
                  stroke={rangeStats.isUp ? '#38bdf8' : '#fb7185'}
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#priceTrendGradient)"
                  dot={{
                    r: 3.5,
                    strokeWidth: 1.5,
                    stroke: isLightTheme ? '#ffffff' : '#0f172a',
                    fill: rangeStats.isUp ? '#0ea5e9' : '#f43f5e',
                  }}
                  activeDot={{
                    r: 5.5,
                    stroke: '#ffffff',
                    strokeWidth: 2,
                    fill: rangeStats.isUp ? '#0284c7' : '#e11d48',
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </>
      ) : (
        /* Honest Baseline Card when < 2 real historical dates are available (never fabricates fake curves) */
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4 md:p-5 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
              <span className="text-[10px] text-slate-400 block mb-1">
                نقطه مبنای ثبت‌شده ({todayPoint?.fullDate || 'امروز'})
              </span>
              <span className="font-extrabold text-sm text-sky-300 font-mono">
                {formatToman(basePrice)}
              </span>
            </div>

            {dayPriceInfo && dayPriceInfo.min > 0 && dayPriceInfo.max > dayPriceInfo.min ? (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3">
                <span className="text-[10px] text-slate-400 block mb-1">
                  بازه واقعی معاملات امروز در بازار
                </span>
                <span className="font-bold text-xs text-slate-200 font-mono">
                  {formatToman(dayPriceInfo.min)} تا {formatToman(dayPriceInfo.max)}
                </span>
              </div>
            ) : (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 flex items-center gap-2 text-[11px] text-slate-300">
                <Database className="w-4 h-4 text-sky-400 shrink-0" />
                <span>نقطه امروز با موفقیت در حافظه دستگاه ثبت شد.</span>
              </div>
            )}
          </div>

          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs leading-relaxed flex items-start gap-2">
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>{trendAnalysis.disclaimer}</span>
          </div>
        </div>
      )}

      {/* Honest Provenance Footer */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] text-slate-400 pt-2 border-t border-slate-800/80">
        <span>
          {trendAnalysis.sources.length > 0
            ? `منابع داده‌های ثبت‌شده: ${trendAnalysis.sources.slice(0, 3).join(' • ')}`
            : trendAnalysis.disclaimer}
        </span>
        <span className="shrink-0">واحد مبالغ: تومان</span>
      </div>
    </div>
  );
};
