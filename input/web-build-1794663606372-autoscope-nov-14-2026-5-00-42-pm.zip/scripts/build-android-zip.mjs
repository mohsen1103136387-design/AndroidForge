import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const androidDir = path.join(rootDir, 'android');
const wwwAssetsDir = path.join(androidDir, 'app', 'src', 'main', 'assets', 'www');
const outZipPath = path.join(rootDir, 'public', 'AutoScope-AndroidForge.zip');

console.log('[AutoScope] 1/3 Building web bundle for Android assets/www ...');
fs.rmSync(outZipPath, { force: true });
fs.mkdirSync(wwwAssetsDir, { recursive: true });
execSync(
  `npx vite build --base=./ --outDir "${wwwAssetsDir}" --emptyOutDir`,
  { cwd: rootDir, stdio: 'inherit' }
);

// Ensure gradlew has executable bit
const gradlewPath = path.join(androidDir, 'gradlew');
if (fs.existsSync(gradlewPath)) {
  fs.chmodSync(gradlewPath, 0o755);
}

console.log('[AutoScope] 2/3 Generating fallback PNG launcher icons (API 24+) ...');
const pyScript = `
import os, struct, zlib, zipfile

def make_png(size, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Crisp AutoScope Slate/Sky icon PNG
    rows = []
    cx = cy = size / 2.0
    r_outer = size * 0.44
    r_inner = size * 0.30
    for y in range(size):
        row = bytearray([0])
        for x in range(size):
            dx = x - cx
            dy = y - cy
            d = (dx*dx + dy*dy) ** 0.5
            # Background slate #0F172A, sky ring #38BDF8, car roof accent #E0F2FE
            if abs(d - r_outer * 0.72) <= max(1.5, size * 0.055):
                row.extend((56, 189, 248, 255))
            elif d <= r_inner * 0.85 and abs(dy) <= size * 0.14 and abs(dx) <= size * 0.22:
                row.extend((224, 242, 254, 255))
            elif d <= r_outer:
                row.extend((15, 23, 42, 255))
            else:
                row.extend((2, 6, 23, 255))
        rows.append(bytes(row))
    raw = b"".join(rows)
    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xffffffff)
    ihdr = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
    png = b"\\x89PNG\\r\\n\\x1a\\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)

res_dir = os.path.join(${JSON.stringify(androidDir)}, "app", "src", "main", "res")
for density, px in [("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)]:
    make_png(px, os.path.join(res_dir, f"mipmap-{density}", "ic_launcher.png"))
    make_png(px, os.path.join(res_dir, f"mipmap-{density}", "ic_launcher_round.png"))

print("[AutoScope] 3/3 Packing AutoScope-AndroidForge.zip ...")
out_zip = ${JSON.stringify(outZipPath)}
android_root = ${JSON.stringify(androidDir)}
os.makedirs(os.path.dirname(out_zip), exist_ok=True)
skip_dirs = {"build", ".gradle", ".idea", "__pycache__"}

with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
    for dirpath, dirnames, filenames in os.walk(android_root):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        for fname in filenames:
            full_path = os.path.join(dirpath, fname)
            rel = os.path.relpath(full_path, android_root)
            arcname = os.path.join("AutoScope-Android", rel).replace("\\\\", "/")
            zinfo = zipfile.ZipInfo(arcname)
            if fname == "gradlew":
                zinfo.external_attr = (0o100755 << 16)
            else:
                zinfo.external_attr = (0o100644 << 16)
            with open(full_path, "rb") as src:
                zf.writestr(zinfo, src.read(), compress_type=zipfile.ZIP_DEFLATED)

size_kb = os.path.getsize(out_zip) / 1024.0
print(f"[AutoScope] Created {out_zip} ({size_kb:.1f} KB)")
`;

execSync('python3 -', { input: pyScript, stdio: ['pipe', 'inherit', 'inherit'] });
