const DEFAULT_ANDROID_API_BASE = 'https://ais-pre-wc2eyrififgn6puwif2twv-45171698555.us-west2.run.app';
const CUSTOM_API_BASE_KEY = 'autoscope_custom_api_base_v1';

export interface AndroidNativeBridge {
  printReport?: (title: string) => void;
  shareText?: (text: string, title?: string) => void;
  exportCsv?: (csvContent: string, filename: string) => void;
  openExternalUrl?: (url: string) => void;
  getApiBaseUrl?: () => string;
}

declare global {
  interface Window {
    __AUTOSCOPE_API_BASE__?: string;
    AndroidBridge?: AndroidNativeBridge;
  }
}

export function isAndroidBridgeAvailable(): boolean {
  return typeof window !== 'undefined' && Boolean(window.AndroidBridge);
}

export function isPackagedAndroidOrigin(): boolean {
  if (typeof window === 'undefined') return false;
  const { protocol, hostname } = window.location;
  return protocol === 'file:' || hostname === 'appassets.androidplatform.net';
}

export function getApiBaseUrl(): string {
  if (typeof window === 'undefined') return '';

  // 1. Explicit runtime injection from Android native shell
  const bridgeUrl = window.AndroidBridge?.getApiBaseUrl?.() || window.__AUTOSCOPE_API_BASE__;
  if (bridgeUrl && /^https?:\/\//i.test(bridgeUrl.trim())) {
    return bridgeUrl.trim().replace(/\/+$/, '');
  }

  // 2. Optional persisted custom backend URL in localStorage
  try {
    const stored = localStorage.getItem(CUSTOM_API_BASE_KEY);
    if (stored && /^https?:\/\//i.test(stored.trim())) {
      return stored.trim().replace(/\/+$/, '');
    }
  } catch {
    // ignore storage access errors
  }

  // 3. Bundled APK offline assets origin routes live API calls to deployed AutoScope server
  if (isPackagedAndroidOrigin()) {
    return DEFAULT_ANDROID_API_BASE;
  }

  // 4. Standard web origin uses relative /api/* routes
  return '';
}

export function apiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const base = getApiBaseUrl();
  return base ? `${base}${normalizedPath}` : normalizedPath;
}
