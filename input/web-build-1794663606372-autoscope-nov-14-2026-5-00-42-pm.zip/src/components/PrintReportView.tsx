import React from 'react';
import { AppraisalRecord, BodyPartId, ChassisPartId } from '../types';
import {
  toPersianDigits,
  formatPersianNumber,
  formatToman,
} from '../utils/persian';
import { BODY_PARTS_INFO, CHASSIS_PARTS_INFO, CHASSIS_SEVERITY_LABELS } from '../utils/carData';
import { Printer, ArrowRight, ShieldCheck, Car, Calendar, FileText } from 'lucide-react';

interface PrintReportViewProps {
  record: AppraisalRecord;
  onBack: () => void;
}

export const PrintReportView: React.FC<PrintReportViewProps> = ({ record, onBack }) => {
  const { carModel, year, mileage, basePrice, sellerPrice, result, trackingCode, shamsiDate, dayPriceInfo } = record;

  const handlePrint = () => {
    if (window.AndroidBridge?.printReport) {
      window.AndroidBridge.printReport(`AutoScope-${trackingCode}`);
      return;
    }
    window.print();
  };

  // Damaged body parts
  const damagedBody = Object.entries(record.bodyParts).filter(
    ([_, s]) => s.damaged || s.painted
  );

  // Damaged chassis parts
  const damagedChassis = Object.entries(record.chassisParts).filter(
    ([_, s]) => s !== 'none'
  );

  return (
    <div className="max-w-4xl mx-auto pb-16">
      {/* Non-printed Controls bar */}
      <div className="print:hidden flex items-center justify-between mb-6 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-lg">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-white px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 transition"
        >
          <ArrowRight className="w-4 h-4" />
          <span>بازگشت به برنامه</span>
        </button>

        <button
          type="button"
          onClick={handlePrint}
          className="flex items-center gap-2 text-xs font-bold text-white px-5 py-2.5 rounded-xl bg-gradient-to-l from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 shadow-lg shadow-sky-500/25 active:scale-95 transition"
        >
          <Printer className="w-4 h-4" />
          <span>چاپ / ذخیره به عنوان PDF</span>
        </button>
      </div>

      {/* Printable Sheet (Standard A4 layout) */}
      <div className="bg-white text-slate-900 rounded-3xl p-8 md:p-12 shadow-2xl print:shadow-none print:p-0 print:rounded-none print:m-0 font-['Vazirmatn'] border border-slate-200 print:border-none">
        {/* Certificate Header */}
        <div className="flex items-center justify-between border-b-2 border-slate-900 pb-5 mb-6">
          <div className="flex items-center gap-3">
            <div className="dark-always w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-black text-xl">
              AS
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black text-slate-900">سامانه کارشناسی خودرو «اتو اسکوپ»</h1>
              <p className="text-xs text-slate-600 mt-0.5">گزارش رسمی و هوشمند ارزیابی سلامت بدنه، شاسی و قیمت روز بازار</p>
            </div>
          </div>

          <div className="text-left text-xs space-y-1">
            <div>
              <span className="text-slate-500">شماره گواهی: </span>
              <span className="font-mono font-bold text-slate-900">{trackingCode}</span>
            </div>
            <div>
              <span className="text-slate-500">تاریخ کارشناسی: </span>
              <span className="font-bold text-slate-900">{shamsiDate}</span>
            </div>
          </div>
        </div>

        {/* Vehicle Main Specifications Grid */}
        <div className="bg-slate-100 rounded-2xl p-4 mb-6 border border-slate-200">
          <h2 className="text-xs font-bold text-slate-700 mb-3 flex items-center gap-1.5">
            <Car className="w-4 h-4 text-sky-600" />
            <span>مشخصات فنی و استعلام بازار خودرو</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 block text-[11px] mb-1">مدل و تیپ خودرو</span>
              <span className="font-bold text-slate-900 text-sm">{carModel}</span>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 block text-[11px] mb-1">سال تولید شمسی</span>
              <span className="font-bold text-slate-900 text-sm">{toPersianDigits(year)}</span>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 block text-[11px] mb-1">کارکرد ثبت شده</span>
              <span className="font-bold text-slate-900 text-sm">{formatPersianNumber(mileage)} کیلومتر</span>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200">
              <span className="text-slate-500 block text-[11px] mb-1">ارزش پایه صفر/سالم روز</span>
              <span className="font-bold text-slate-900 text-sm">{formatToman(basePrice)}</span>
            </div>
          </div>

          {dayPriceInfo && (
            <div className="mt-3 text-[11px] text-slate-600 border-t border-slate-200 pt-2 space-y-1">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span>
                  {dayPriceInfo.isDiscontinued ? 'میانگین آگهی‌های بازار (توقف تولید):' : 'استعلام قیمت روز بازار:'}{' '}
                  {dayPriceInfo.date} (بازه: {formatPersianNumber(dayPriceInfo.min)} الی {formatPersianNumber(dayPriceInfo.max)} تومان)
                </span>
                {dayPriceInfo.sources && dayPriceInfo.sources.length > 0 && (
                  <span>منابع استعلام: {dayPriceInfo.sources.join('، ')}</span>
                )}
              </div>
              {dayPriceInfo.isDiscontinued && (
                <p className="text-[10px] text-amber-700 font-semibold">
                  توجه: به دلیل توقف تولید این خودرو، قیمت پایه صرفاً میانگین آگهی‌های دیوار و سایت‌های معتبر بوده و قیمت روز و دقیق کارخانه‌ای نیست.
                </p>
              )}
            </div>
          )}
        </div>

        {/* 3-Section Inspection Summary: Body, Chassis, Technical */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Body Parts Summary */}
          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50">
            <h3 className="text-xs font-bold text-slate-800 mb-2.5 pb-1.5 border-b border-slate-200 flex items-center justify-between">
              <span>کارشناسی بدنه و رنگ‌شدگی</span>
              <span className="text-[10px] text-slate-500">
                {damagedBody.length === 0 ? 'بدون رنگ و تعویض' : `${toPersianDigits(damagedBody.length)} قطعه`}
              </span>
            </h3>

            {damagedBody.length === 0 ? (
              <p className="text-xs text-emerald-700 font-semibold py-2">
                ✓ کلیه قطعات بدنه (سپرها، درب‌ها، گلگیرها، سقف و کاپوت) فاقد هرگونه رنگ‌شدگی یا ضربه هستند.
              </p>
            ) : (
              <ul className="space-y-1.5 text-xs text-slate-700">
                {damagedBody.map(([partId, state]) => {
                  const meta = BODY_PARTS_INFO[partId as BodyPartId];
                  return (
                    <li key={partId} className="flex items-center justify-between py-1 border-b border-slate-100 last:border-none">
                      <span className="font-semibold text-slate-900">{meta?.name}</span>
                      <span className="text-[11px]">
                        {state.damaged && <span className="text-rose-600 font-bold ml-1.5">ضربه خورده</span>}
                        {state.painted && <span className="text-amber-600 font-bold">رنگ شده</span>}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          {/* Chassis and Pillars Summary */}
          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50">
            <h3 className="text-xs font-bold text-slate-800 mb-2.5 pb-1.5 border-b border-slate-200 flex items-center justify-between">
              <span>کارشناسی شاسی، ستون‌ها و اتاق</span>
              <span className="text-[10px] text-slate-500">
                {damagedChassis.length === 0 ? 'سالم' : `${toPersianDigits(damagedChassis.length)} آسیب`}
              </span>
            </h3>

            {damagedChassis.length === 0 ? (
              <p className="text-xs text-emerald-700 font-semibold py-2">
                ✓ کلیه ستون‌های A/B/C، ریل‌های شاسی جلو و عقب، سینی‌ها و تیر سقف کاملاً سالم و بدون دست‌خوردگی هستند.
              </p>
            ) : (
              <ul className="space-y-1.5 text-xs text-slate-700">
                {damagedChassis.map(([partId, sev]) => {
                  const meta = CHASSIS_PARTS_INFO[partId as ChassisPartId];
                  return (
                    <li key={partId} className="flex items-center justify-between py-1 border-b border-slate-100 last:border-none">
                      <span className="font-semibold text-slate-900">{meta?.name}</span>
                      <span className="text-[11px] font-bold text-rose-600">
                        {CHASSIS_SEVERITY_LABELS[sev]}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>

        {/* Deductions Breakdown Table */}
        <div className="mb-6">
          <h3 className="text-xs font-bold text-slate-800 mb-2 flex items-center justify-between">
            <span>جدول تفکیکی محاسبات و کسورات کارشناسی</span>
            <span className="text-xs text-rose-600 font-bold">افت کل: {toPersianDigits(result.totalDeductionPercentage)}٪</span>
          </h3>

          <table className="w-full text-right text-xs border border-slate-200 rounded-xl overflow-hidden">
            <thead className="bg-slate-100 text-slate-700 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">ردیف</th>
                <th className="py-2.5 px-3">شرح عامل کسر قیمت</th>
                <th className="py-2.5 px-3 text-center">درصد افت</th>
                <th className="py-2.5 px-3 text-left">مبلغ کسرشده (تومان)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {result.rows.map((row, idx) => {
                const isBonus = row.amount < 0;
                const isInfoZero = row.amount === 0;
                return (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="py-2 px-3 text-slate-500">{toPersianDigits(idx + 1)}</td>
                    <td className="py-2 px-3">
                      <span className="font-semibold text-slate-900">{row.factor}</span>
                      {row.description && (
                        <span className="text-[10px] text-slate-500 block">{row.description}</span>
                      )}
                    </td>
                    <td
                      className={`py-2 px-3 text-center font-bold ${
                        isBonus ? 'text-emerald-700' : isInfoZero ? 'text-sky-700' : 'text-rose-600'
                      }`}
                    >
                      {isBonus
                        ? `+${toPersianDigits(Math.abs(row.percentage))}٪`
                        : isInfoZero
                        ? '۰٪ (لحاظ‌شده)'
                        : `${toPersianDigits(row.percentage)}٪`}
                    </td>
                    <td
                      className={`py-2 px-3 text-left font-mono font-semibold ${
                        isBonus ? 'text-emerald-700' : isInfoZero ? 'text-slate-500' : 'text-slate-800'
                      }`}
                    >
                      {isBonus
                        ? `+${formatPersianNumber(Math.abs(row.amount))}`
                        : formatPersianNumber(row.amount)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-100 font-bold border-t border-slate-300">
              <tr>
                <td colSpan={2} className="py-2.5 px-3 text-slate-900">مجموع کسورات کارشناسی</td>
                <td className="py-2.5 px-3 text-center text-rose-600 font-black">
                  {toPersianDigits(result.totalDeductionPercentage)}٪
                </td>
                <td className="py-2.5 px-3 text-left font-mono text-rose-600 font-black">
                  {formatPersianNumber(result.totalDeductions)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Final Appraisal Value & Purchase Judgment */}
        <div className="dark-always bg-slate-900 text-white rounded-2xl p-5 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-xs text-sky-300 block mb-1">قیمت منطقی و عادلانه کارشناسی روز</span>
            <div className="text-2xl md:text-3xl font-black text-white">
              {formatPersianNumber(result.fairPrice)} <span className="text-sm font-normal text-slate-300">تومان</span>
            </div>
            {result.fairPriceMin && result.fairPriceMax && (
              <span className="text-[11px] text-sky-300/90 mt-1 block">
                بازه عادلانه معامله: از {formatToman(result.fairPriceMin)} تا {formatToman(result.fairPriceMax)}
              </span>
            )}
            {sellerPrice && (
              <span className="text-xs text-slate-400 mt-1 block">
                قیمت اعلامی فروشنده: {formatToman(sellerPrice)}
              </span>
            )}
          </div>

          <div className="dark-always-box text-center sm:text-left bg-slate-800/80 p-3.5 rounded-xl border border-slate-700">
            <span className="text-xs text-slate-400 block mb-0.5">داوری ارزش معامله</span>
            <span className="text-sm md:text-base font-bold text-sky-400">
              {result.dealJudgment.title}
            </span>
          </div>
        </div>

        {/* Legal Disclaimer & Stamp Space */}
        <div className="border-t border-slate-200 pt-4 text-[10px] text-slate-500 leading-relaxed">
          <p className="font-bold text-slate-700 mb-1">سلب مسئولیت و نکات قانونی:</p>
          <p>
            این گزارش بر اساس اطلاعات و مشخصات اعلام‌شده توسط متقاضی و محاسبات تحلیلی بازار روز خودرو تهیه گردیده است.
            گزارش حاضر جنبه برآورد قیمت منصفانه و راهنمای کارشناسی دارد و به منزله تضمین وضعیت فنی پنهان یا تست مکانیکی در تعمیرگاه معتبر نمی‌باشد.
            توصیه اکید می‌شود پیش از انعقاد قرارداد، خودرو توسط کارشناس خبره در محل مورد بازرسی مکانیکی و چشمی قرار گیرد.
          </p>

          <div className="flex justify-between items-end mt-6 pt-4 border-t border-slate-100 text-[11px]">
            <div>
              <span>محل امضاء و مهر متقاضی یا کارشناس: </span>
              <div className="w-40 h-10 border-b border-dashed border-slate-300 mt-2" />
            </div>
            <div className="text-left font-mono">
              AutoScope Smart Car Appraisal System • www.autoscope.ir
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
