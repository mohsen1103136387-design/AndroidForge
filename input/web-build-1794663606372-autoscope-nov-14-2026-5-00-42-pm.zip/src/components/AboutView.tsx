import React from 'react';
import {
  ShieldAlert,
  Cpu,
  CheckCircle2,
  Smartphone,
  Download,
  ExternalLink,
} from 'lucide-react';
import { isAndroidBridgeAvailable } from '../utils/api';

export const AboutView: React.FC = () => {
  return (
    <div className="space-y-6 max-w-3xl mx-auto pb-12 animate-in fade-in duration-300">
      {/* Brand Profile Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl backdrop-blur-sm text-center relative overflow-hidden">
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center font-black text-2xl mx-auto mb-4 shadow-lg shadow-sky-500/25">
          AS
        </div>
        <h1 className="text-xl md:text-2xl font-black text-slate-100">
          سامانه کارشناسی هوشمند خودرو «اتو اسکوپ»
        </h1>
        <p className="text-xs md:text-sm text-slate-400 max-w-lg mx-auto mt-2 leading-relaxed">
          ابزار تخصصی، مستقل و موبایل‌محور قیمت‌گذاری و کارشناسی خودروهای دست‌دوم در بازار ایران
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 text-center text-xs">
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-sky-400 font-bold text-sm block">۱۰۰٪</span>
            <span className="text-slate-400 text-[11px]">مستقل و بی‌طرف</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-emerald-400 font-bold text-sm block">سه‌بعدی</span>
            <span className="text-slate-400 text-[11px]">بررسی بدنه و شاسی</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-purple-400 font-bold text-sm block">Gemini</span>
            <span className="text-slate-400 text-[11px]">استعلام زنده بازار</span>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
            <span className="text-amber-400 font-bold text-sm block">محلی</span>
            <span className="text-slate-400 text-[11px]">ذخیره آفلاین داده‌ها</span>
          </div>
        </div>
      </div>

      {/* Methodology Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 text-xs md:text-sm text-slate-300 leading-relaxed">
        <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-sky-400" />
          <span>الگوریتم و روش‌شناسی قیمت‌گذاری در اتو اسکوپ</span>
        </h2>
        <p>
          نوسانات نامتعارف و قیمت‌سازی‌های کاذب در پلتفرم‌های آگهی، خریداران و فروشندگان خودرو را با چالش‌های جدی مواجه کرده است.
          «اتو اسکوپ» با پیاده‌سازی فرمول‌های استاندارد اتحادیه نمایشگاه‌داران و صنف کارشناسان رسمی، تمامی ابعاد فنی، بدنه، سن و کارکرد خودرو را به صورت ماتریس وزنی پردازش می‌کند.
        </p>
        <div className="space-y-2 pt-2">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>محاسبه افت سن سالانه بر اساس ضریب خوش‌فروشی برند (Brand Factor)</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>پیمایش استاندارد ۲۰٬۰۰۰ کیلومتر در سال و کسر به ازای کیلومتر مازاد</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>تحلیل هندسی آسیب اسکلت شاسی و ستون‌ها با ضریب بیشینه و سرشکن آسیب‌های زنجیره‌ای</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>تطبیق بلادرنگ با قیمت روز خودرو در بازار از طریق جستجوی هوش مصنوعی (Google Search Grounding)</span>
          </div>
        </div>
      </div>

      {/* AndroidForge APK Source Download Card (shown on web) */}
      {!isAndroidBridgeAvailable() && (
        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-3xl p-6 shadow-xl space-y-4 text-xs md:text-sm text-slate-300 leading-relaxed">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm md:text-base font-bold text-slate-100">
                  سورس آماده ساخت اپلیکیشن اندروید (APK)
                </h2>
                <p className="text-[11px] text-slate-400">
                  پروژه استاندارد Gradle + WebViewAssetLoader ویژه بیلد در سامانه AndroidForge
                </p>
              </div>
            </div>

            <a
              href="/AutoScope-AndroidForge.zip"
              download="AutoScope-AndroidForge.zip"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition active:scale-95 shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>دانلود فایل ZIP سورس اندروید</span>
            </a>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3.5 text-xs text-slate-300 space-y-1.5">
            <p className="font-bold text-slate-200">مراحل دریافت خروجی APK از AndroidForge:</p>
            <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px]">
              <li>فایل <span className="font-mono text-sky-300">AutoScope-AndroidForge.zip</span> را از دکمه بالا دانلود کنید.</li>
              <li>
                وارد سایت{' '}
                <a
                  href="https://professional-x.github.io/AndroidForge/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sky-400 hover:text-sky-300 underline inline-flex items-center gap-1"
                >
                  <span>AndroidForge</span>
                  <ExternalLink className="w-3 h-3" />
                </a>{' '}
                شوید و مخزن/توکن گیت‌هاب خود را متصل کنید.
              </li>
              <li>فایل ZIP را آپلود کرده و گزینه Build APK را بزنید تا فایل نصبی APK تحویل داده شود.</li>
            </ol>
          </div>
        </div>
      )}

      {/* Legal Disclaimer Box (سلب مسئولیت صریح) */}
      <div className="bg-slate-950 border border-rose-500/30 rounded-3xl p-6 shadow-xl space-y-3 text-xs leading-relaxed text-slate-300">
        <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
          <ShieldAlert className="w-5 h-5" />
          <span>سلب مسئولیت قانونی و اخطار مهم:</span>
        </div>
        <p>
          «سامانه اتو اسکوپ» یک ابزار محاسباتی، آماری و تحلیلی است که بر اساس اطلاعات خوداظهاری کاربر و گزارش‌های قیمت روز بازار عمل می‌نماید.
          اطلاعات ارائه شده در این برنامه به منزله مشاوره عمومی قیمت‌گذاری بوده و هیچ‌گونه مسئولیت حقوقی یا مالی در قبال معاملات خریدار یا فروشنده متوجه این سامانه نخواهد بود.
        </p>
        <p className="text-slate-400">
          توصیه اکید ما این است که پیش از هرگونه پرداخت وجه یا عقد قرارداد رسمی، خودرو به همراه مدارک مالکیتی (سند کمپانی، برگ سبز، برگه معاینه فنی و گواهی تسویه خلافی) به صورت حضوری توسط کارشناسان رسمی و با تجهیزات فیزیکی رنگ‌سنج و دیاگ کنترل گردد.
        </p>
      </div>
    </div>
  );
};
