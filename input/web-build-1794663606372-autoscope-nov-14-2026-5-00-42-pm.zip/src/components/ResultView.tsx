import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { motion, useMotionValue, useTransform, animate } from 'framer-motion';
import { AppraisalRecord } from '../types';
import {
  toPersianDigits,
  formatPersianNumber,
  formatToman,
} from '../utils/persian';
import { apiUrl } from '../utils/api';
import { PriceTrendChart } from './PriceTrendChart';
import {
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Share2,
  Printer,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
  Brain,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  Info,
  Layers,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  Scale,
  Play,
} from 'lucide-react';

interface ResultViewProps {
  record: AppraisalRecord;
  records?: AppraisalRecord[];
  onNewEvaluation: () => void;
  onGoToPrint: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const ResultView: React.FC<ResultViewProps> = ({
  record,
  records = [],
  onNewEvaluation,
  onGoToPrint,
  showToast,
}) => {
  const { result, carModel, year, mileage, basePrice, sellerPrice, trackingCode, dayPriceInfo } = record;

  const [feedbackGiven, setFeedbackGiven] = useState<'up' | 'down' | null>(null);

  // Framer Motion Animated Countdown State
  const motionPrice = useMotionValue(basePrice || result.fairPrice);
  const [displayPrice, setDisplayPrice] = useState<number>(basePrice || result.fairPrice);
  const [isCounting, setIsCounting] = useState<boolean>(true);
  const [replayKey, setReplayKey] = useState<number>(0);

  // AI Smart Analysis state
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [showAiModal, setShowAiModal] = useState<boolean>(false);

  // Reset AI analysis and feedback state when switching records
  useEffect(() => {
    setAiAnalysis(null);
    setAiError(null);
    setShowAiModal(false);
    setFeedbackGiven(null);
  }, [record.id]);

  // Framer Motion Numerical Countdown Effect: Starts from basePrice and counts down to fairPrice
  useEffect(() => {
    setIsCounting(true);
    // Start countdown from basePrice (or from fairPrice * 1.3 if basePrice <= fairPrice)
    const startValue = basePrice > result.fairPrice ? basePrice : result.fairPrice;
    const targetValue = result.fairPrice;

    motionPrice.set(startValue);
    setDisplayPrice(startValue);

    const controls = animate(motionPrice, targetValue, {
      duration: 1.8,
      ease: [0.16, 1, 0.3, 1], // snappy smooth cubic-bezier deceleration
      onUpdate: (latest) => {
        setDisplayPrice(Math.round(latest));
      },
      onComplete: () => {
        setDisplayPrice(targetValue);
        setIsCounting(false);

        // Fire celebratory confetti if excellent deal
        if (result.dealJudgment.level === 'excellent') {
          try {
            confetti({
              particleCount: 85,
              spread: 75,
              origin: { y: 0.6 },
            });
          } catch {
            // ignore
          }
        }
      },
    });

    return () => controls.stop();
  }, [result.fairPrice, basePrice, replayKey, result.dealJudgment.level]);

  // Replay countdown animation
  const handleReplayCountdown = () => {
    setReplayKey((prev) => prev + 1);
  };

  // Request AI Smart Analysis
  const handleFetchAiAnalysis = async () => {
    setShowAiModal(true);
    if (aiAnalysis) return;

    setIsAiLoading(true);
    setAiError(null);

    try {
      const res = await fetch(apiUrl('/api/car-analysis'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          carModel,
          year,
          mileage,
          basePrice,
          fairPrice: result.fairPrice,
          askingPrice: sellerPrice,
          dealJudgment: result.dealJudgment.title,
          damagedParts: Object.entries(record.bodyParts)
            .filter(([_, s]) => s.damaged || s.painted)
            .map(([id, s]) => ({ id, ...s })),
          damagedChassis: Object.entries(record.chassisParts)
            .filter(([_, s]) => s !== 'none')
            .map(([id, s]) => ({ id, severity: s })),
          technicalIssues: record.technical,
          labels: record.labels,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'خطا در تحلیل هوش مصنوعی');
      }

      setAiAnalysis(data.analysis);
    } catch (err: any) {
      console.error(err);
      setAiError('دریافت تحلیل کارشناسی هوش مصنوعی با خطا مواجه شد. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsAiLoading(false);
    }
  };

  // Share text summary to clipboard
  const handleShareText = () => {
    const text = `📊 نتیجه کارشناسی خودرو اتو اسکوپ (AutoScope)
🚗 خودرو: ${carModel} مدل ${toPersianDigits(year)}
📏 کارکرد: ${formatPersianNumber(mileage)} کیلومتر
💎 ارزش بازار (پایه): ${formatToman(basePrice)}
📉 افت کارشناسی: ${toPersianDigits(result.totalDeductionPercentage)}٪ (${formatToman(result.totalDeductions)})
✅ قیمت منطقی روز: ${formatToman(result.fairPrice)}
${result.fairPriceMin && result.fairPriceMax ? `🎯 بازه عادلانه معامله: از ${formatToman(result.fairPriceMin)} تا ${formatToman(result.fairPriceMax)}\n` : ''}${sellerPrice ? `🏷️ قیمت فروشنده: ${formatToman(sellerPrice)} (${result.dealJudgment.title})\n` : ''}
کد پیگیری: ${trackingCode}`;

    if (window.AndroidBridge?.shareText) {
      window.AndroidBridge.shareText(text, `گزارش کارشناسی ${carModel}`);
      showToast('پنجره اشتراک‌گذاری اندروید باز شد.', 'success');
      return;
    }

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      showToast('خلاصه کارشناسی خودرو در حافظه کپی شد.', 'success');
    } else {
      showToast('امکان کپی خودکار فراهم نیست.', 'error');
    }
  };

  // Feedback
  const handleFeedback = (type: 'up' | 'down') => {
    setFeedbackGiven(type);
    showToast(
      type === 'up'
        ? 'با تشکر! بازخورد مثبت شما در بهبود الگوریتم ثبت شد.'
        : 'با تشکر از ثبت نظر؛ بازخورد شما توسط تیم فنی بررسی خواهد شد.',
      'info'
    );
  };

  // Comparison Bar Max Value
  const maxBarValue = Math.max(basePrice, result.fairPrice, sellerPrice || 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: 'easeOut' }}
      className="space-y-6 max-w-3xl mx-auto pb-12"
    >
      {/* ── Top Header Card: نتیجه کارشناسی ── */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
        {/* Glow accent */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-5 border-b border-slate-800/80">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs bg-sky-500/15 text-sky-300 border border-sky-500/30 px-2.5 py-0.5 rounded-full font-medium">
                کد گواهی: {trackingCode}
              </span>
              <span className="text-xs text-slate-400">{record.shamsiDate}</span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-slate-100 mt-2">
              {carModel} <span className="text-sky-400">مدل {toPersianDigits(year)}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              کارکرد: {formatPersianNumber(mileage)} کیلومتر | افت کل: {toPersianDigits(result.totalDeductionPercentage)}٪
            </p>
          </div>

          {/* Deal judgment badge */}
          {sellerPrice && (
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className={`px-4 py-2 rounded-2xl border text-xs md:text-sm font-bold flex items-center gap-1.5 shadow-lg ${result.dealJudgment.badgeClass}`}
            >
              <span>{result.dealJudgment.title}</span>
            </motion.div>
          )}
        </div>

        {/* ── Big Fair Price Spotlight with Framer Motion Numerical Countdown ── */}
        <motion.div
          key={replayKey}
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="bg-slate-950/80 border border-sky-500/40 rounded-2xl p-5 md:p-6 text-center my-4 relative shadow-inner overflow-hidden"
        >
          {/* Subtle pulse background glow during counting */}
          <div
            className={`absolute inset-0 bg-sky-500/5 transition-opacity duration-700 pointer-events-none ${
              isCounting ? 'opacity-100 animate-pulse' : 'opacity-0'
            }`}
          />

          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="text-xs text-slate-400 font-medium">قیمت منطقی و عادلانه کارشناسی</span>
            {isCounting ? (
              <span className="inline-flex items-center gap-1 text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-semibold animate-pulse">
                <TrendingDown className="w-3 h-3 text-amber-400" />
                <span>شمارش معکوس و کسر افت...</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>نهایی شد</span>
              </span>
            )}

            <button
              type="button"
              onClick={handleReplayCountdown}
              className="p-1 rounded-lg text-slate-400 hover:text-sky-300 hover:bg-slate-800/80 transition"
              title="پخش مجدد شمارش معکوس"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Animated Countdown Value */}
          <motion.div
            className="text-3xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-l from-sky-400 via-teal-300 to-emerald-400 font-mono tracking-tight my-1"
            animate={isCounting ? { scale: [1, 1.02, 1] } : { scale: 1 }}
            transition={{ duration: 0.4, repeat: isCounting ? Infinity : 0 }}
          >
            {formatPersianNumber(displayPrice)}{' '}
            <span className="text-base md:text-xl text-slate-400 font-normal">تومان</span>
          </motion.div>

          {/* Fair Transaction Range & Confidence Badge */}
          <div className="flex items-center justify-center gap-2 flex-wrap mt-2">
            {result.fairPriceMin && result.fairPriceMax && (
              <span className="inline-flex items-center gap-1.5 text-[11px] bg-slate-900/90 border border-slate-700/80 text-slate-300 px-3 py-1 rounded-full">
                <span>بازه عادلانه معامله:</span>
                <strong className="text-sky-300">
                  {formatToman(result.fairPriceMin)} تا {formatToman(result.fairPriceMax)}
                </strong>
              </span>
            )}
            {result.confidenceLevel && (
              <span
                className={`inline-flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-full font-semibold border ${
                  result.confidenceLevel === 'high'
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : result.confidenceLevel === 'medium'
                    ? 'bg-sky-500/15 text-sky-300 border-sky-500/30'
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                }`}
              >
                <span>
                  {result.confidenceLevel === 'high'
                    ? 'دقت بالا (داده‌های زنده سال ساخت)'
                    : result.confidenceLevel === 'medium'
                    ? 'دقت استاندارد (مبنای بازار روز)'
                    : 'برآورد تقریبی / دستی'}
                </span>
              </span>
            )}
          </div>

          <div className="flex items-center justify-center gap-4 mt-3 pt-3 border-t border-slate-800/80 text-xs text-slate-400 flex-wrap">
            <div>
              <span>{dayPriceInfo?.isDiscontinued ? 'میانگین قیمت بازار (توقف تولید): ' : 'قیمت پایه بازار: '}</span>
              <span className="text-slate-200 font-semibold">{formatToman(basePrice)}</span>
            </div>
            <span className="text-slate-600">•</span>
            <div>
              <span>مجموع کسورات کارشناسی: </span>
              <span className="text-rose-400 font-semibold">{formatToman(result.totalDeductions)}</span>
            </div>
          </div>

          {dayPriceInfo?.isDiscontinued && (
            <div className="mt-3 p-2.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-200 text-[11px] leading-relaxed text-right flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                توجه: به دلیل توقف تولید این خودرو، قیمت پایه مبنا از میانگین آگهی‌های دیوار، باما و سایت‌های معتبر خودرو استخراج شده و قیمت روز و دقیق کارخانه‌ای نیست.
              </span>
            </div>
          )}
        </motion.div>

        {/* Seller Price Judgment Explanation */}
        {sellerPrice ? (
          <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800 text-xs text-slate-300 leading-relaxed">
            <div className="flex items-center gap-2 mb-1.5">
              <Scale className="w-4 h-4 text-sky-400 shrink-0" />
              <span className="font-bold text-slate-100">تحلیل اختلاف قیمت فروشنده با قیمت منطقی:</span>
            </div>
            <p>{result.dealJudgment.description}</p>
            <div className="mt-2 text-[11px] text-slate-400">
              قیمت اعلامی فروشنده: <span className="text-slate-200 font-semibold">{formatToman(sellerPrice)}</span>
              {' '}(
              {result.dealJudgment.diffPercent > 0 ? (
                <span className="text-rose-400 font-bold">+{toPersianDigits(result.dealJudgment.diffPercent)}٪ گران‌تر</span>
              ) : (
                <span className="text-emerald-400 font-bold">{toPersianDigits(result.dealJudgment.diffPercent)}٪ ارزان‌تر</span>
              )}
              )
            </div>
          </div>
        ) : (
          <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 text-xs text-slate-400 flex items-center gap-2">
            <Info className="w-4 h-4 text-sky-400 shrink-0" />
            <span>قیمت اعلامی فروشنده وارد نشده بود. در صورت تمایل به مقایسه معامله، می‌توانید قیمت پیشنهادی فروشنده را در فرم ویرایش کنید.</span>
          </div>
        )}
      </div>

      {/* ── 3-Bar Comparison Chart with Framer Motion ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <h3 className="text-sm font-bold text-slate-100 mb-4 flex items-center gap-2">
          <Layers className="w-4 h-4 text-sky-400" />
          <span>مقایسه نموداری ارزش خودرو</span>
        </h3>

        <div className="space-y-4">
          {/* Base Market Price Bar */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">قیمت خودرو سالم / پایه بازار</span>
              <span className="text-slate-200 font-semibold">{formatToman(basePrice)}</span>
            </div>
            <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(basePrice / maxBarValue) * 100}%` }}
                transition={{ duration: 1.2, ease: 'easeOut' }}
                className="h-full bg-slate-400 rounded-full"
              />
            </div>
          </div>

          {/* Fair Price Bar */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-sky-300 font-bold">قیمت منطقی کارشناسی شده</span>
              <span className="text-sky-400 font-bold">{formatToman(result.fairPrice)}</span>
            </div>
            <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(result.fairPrice / maxBarValue) * 100}%` }}
                transition={{ duration: 1.5, ease: 'easeOut' }}
                className="h-full bg-gradient-to-l from-sky-400 to-teal-400 rounded-full"
              />
            </div>
          </div>

          {/* Seller Asking Price Bar */}
          {sellerPrice && (
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">قیمت اعلامی فروشنده</span>
                <span className={`font-semibold ${sellerPrice > result.fairPrice ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {formatToman(sellerPrice)}
                </span>
              </div>
              <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(sellerPrice / maxBarValue) * 100}%` }}
                  transition={{ duration: 1.3, ease: 'easeOut' }}
                  className={`h-full rounded-full ${
                    sellerPrice > result.fairPrice ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Real 30-Day Historical Price Trend Chart (Recharts) ── */}
      <PriceTrendChart
        basePrice={basePrice}
        carModel={carModel}
        year={year}
        dayPriceInfo={dayPriceInfo}
        records={records}
      />

      {/* ── Deductions Breakdown Table ── */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-xl backdrop-blur-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm md:text-base font-bold text-slate-100 flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-rose-400" />
              <span>ریز جدول کسورات و افت قیمت کارشناسی</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">تفکیک شفاف هر عامل، درصد افت و مبلغ کسرشده</p>
          </div>
          <span className="text-xs bg-rose-500/15 text-rose-300 border border-rose-500/30 px-2.5 py-1 rounded-xl font-bold">
            -{toPersianDigits(result.totalDeductionPercentage)}٪
          </span>
        </div>

        {result.isCapped && (
          <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              سقف مجاز افت قیمت در استاندارد کارشناسی حداکثر ۹۰٪ قیمت پایه است؛ با رسیدن به این حد، مبالغ ردیف‌های جدول به تناسب تنظیم شدند تا جمع نهایی با قیمت منطقی هماهنگ باشد.
            </span>
          </div>
        )}

        {result.rows.length === 0 ? (
          <div className="py-8 text-center bg-slate-950/40 rounded-2xl border border-slate-800/80">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-200">خودرو در شرایط استثنایی و بدون افت قیمت است!</p>
            <p className="text-xs text-slate-400 mt-1">هیچ‌گونه کسری سن، کارکرد مازاد یا آسیب بدنه و شاسی ثبت نشده است.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 px-3 font-semibold">عامل افت قیمت</th>
                  <th className="py-2.5 px-3 font-semibold text-center">درصد</th>
                  <th className="py-2.5 px-3 font-semibold text-left">مبلغ کسرشده (تومان)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {result.rows.map((row, index) => {
                  const isBonus = row.amount < 0;
                  const isInfoZero = row.amount === 0;
                  return (
                    <motion.tr
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 + index * 0.04 }}
                      className="hover:bg-slate-800/30 transition"
                    >
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-200">{row.factor}</div>
                        {row.description && (
                          <div className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{row.description}</div>
                        )}
                      </td>
                      <td
                        className={`py-3 px-3 text-center font-bold whitespace-nowrap ${
                          isBonus ? 'text-emerald-400' : isInfoZero ? 'text-sky-400' : 'text-rose-400'
                        }`}
                      >
                        {isBonus
                          ? `+${toPersianDigits(Math.abs(row.percentage))}٪ ارزش افزوده`
                          : isInfoZero
                          ? '۰٪ (لحاظ‌شده)'
                          : `${toPersianDigits(row.percentage)}٪`}
                      </td>
                      <td
                        className={`py-3 px-3 text-left font-mono font-semibold whitespace-nowrap ${
                          isBonus ? 'text-emerald-400' : isInfoZero ? 'text-slate-400' : 'text-slate-300'
                        }`}
                      >
                        {isBonus
                          ? `+${formatPersianNumber(Math.abs(row.amount))}`
                          : formatPersianNumber(row.amount)}
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t border-slate-700 bg-slate-950/60 font-bold text-slate-100">
                  <td className="py-3.5 px-3">مجموع کل کسورات</td>
                  <td className="py-3.5 px-3 text-center text-rose-400">
                    {toPersianDigits(result.totalDeductionPercentage)}٪
                  </td>
                  <td className="py-3.5 px-3 text-left font-mono text-rose-400">
                    {formatPersianNumber(result.totalDeductions)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      {/* ── AI Smart Analysis Action Button ── */}
      <div className="bg-gradient-to-l from-indigo-950/50 via-slate-900 to-sky-950/50 border border-indigo-500/30 rounded-3xl p-5 md:p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-slate-100 text-sm md:text-base flex items-center gap-2">
            <Brain className="w-5 h-5 text-indigo-400" />
            <span>تحلیل هوشمند با هوش مصنوعی (Gemini)</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            ارزیابی ریسک‌های ایمنی، نکات چک‌لیست بازدید حضوری و ترفندهای چانه‌زنی با فروشنده
          </p>
        </div>

        <button
          type="button"
          onClick={handleFetchAiAnalysis}
          className="shrink-0 w-full sm:w-auto min-h-[46px] px-5 py-3 rounded-2xl bg-gradient-to-l from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white font-bold text-xs md:text-sm shadow-lg shadow-indigo-500/20 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>مشاهده تحلیل هوشمند</span>
        </button>
      </div>

      {/* ── Action Buttons Bar ── */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <button
          type="button"
          onClick={handleShareText}
          className="min-h-[46px] py-3 px-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95 shadow-md"
        >
          <Share2 className="w-4 h-4 text-sky-400" />
          <span>اشتراک متنی</span>
        </button>

        <button
          type="button"
          onClick={onGoToPrint}
          className="min-h-[46px] py-3 px-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95 shadow-md"
        >
          <Printer className="w-4 h-4 text-purple-400" />
          <span>ذخیره PDF / چاپ</span>
        </button>

        <div className="col-span-2 sm:col-span-1 flex gap-1">
          <button
            type="button"
            onClick={() => handleFeedback('up')}
            className={`flex-1 py-3 px-2 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-1 transition ${
              feedbackGiven === 'up'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700/80'
            }`}
            title="کارشناسی مفید بود"
          >
            <ThumbsUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>منصفانه</span>
          </button>
          <button
            type="button"
            onClick={() => handleFeedback('down')}
            className={`flex-1 py-3 px-2 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-1 transition ${
              feedbackGiven === 'down'
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700/80'
            }`}
            title="نیاز به اصلاح"
          >
            <ThumbsDown className="w-3.5 h-3.5 text-rose-400" />
            <span>غیرمنصفانه</span>
          </button>
        </div>

        <button
          type="button"
          onClick={onNewEvaluation}
          className="col-span-2 sm:col-span-1 py-3 px-3 rounded-2xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/40 text-sky-300 text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 shadow-md"
        >
          <RotateCcw className="w-4 h-4" />
          <span>ارزیابی جدید</span>
        </button>
      </div>

      {/* ── AI Analysis Modal ── */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 md:p-5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Brain className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-slate-100 text-sm md:text-base">
                  تحلیل تخصصی کارشناس هوش مصنوعی
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAiModal(false)}
                className="p-1 text-slate-400 hover:text-slate-200"
              >
                ✕
              </button>
            </div>

            <div className="p-5 md:p-6 overflow-y-auto flex-1 space-y-4">
              {isAiLoading ? (
                <div className="py-12 text-center">
                  <div className="inline-block w-8 h-8 border-3 border-indigo-400 border-t-transparent rounded-full animate-spin mb-3" />
                  <p className="text-sm font-semibold text-slate-200">در حال تحلیل ریسک‌ها و تدوین استراتژی چانه‌زنی با Gemini...</p>
                  <p className="text-xs text-slate-400 mt-1">لطفاً چند لحظه شکیبا باشید</p>
                </div>
              ) : aiError ? (
                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                  {aiError}
                </div>
              ) : aiAnalysis ? (
                <div className="max-w-none text-slate-200 text-xs md:text-sm leading-relaxed whitespace-pre-line space-y-2">
                  {aiAnalysis}
                </div>
              ) : null}
            </div>

            <div className="p-4 border-t border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowAiModal(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                بستن
              </button>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};
